# DeroM Advanced Features Guide

This document covers the new enterprise-grade features added to DeroM.

## PyQt5 Modern GUI

### Installation

```bash
py -m pip install -r requirements.txt
```

The requirements now include PyQt5 and cryptography libraries.

### Launching

**Windows:**
```bash
DeroM_Qt.bat
```

**Command line:**
```bash
py -B -m derom.gui_qt
```

### Features

- **Modern Dark Theme**: GitHub-inspired dark color scheme
- **Tabbed Interface**: Separate tabs for Node, Wallets, Block Explorer, and Settings
- **Real-time Statistics**: Live height, difficulty, miner count, and mempool status
- **Block Explorer**: Search blocks by height, transactions by hash, and addresses
- **Activity Log**: Complete history of all operations

---

## Multi-Address Wallet Management

### Overview

Manage multiple addresses/keypairs within a single wallet file.

### Usage Example (Python API)

```python
from derom.multi_wallet import MultiAddressWallet

# Create new multi-address wallet
wallet = MultiAddressWallet.create_new("wallet_multi.json", name="My Trading Wallet")

# Add more addresses
wallet.add_address(label="Savings", is_default=False)
wallet.add_address(label="Mining", is_default=False)

# Import existing private key
wallet.import_address(private_key_hex, label="Imported Key")

# Get statistics
print(f"Total balance: {wallet.get_total_balance()}")
print(f"Addresses: {len(wallet.list_addresses())}")

# Save to disk
wallet.save()
```

### In GUI

1. Click **Wallets** tab
2. Use **New Wallet** to generate fresh addresses
3. Use **Import** to add existing keys
4. Switch between addresses using the dropdown
5. View balance and transaction history for each address

---

## Encrypted Wallet Support

### Overview

Protect wallet files with AES-256-GCM encryption using a password.

### Creating Encrypted Wallet (Python API)

```python
from derom.encryption import EncryptedWallet, WalletManager

wallet_data = {
    "address": "D...",
    "private_key": "...",
    "public_key": "...",
}

# Encrypt with password
encrypted = EncryptedWallet.encrypt_wallet(wallet_data, password="MySecurePassword123!")

# Save to file
with open("wallet_encrypted.json", "w") as f:
    json.dump(encrypted, f)
```

### Decrypting

```python
# Load encrypted file
with open("wallet_encrypted.json", "r") as f:
    encrypted_data = json.load(f)

# Decrypt with password
wallet = EncryptedWallet.decrypt_wallet(encrypted_data, password="MySecurePassword123!")

if wallet:
    print(f"Address: {wallet['address']}")
else:
    print("Wrong password or corrupted wallet")
```

### Encryption Specs

- **Algorithm**: AES-256-GCM
- **Key Derivation**: PBKDF2-SHA256 (100,000 iterations)
- **Salt Size**: 16 bytes
- **IV/Nonce Size**: 12 bytes

**Security Notes**:
- Passwords must be at least 12 characters (recommended 16+)
- Encrypted file contains no private key material in plaintext
- Authentication tag ensures file hasn't been tampered with

---

## PPLNS Pool Mode

### Overview

Pay Per Last N Shares pool allows multiple miners to contribute and split block rewards.

### Configuration

Create `pool_config.json`:

```json
{
    "pool_name": "My DeroM Pool",
    "pool_address": "D...",
    "window_size": 1000,
    "block_reward": 5000000000,
    "pool_fee": 0.01,
    "min_payout": 10000000,
    "difficulty_multiplier": 256
}
```

### Running Pool Server

```python
from derom.pool import PPLNSPool

pool = PPLNSPool("pool_config.json")

# Process miner share
result = pool.submit_share(
    address="D...",
    difficulty=256.0,
    block=False  # or True if it's a block solution
)

# When block is found
if result["block"]:
    payouts = result["block_info"]["payouts"]
    # payouts[address] = amount in atoms
```

### Pool Statistics API

```python
# Get miner stats
stats = pool.get_miner_stats("D...")

# Get pool stats
pool_stats = pool.get_pool_stats()
print(f"Miners: {pool_stats['miners']}")
print(f"Blocks found: {pool_stats['blocks_found']}")
print(f"Total paid: {pool_stats['total_paid_out']}")

# Process and distribute payouts
payouts = pool.process_payouts()
for address, amount in payouts.items():
    # Send transaction to address for amount
    pass
```

### How PPLNS Works

1. Miners submit shares with their difficulty target
2. Pool tracks last N shares (configurable window)
3. When a block is found, reward is split proportionally to share difficulty
4. Each miner receives share_difficulty / total_window_difficulty × block_reward
5. Payments accumulate until reaching minimum payout threshold

---

## P2P Node Synchronization

### Overview

Connect multiple DeroM nodes to form a distributed network for chain synchronization.

### Configuration

In `config.json`, add P2P settings:

```json
{
    "p2p_enabled": true,
    "p2p_listen_host": "0.0.0.0",
    "p2p_listen_port": 3334,
    "p2p_initial_peers": [
        "node1.example.com:3334",
        "node2.example.com:3334"
    ]
}
```

### Python API

```python
from derom.p2p import P2PNode

# Create node
p2p = P2PNode(
    node_id="my-node-1",
    listen_host="0.0.0.0",
    listen_port=3334,
    initial_peers=["peer1:3334", "peer2:3334"]
)

# Start P2P networking
p2p.start()

# Broadcast new block
p2p.broadcast_block({
    "height": 12345,
    "hash": "...",
    "data": "..."
})

# Broadcast transaction
p2p.broadcast_transaction({
    "id": "...",
    "from": "D...",
    "to": "D...",
    "amount": 1000000000
})

# Request blocks from peers
blocks = p2p.request_blocks(from_height=1000, to_height=1100)

# Get sync status
status = p2p.get_sync_status()
print(f"Synced: {status['synced']}")
print(f"Height: {status['best_height']}")
print(f"Peers: {status['peer_count']}")

# Stop
p2p.stop()
```

### P2P Network Architecture

- **Handshake Protocol**: Nodes exchange version, height, and capabilities
- **Block Propagation**: New blocks broadcast to all connected peers
- **Transaction Relay**: Pending transactions propagated through network
- **Ping/Pong**: Keep-alive mechanism detects disconnected peers
- **Auto-Connect**: Attempts to maintain connections to seed nodes

### Peer Management

```python
# Add peer
p2p.add_peer("node3.example.com", 3334)

# Get peer info
peers = p2p.get_peer_info()
for peer in peers:
    print(f"{peer['id']}: height={peer['height']}, connected={peer['connected']}")

# Monitor network
while p2p.running:
    status = p2p.get_sync_status()
    print(f"Height: {status['best_height']}, Peers: {status['peer_count']}")
    time.sleep(5)
```

---

## Integration Guide

### Using All Features Together

```python
from derom.node import NodeRunner
from derom.pool import PPLNSPool
from derom.p2p import P2PNode
from derom.multi_wallet import MultiAddressWallet
from derom.encryption import EncryptedWallet

# 1. Load encrypted wallet
with open("wallet.json") as f:
    enc_data = json.load(f)
wallet = EncryptedWallet.decrypt_wallet(enc_data, password="secure!")

# 2. Start node with P2P sync
node = NodeRunner("config.json", "data/")
p2p = P2PNode("my-node", "0.0.0.0", 3334)
node.p2p = p2p
p2p.start()

# 3. Setup pool
pool = PPLNSPool("pool_config.json")

# 4. Manage multi-address wallet
multi_wallet = MultiAddressWallet("wallet_multi.json")
multi_wallet.load()

# 5. Process mining with pool
for share in mining_results:
    result = pool.submit_share(
        address=share["miner"],
        difficulty=share["difficulty"],
        block=share["is_block"]
    )
    
    if result["block"]:
        # Block found! Distribute rewards
        payouts = pool.process_payouts()
        for addr, amount in payouts.items():
            # Send payout transaction...
            pass
```

---

## Performance Considerations

### Pool Settings

- **Window Size**: Larger windows = more stable earnings but slower payouts
  - Small pools (< 50 miners): 500 shares
  - Medium pools: 1000 shares
  - Large pools: 5000+ shares

- **Minimum Payout**: Balance safety against payout frequency
  - Too low: Many small transactions
  - Too high: Miners wait longer

### P2P Network

- **Peer Count**: Target 3-10 peers per node
  - Fewer: Slower sync, less network resilience
  - More: Higher bandwidth but better redundancy

- **Block Propagation**: ~5-10 seconds typical
- **Full Sync Time**: ~1 second per 1000 blocks

### Encryption Performance

- Key derivation: ~100ms (intentional, for security)
- Encryption/decryption: <1ms for typical wallets

---

## Security Best Practices

1. **Encrypted Wallets**
   - Use strong passwords (16+ characters, mixed case/numbers/symbols)
   - Never reuse passwords
   - Store password separately from wallet file

2. **Private Keys**
   - Always keep `wallet.json` on encrypted storage
   - Backup encrypted wallets to secure location
   - Never share or paste private keys in unsecured applications

3. **P2P Network**
   - Validate peer signatures (future enhancement)
   - Use firewalls to restrict P2P connections if needed
   - Monitor for suspicious peer behavior

4. **Pool Operation**
   - Keep pool wallet separate from mining wallet
   - Regularly sweep pool wallet to cold storage
   - Audit payout transactions frequently

---

## Troubleshooting

### GUI doesn't start
```bash
# Install missing PyQt5
py -m pip install PyQt5 --upgrade

# Try from command line for error messages
py -B -m derom.gui_qt
```

### Encryption/decryption fails
- Verify password is correct
- Check wallet file hasn't been corrupted
- Ensure `cryptography` library is installed

### P2P not syncing
- Verify firewall allows port 3334
- Check `p2p_initial_peers` are reachable
- Monitor logs for connection errors

### Pool not distributing payouts
- Verify block reward configuration
- Check minimum payout amount
- Ensure pool wallet has funds for payouts

---

## API Reference

All modules are importable from the `derom` package:

```python
from derom.encryption import EncryptedWallet, WalletManager
from derom.multi_wallet import MultiAddressWallet
from derom.pool import PPLNSPool, PoolAccount
from derom.p2p import P2PNode, PeerConnection
from derom.gui_qt import DeroMMainWindow, main
```

---

## Future Enhancements

- [ ] Peer reputation system
- [ ] Transaction fee market
- [ ] Atomic swaps
- [ ] Lightning-like payment channels
- [ ] Hardware wallet integration
- [ ] Cold storage utilities
- [ ] Mobile wallet companion

