@echo off
rem Builds dist\DeroM.exe (single file, no Python needed on the target PC)
rem and copies it next to this script so it uses the same wallet/data.
cd /d "%~dp0"

py -m pip install --upgrade pyinstaller || goto :err

py -B -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name DeroM DeroM.py || goto :err

copy /y "dist\DeroM.exe" "DeroM.exe" >nul || goto :err
echo.
echo SUCCESS: DeroM.exe created in %~dp0
exit /b 0

:err
echo.
echo BUILD FAILED - see output above
pause
exit /b 1
