@echo off
REM Build DeroM PyQt5 GUI as standalone executable
REM Requires: pyinstaller (pip install pyinstaller)

title Building DeroM Qt Executable

echo Building DeroM Qt Control Panel...
echo.

REM Check if pyinstaller is installed
py -m pip list | findstr /i pyinstaller >nul
if errorlevel 1 (
    echo Installing PyInstaller...
    py -m pip install pyinstaller
)

REM Build the executable
py -m PyInstaller DeroM_Qt.spec --onefile --distpath . --buildpath build_qt

if errorlevel 0 (
    echo.
    echo ========================================
    echo SUCCESS: DeroM_Qt.exe created
    echo ========================================
    echo Location: %CD%\DeroM_Qt.exe
    echo.
    echo The executable is now standalone and can be:
    echo - Copied to any Windows PC (no Python required)
    echo - Launched directly by double-clicking
    echo - Distributed to other users
    echo.
    pause
) else (
    echo.
    echo FAILED: Build error
    echo.
    pause
)
