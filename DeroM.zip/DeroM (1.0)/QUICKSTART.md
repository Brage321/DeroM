# DeroM v2.0 Quick Start Guide

## Installation

```bash
cd "DeroM (1.0)"
py -m pip install -r requirements.txt
```

This installs:
- `ecdsa` - Cryptography
- `PyQt5` - Modern GUI
- `cryptography` - Wallet encryption

## Launching the Application

### Option 1: Modern PyQt5 GUI (Recommended)
```bash
DeroM_Qt.bat              # Windows - double-click
py -B -m derom.gui_qt     # Command line
```

### Option 2: Legacy Tkinter GUI
```bash
DeroM.bat                 # Windows - double-click
py -B -m derom.gui        # Command line
```

### Option 3: Command Line Tools
```bash
py -m derom.wallet create           # Create wallet
py -m derom.wallet address          # Show address
py -m derom.wallet balance          # Check balance
py -m derom.wallet send --to D... --amount 5  # Send coins
```

## First Time Setup

### 1. Create a Wallet

**GUI Method (Easiest):**
1. Launch `DeroM_Qt.bat`
2. Go to **Wallets** tab
3. Click **New Wallet**
4. Wallet created! Your address appears in the ADDRESS field

**CLI Method:**
```bash
py -m derom.wallet create
# Prints your D... address
# wallet.json created in current directory
```

### 2. Start Mining Node

**GUI Method:**
1. Still in **Wallets** tab, note your address
2. Click **Node Status** tab
3. Click **Start Node**
4. Wait for green indicator (usually 5-10 seconds)
5. Copy the URL and username shown in CONNECT YOUR MINER section

**CLI Method:**
```bash
start_node.bat
# or
py -m derom.node
```

### 3. Point Miner to Node

**In Your ASIC Miner Config:**
```
URL:      stratum+tcp://YOUR_PC_IP:3333
User:     YOUR_D_ADDRESS.worker1
Password: x
```

**Example:**
```
URL:      stratum+tcp://192.168.1.100:3333
User:     DbQYQzQ6y9aB5jvUDWhj3HU5mLLCX5rw35.worker1
Password: x
```

## Advanced Features

### Multi-Address Wallets

Add more addresses to receive rewards from different mining operations:

**GUI Method:**
1. **Wallets** tab → **New Wallet** button → generates fresh address
2. Repeat to add multiple addresses
3. Switch between them in dropdown

**Python API:**
```python
from derom.multi_wallet import MultiAddressWallet

wallet = MultiAddressWallet.create_new("mywallets.json")
wallet.add_address(label="GPU Mining")
wallet.add_address(label="ASIC #1")
wallet.add_address(label="ASIC #2")
wallet.save()
```

### Encrypted Wallets

Protect sensitive wallets with passwords:

**GUI Method:**
1. Create wallet normally
2. Backup wallet file to safe location
3. Password-protect with encryption tool (todo: add to GUI)

**Python API:**
```python
from derom.encryption import EncryptedWallet
import json

# Create encrypted wallet
wallet_data = {
    "address": "D...",
    "private_key": "...",
    "public_key": "..."
}

encrypted = EncryptedWallet.encrypt_wallet(
    wallet_data,
    password="MyStrongPassword123!"
)

# Save to file
with open("wallet_secure.json", "w") as f:
    json.dump(encrypted, f)

# Later: Decrypt and use
with open("wallet_secure.json") as f:
    enc_data = json.load(f)

wallet = EncryptedWallet.decrypt_wallet(enc_data, password="MyStrongPassword123!")
print(wallet["address"])
```

### Block Explorer

**GUI Method:**
1. Click **Block Explorer** tab
2. Enter block height (e.g., "1", "100", "12345")
3. Click **Search** to view block details
4. Or enter D... address to see account balance

**Key Info Displayed:**
- Height, Hash, Miner address
- Block Reward in DEROM
- Timestamp
- Transaction count

### Setup Pool Mining

Enable multiple miners to share rewards:

**1. Create Pool Config** (`pool_config.json`):
```json
{
    "pool_name": "My Mining Pool",
    "pool_address": "DPoolOperator123...",
    "pool_fee": 0.01,
    "window_size": 1000,
    "block_reward": 5000000000,
    "min_payout": 10000000
}
```

**2. Start Pool Server:**
```python
from derom.pool import PPLNSPool

pool = PPLNSPool("pool_config.json")

# Miners connect and submit shares
# When block found, rewards distributed automatically
```

**3. Configure Miners:**
```
URL:      stratum+tcp://pool_machine_ip:3333
User:     YOUR_ADDRESS.worker1
Password: x
```

### Setup P2P Network (Advanced)

Connect multiple nodes for distributed mining:

**1. Update Config:**
```json
{
    "p2p_enabled": true,
    "p2p_listen_port": 3334,
    "p2p_initial_peers": [
        "peer1.example.com:3334",
        "peer2.example.com:3334"
    ]
}
```

**2. Start Node:**
```bash
py -m derom.node
```

Node automatically connects to peers and syncs blockchain.

**3. Monitor Status:**
```python
from derom.p2p import P2PNode

p2p = P2PNode("my-node")
p2p.start()

# Check status every 5 seconds
import time
while True:
    status = p2p.get_sync_status()
    print(f"Height: {status['best_height']}, Peers: {status['peer_count']}")
    time.sleep(5)
```

## Building Standalone Executables

### PyQt5 GUI Executable
```bash
build_exe_qt.bat
```

Creates `DeroM_Qt.exe` (~50 MB) - works on any Windows PC, no Python needed.

### Legacy Tkinter Executable
```bash
build_exe.bat
```

Creates `DeroM.exe` (~13 MB) - lighter weight.

## Troubleshooting

### "ModuleNotFoundError: No module named 'PyQt5'"
```bash
py -m pip install PyQt5 --upgrade
```

### "Node offline" in GUI
1. Check Windows Firewall allows port 3333
2. Verify `config.json` exists
3. Check `data/` directory exists
4. Try starting from command line: `py -m derom.node`

### Miner shows "rejected" shares
1. Verify miner username is FULL address (not just prefix)
2. Username must be: `DxxxxAddress.workername`
3. Check miner can reach node IP (ping test)
4. Verify port 3333 is open

### Can't connect to pool
1. Verify pool machine IP is correct
2. Check firewall on pool machine allows port 3333
3. Try from same network first (localhost testing)
4. Check pool is running: `py -c "from derom.pool import PPLNSPool; p = PPLNSPool(); print('Pool OK')"`

### Encrypted wallet won't decrypt
1. Verify password is EXACTLY correct (case-sensitive)
2. Check wallet file isn't corrupted
3. Try with backup copy if available
4. Ensure cryptography library is installed: `py -m pip install cryptography --upgrade`

## Common Commands Reference

```bash
# Wallets
py -m derom.wallet create                    # Create new wallet
py -m derom.wallet address                   # Show address
py -m derom.wallet balance                   # Check balance
py -m derom.wallet balance --address D...    # Check any address
py -m derom.wallet send --to D... --amount 5 # Send coins

# Node
py -m derom.node                             # Start node manually
py -m derom.rpc getinfo                      # Get node info (must be running)
py -m derom.rpc getblockcount                # Get block height

# Mining
py test_miner.py --user D....worker1 --seconds 60  # Test CPU mining

# GUI
DeroM_Qt.bat                                 # Modern PyQt5 interface
DeroM.bat                                    # Legacy Tkinter interface
py -B -m derom.gui_qt                        # PyQt5 from command line
py -B -m derom.gui                           # Tkinter from command line
```

## Network Ports

- **3333**: Stratum mining protocol (miners connect here)
- **3334**: P2P node synchronization (optional)
- **8570**: JSON-RPC control plane (localhost only)

## Security Tips

1. **Backup Wallets**: Save `wallet.json` to USB drive
2. **Use Encryption**: For high-value wallets, use encrypted storage
3. **Firewall**: Only open port 3333 if you want external miners
4. **Private Keys**: Never share or paste private keys
5. **Passwords**: Use strong passwords (16+ characters) for encryption

## Performance Tips

1. **Multi-address Wallets**: Organize addresses by purpose (mining, trading, savings)
2. **Pool Window**: Larger window size (1000-2000) = more stable earnings
3. **P2P Network**: Connect to 3-10 peers for optimal sync speed
4. **Encryption**: Passwords only need to be entered once at startup

## Support & Resources

- **Documentation**: See `ADVANCED_FEATURES.md` for full API reference
- **Changelog**: See `CHANGELOG.md` for version history
- **Original README**: See `README.md` for core protocol details
- **Examples**: Check Python files in `derom/` directory for code examples

---

**Happy Mining! 🎉**

Questions? Check ADVANCED_FEATURES.md for detailed API documentation.
