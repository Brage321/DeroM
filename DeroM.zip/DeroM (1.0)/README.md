# DeroM (DEROM)

A simple, ASIC-mineable cryptocurrency that **works today**: full node +
stratum server + CLI wallet, all in one folder of readable Python.

- **Algorithm:** double-SHA-256 over Bitcoin's exact 80-byte header layout —
  the only format SHA-256 ASIC chips natively hash.
- **Solo stratum mining:** each miner's block reward is paid straight to the
  payout address in their username. No pool operator holds your coins.
- **Ledger:** account/balance model, secp256k1 ECDSA-signed spends.
- **Economics:** 50 DEROM per block, halving every 810,000 blocks,
  **max supply 81,000,000 DEROM**, ~5 min target block time with
  retargeting every 10 blocks.
- **No premine** — the genesis block pays nothing.

## Requirements

Python 3.9+ (`py` launcher on Windows) and one pure-Python dependency:

```
py -m pip install -r requirements.txt
```

> **Prefer clicking?** Double-click **`DeroM.bat`** for the control panel GUI,
> or run **`build_exe.bat`** once to produce a standalone **`DeroM.exe`**
> (~13 MB, no Python required on any PC you copy it to).

## Quickstart (3 terminals)

**1. Make your wallet**

```
py -m derom.wallet create          # writes wallet.json, prints your D... address
py -m derom.wallet address         # print it again any time
```

**2. Start the node**

```
start_node.bat                     # or: py -m derom.node
```

**3. Point your ASIC at it**

| Setting | Value |
|---|---|
| URL  | `stratum+tcp://derom.surge.sh:3333` |
| User | `<your wallet address>.worker1` |
| Pass | `x` |

That's it — every block your machine solves pays **50 DEROM directly to your
address**. Check earnings with:

```
py -m derom.wallet balance
```

Windows Firewall may prompt once for port 3333 — allow it for miners on your
LAN (or forward the port to go public).

## Test without hardware

```
py test_miner.py --user <ADDRESS>.worker1 --seconds 90
```

A CPU miner speaking the identical protocol — proves shares, blocks and
payouts work before you power up the rig.

## Sending coins

```
py derom\wallet.py send --to Dxxxxxxxx... --amount 5 --fee 0.001
```

Transactions wait in the mempool until the next block mines them.

## Difficulty notes

- `initial_difficulty` (config.json) sets the block-1 difficulty; the default
  `45000` targets ~5-minute blocks on a typical mid-range ASIC miner (~600 GH/s).
  Rule of thumb: `difficulty ≈ hashrate_H/s × block_time_s ÷ 2^32`
  (i.e. GH/s × 300 ÷ 4.295).
- Difficulty self-adjusts ×4 max every 10 blocks toward the 5-minute target,
  so being off at launch self-heals within a few hours.
- Per-worker share difficulty auto-tunes (vardiff) to ~15 s/share and never
  exceeds network difficulty.
- The 81M cap comes from the halving schedule itself:
  50 DEROM × 810,000 blocks × 2 = **81,000,000 DEROM** — forever.

## JSON-RPC (localhost:8570)

`getinfo`, `getblockcount`, `getdifficulty`, `getblock <h|hash>`,
`getbalance <addr>`, `getaccount <addr>`, `submittransaction [tx]`,
`getrawmempool`, `getmininginfo`, `getnetworkhashps`, `getblocktemplate`,
`submitblock [block]`, `stop`.

Example: `curl -X POST http://127.0.0.1:8570 -d "{\"method\":\"getinfo\"}"`

### For pool operators

DeroM exposes the two RPC endpoints standard pool software needs to offer
DEROM to its miners:

```bash
# Fetch a block template (height, previousblockhash, nbits, target,
# coinbasevalue, transactions). Build jobs from it exactly like you would
# for any getblocktemplate-compatible coin.
curl -X POST http://127.0.0.1:8570 -d '{"method":"getblocktemplate"}'

# Submit a solved block (full block JSON: hash, height, header, txs).
curl -X POST http://127.0.0.1:8570 \
     -d '{"method":"submitblock","params":[{"height":1,"header":{...},"txs":[...]}]}'
```

- **PoW** is plain double-SHA-256 over the 80-byte Bitcoin header layout
  (see `derom/block.py`) - any SHA-256 ASIC hashes it natively.
- **Payout addresses** are base58 `D...` addresses; the first 4 bytes of the
  address are a double-SHA-256 checksum (`ADDRESS_VERSION_BYTE = 0x1F`).
- **Block reward** (subsidy + fees) is returned as `coinbasevalue` in the
  template, so your coinbase can pay your own pool wallets.
- **Ports**: stratum `3333` (or `py -m derom.node` console), RPC `8570`.
- A reference miner (`py test_miner.py --user D....worker1 --seconds 90`)
  and the built-in stratum server double as a compatibility harness -
  run them against your pool implementation to verify share flow.

## Project layout

| Path | Purpose |
|---|---|
| `derom/crypto.py` | hashing, base58 addresses ('D' prefix), keys, nBits, merkle |
| `derom/block.py` | 80-byte header pack/unpack, stratum coinbase construction |
| `derom/tx.py` | coinbase/spend transactions, signatures, verification |
| `derom/chain.py` | validation, state, retargeting, persistence (`data/`) |
| `derom/mempool.py` | pending transactions |
| `derom/stratum.py` | ASIC-facing mining server (port 3333) |
| `derom/rpc.py` | HTTP JSON-RPC control plane (port 8570) |
| `derom/node.py` | entry point tying it together |
| `derom/wallet.py` | key management + payments |
| `derom/gui.py` | **[Legacy]** tkinter-based control panel |
| `derom/gui_qt.py` | **[New]** Modern PyQt5 control panel with tabs |
| `derom/multi_wallet.py` | **[New]** Multi-address wallet management |
| `derom/encryption.py` | **[New]** AES-256-GCM encrypted wallet storage |
| `derom/pool.py` | **[New]** PPLNS pool mode for shared mining |
| `derom/p2p.py` | **[New]** P2P node synchronization network |

## Enterprise Features (NEW)

### PyQt5 Modern GUI

Beautiful dark-themed interface with tabbed layout:
- **Node Status Tab**: Real-time blockchain statistics and node control
- **Wallets Tab**: Multi-address wallet management, encrypted storage
- **Block Explorer**: Search and inspect blocks, addresses, transactions
- **Settings Tab**: Configure pool, P2P, and difficulty parameters
- **Activity Log**: Complete operation history

Launch: `DeroM_Qt.bat` or `py -B -m derom.gui_qt`

**Build standalone executable:**
```bash
py -m pip install pyinstaller
build_exe_qt.bat
# Creates DeroM_Qt.exe (~50 MB with PyQt5)
```

### Multi-Address Wallets

Manage unlimited addresses in a single wallet:

```python
from derom.multi_wallet import MultiAddressWallet

wallet = MultiAddressWallet.create_new("my_wallet.json")
wallet.add_address(label="Primary")
wallet.add_address(label="Mining")
wallet.add_address(label="Savings")
wallet.save()

print(f"Total balance: {wallet.get_total_balance()}")
```

### Encrypted Wallets

Password-protected wallets with AES-256-GCM encryption:

```python
from derom.encryption import EncryptedWallet

wallet_data = {"address": "D...", "private_key": "..."}
encrypted = EncryptedWallet.encrypt_wallet(wallet_data, password="SecurePass123!")

# Decrypt later
wallet = EncryptedWallet.decrypt_wallet(encrypted, password="SecurePass123!")
```

**Features:**
- PBKDF2-SHA256 key derivation (100,000 iterations)
- Authenticated encryption (GCM mode)
- Tamper detection built-in
- ~100ms per decryption (intentional for security)

### PPLNS Pool Mode

Allow miners to pool resources and split block rewards:

```python
from derom.pool import PPLNSPool

pool = PPLNSPool("pool_config.json")

# Miners submit shares
result = pool.submit_share("D...", difficulty=256.0, block=False)

# When block found
if share_is_block:
    block_info = pool.on_block_found("D...")
    # Rewards automatically distributed to all contributors

# Pay miners
payouts = pool.process_payouts()
```

**Configuration:**
```json
{
    "pool_name": "My Pool",
    "pool_fee": 0.01,
    "window_size": 1000,
    "min_payout": 0.1
}
```

### P2P Network Sync

Connect multiple nodes for distributed chain synchronization:

```python
from derom.p2p import P2PNode

p2p = P2PNode("my-node", listen_port=3334)
p2p.add_peer("node2.example.com", 3334)
p2p.start()

# Broadcast new blocks
p2p.broadcast_block(block_data)

# Get network status
status = p2p.get_sync_status()
```

**Features:**
- Automatic peer discovery
- Block propagation (< 10s typical)
- Transaction relay
- Keep-alive ping/pong
- Configurable peer limits

## Advanced Features Documentation

See [ADVANCED_FEATURES.md](ADVANCED_FEATURES.md) for complete API reference and examples.

## ASIC miner troubleshooting

**The node now speaks "firmware-hardened" stratum**, but if your ASIC miners still
misbehaves, check these in order:

1. **URL:** `stratum+tcp://derom.surge.sh:3333` is the official mining hostname,
   but it only reaches this pool if that DNS name points at (or is forwarded to)
   the machine running your node. On a private LAN use the PC's LAN IP, e.g.
   `stratum+tcp://192.168.1.50:3333` (`localhost` will NOT work from a separate
   device).
2. **Username = your full wallet address + `.worker`**, e.g.
   `DbQYQzQ6y9aB5jvUDWhj3HU5mLLCX5rw35.worker1`. The part before the dot is
   where payouts go - if it's not a valid DeroM address the server rejects
   the login on purpose.
3. **Windows Firewall**: allow inbound TCP 3333 (the first launch usually
   prompts; pick "Allow" for Private networks).
4. Same router/subnet: the miner's WiFi and this PC must be able to reach each
   other (ping the PC's IP from another machine to confirm).
5. Watch the GUI **ACTIVITY** log or the node console - every connect,
   authorize, share and disconnect (with reason) is logged. If you see
   repeated connect/disconnect with 0 shares, it's almost always #1-#4.

Early in the chain's life network difficulty is tiny, so the server
automatically caps each worker's difficulty at the network level.
Your ASIC miner should show shares flowing within seconds of an accepted login.

## Roadmap - Completed ✓

- ✓ PPLNS pool payouts instead of solo
- ✓ P2P node sync so several machines share one chain
- ✓ Web dashboard / block explorer UI (in PyQt5 GUI)
- ✓ Encrypted wallet files, multi-address wallets

## Future Enhancements

- [ ] Peer reputation and scoring system
- [ ] Transaction fee market dynamics
- [ ] Atomic swaps between DeroM and other cryptocurrencies
- [ ] Lightning-like payment channels
- [ ] Hardware wallet integration (Ledger, Trezor)
- [ ] Cold storage security utilities
- [ ] Mobile wallet companion app
- [ ] Advanced analytics dashboard
- [ ] Fee-free multisig support
