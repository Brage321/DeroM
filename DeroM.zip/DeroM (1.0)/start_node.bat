@echo off
cd /d "%~dp0"
py -m derom.node %*
pause
