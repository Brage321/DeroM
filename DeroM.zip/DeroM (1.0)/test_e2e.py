"""Final end-to-end verification: node + mining + transactions + pool."""
import json
import os
import sys
import urllib.request

sys.argv = ['test']
os.chdir(os.path.dirname(os.path.abspath(__file__))) if os.path.dirname(os.path.abspath(__file__)) else None

from derom.node import NodeRunner, load_config
os.makedirs('data_test', exist_ok=True)
cfg = load_config('config.json', overrides={
    'data_dir': 'data_test',
    'stratum_port': 3334,
    'rpc_port': 8572,
    'initial_difficulty': 0.001,
    'debug_stratum': False,
})

def rpc_call(method, params=None):
    url = 'http://127.0.0.1:{}/'.format(cfg['rpc_port'])
    payload = json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method,
                          'params': params or []}).encode()
    req = urllib.request.Request(url, data=payload,
                                 headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=5) as resp:
        return json.loads(resp.read().decode())

runner = NodeRunner(cfg)
runner.start(timeout=60)
print('== Node up, height', runner.node.chain.height, '==')

ok = True

# 1. Mine a block with the CPU miner
with open('wallet.json') as f:
    wallet = json.load(f)
addr = wallet['address']
from derom.testminer import run_cpu_miner
res = run_cpu_miner('{}.final'.format(addr), seconds=8,
                    host='127.0.0.1', port=cfg['stratum_port'], log=print)
print('CPU miner:', res)
if runner.node.chain.height < 1:
    print('FAIL: no block mined'); ok = False

# 2. Verify balance
acct = rpc_call('getaccount', [addr])['result']
print('Balance after mining:', acct['balance'], 'atoms')
if acct['balance'] <= 0:
    print('FAIL: no balance'); ok = False

# 3. Create wallet2 and send a spend transaction via RPC (same flow wallet uses)
wallet2 = json.load(open('wallet2.json')) if os.path.exists('wallet2.json') else None
to_addr = wallet2['address'] if wallet2 else addr
priv = bytes.fromhex(wallet['private_key'])
# Wait for a second block so the mined reward is spendable via nonce tracking
res2 = run_cpu_miner('{}.final2'.format(addr), seconds=5,
                     host='127.0.0.1', port=cfg['stratum_port'], log=print)
print('Second miner run:', res2)

acct = rpc_call('getaccount', [addr])['result']
print('Balance after 2 blocks:', acct['balance'])

# Build + submit a spend
from derom import tx as txlib
amount = 100000  # 0.001 DEROM
fee = txlib.MIN_FEE_ATOMS
spend = txlib.make_spend(priv, to_addr, amount, fee, acct['next_nonce'])
tid = rpc_call('submittransaction', [spend])
print('submittransaction ->', tid)
if tid.get('error'):
    print('FAIL submit tx:', tid['error']); ok = False
else:
    mp = rpc_call('getrawmempool')['result']
    print('mempool size:', len(mp))
    if tid['result'] not in mp:
        print('FAIL: tx not in mempool'); ok = False

# 4. Pool round-trip
from derom.pool import PPLNSPool
import tempfile
with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
    pcfg = f.name
json.dump({'pool_name': 'E2E', 'window_size': 5, 'block_reward': 50 * 10**8,
           'pool_fee': 0.01, 'min_payout': 1}, open(pcfg, 'w'))
pool = PPLNSPool(pcfg)
pool.register_miner('Daddr1', 'w1')
pool.register_miner('Daddr2', 'w2')
for i in range(6):
    pool.submit_share('Daddr1', 2.0)
    pool.submit_share('Daddr2', 1.0)
blk_info = pool.on_block_found('Daddr1')
assert blk_info.get('payouts'), 'no payouts'
# Integer truncation of per-miner payouts leaves at most a few atoms of
# dust; payouts + fee must be within a small epsilon of the reward.
assert abs(sum(blk_info['payouts'].values()) + blk_info['fee']
           - blk_info['reward']) < len(blk_info['payouts']) * 2
stats = pool.get_pool_stats()
assert stats['total_miners'] == 2
print('Pool payout round-trip OK:', blk_info['payouts'])
for path in (pcfg, pcfg.replace('.json', '_accounts.json')):
    if os.path.exists(path):
        os.remove(path)

print()
print('FINAL RESULT:', 'ALL PASS' if ok else 'FAILURES PRESENT')
runner.stop()