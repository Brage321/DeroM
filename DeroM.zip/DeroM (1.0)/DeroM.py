"""DeroM - frozen application entry point (built by build_exe.bat or build_exe_qt.bat)."""
import multiprocessing
import os
import sys
import traceback


def _crash_log(exc: BaseException):
    try:
        path = os.path.join(os.path.dirname(sys.executable),
                            "DeroM_error.log")
        with open(path, "a", encoding="utf-8") as fh:
            fh.write("\n" + "=" * 60 + "\n")
            traceback.print_exception(type(exc), exc, exc.__traceback__,
                                      file=fh)
    except Exception:
        pass


def main():
    multiprocessing.freeze_support()      # required for frozen onefile apps
    try:
        # Try PyQt5 GUI first (modern interface)
        try:
            from derom.gui_qt import main as gui_main
            gui_main()
        except ImportError:
            # Fall back to tkinter GUI if PyQt5 not available
            from derom.gui import main as gui_main
            gui_main()
    except Exception as exc:              # noqa: BLE001 - last resort log
        _crash_log(exc)
        raise


if __name__ == "__main__":
    main()
