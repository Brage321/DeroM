"""DeroM CPU test miner - CLI wrapper.

Usage: py test_miner.py --user ADDRESS.worker1 --seconds 90
"""
import argparse

from derom.testminer import run_cpu_miner


def main():
    ap = argparse.ArgumentParser(description="DeroM CPU stratum test miner")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=3333)
    ap.add_argument("--user", required=True, help="ADDRESS.workername")
    ap.add_argument("--seconds", type=int, default=90)
    args = ap.parse_args()
    run_cpu_miner(args.user, seconds=args.seconds, host=args.host,
                  port=args.port, log=print, verbose=True)


if __name__ == "__main__":
    main()
