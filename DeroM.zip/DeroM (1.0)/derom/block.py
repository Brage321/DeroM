"""DeroM blocks: the 80-byte ASIC-compatible header + coinbase construction.

Header layout (identical to Bitcoin so SHA-256 ASICs can hash it natively):

    version     uint32 LE
    prev_hash   32 bytes  (parent block hash, byte-reversed on the wire)
    merkle_root 32 bytes  (byte-reversed on the wire)
    ntime       uint32 LE
    nbits       uint32 LE (compact encoded PoW target)
    nonce       uint32 LE

PoW = SHA256(SHA256(header)) interpreted little-endian must be <= target.
"""
import struct

from .crypto import merkle_branch, merkle_root_from_branch, sha256d

HEADER_SIZE = 80
# 0x20000000 (BIP9-style base version) - ASIC firmware stacks commonly
# normalize/stamp this version into jobs; advertising v1 causes a constant
# header mismatch where every firmware share fails pool-side reconstruction.
BLOCK_VERSION = 0x20000000
COINBASE_TAG = b"/DeroM/"


def pack_header(version: int, prev_hash_hex: str, merkle_hex: str,
                ntime: int, nbits: int, nonce: int) -> bytes:
    """Serialize the 80-byte header. `prev_hash_hex`/`merkle_hex` are
    display-order hex (reversed internally, Bitcoin wire convention)."""
    return (struct.pack("<I", version)
            + bytes.fromhex(prev_hash_hex)[::-1]
            + bytes.fromhex(merkle_hex)[::-1]
            + struct.pack("<III", ntime, nbits, nonce))


def unpack_header(raw: bytes) -> dict:
    if len(raw) != HEADER_SIZE:
        raise ValueError("header must be exactly 80 bytes")
    return {
        "version": struct.unpack("<I", raw[0:4])[0],
        "prev": raw[4:36][::-1].hex(),
        "merkle": raw[36:68][::-1].hex(),
        "ntime": struct.unpack("<I", raw[68:72])[0],
        "nbits": struct.unpack("<I", raw[72:76])[0],
        "nonce": struct.unpack("<I", raw[76:80])[0],
    }


def block_hash(header_raw: bytes) -> str:
    """Display-order hash hex of an 80-byte header."""
    return sha256d(header_raw)[::-1].hex()


def hash_display(digest: bytes) -> str:
    return digest[::-1].hex()


# ------------------------------------------------------- varint / scripts

def varint(n: int) -> bytes:
    if n < 0xFD:
        return bytes([n])
    if n <= 0xFFFF:
        return b"\xfd" + struct.pack("<H", n)
    return b"\xfe" + struct.pack("<I", n)


def p2pkh_script(h160: bytes) -> bytes:
    """Decorative pay-to-pubkey-hash output script (kept Bitcoin-shaped)."""
    return b"\x76\xa9\x14" + h160 + b"\x88\xac"


def address_to_script(address: str) -> bytes:
    from .crypto import b58check_decode
    payload = b58check_decode(address)
    return p2pkh_script(payload[1:])


# ------------------------------------------------------- coinbase (stratum)

def build_coinbase_parts(payout_address: str, value: int, height: int,
                         extranonce1_hex: str, extranonce2_hex: str,
                         tag: bytes = COINBASE_TAG):
    """Build the stratum coinbase transaction split around the extranonce
    region. Returns (coinbase1_hex, coinbase2_hex, coinbase_raw_bytes).

    scriptSig = [BIP34 height push][extranonce1+extranonce2][tag]
    """
    en1 = bytes.fromhex(extranonce1_hex)
    en2 = bytes.fromhex(extranonce2_hex)

    # BIP34-style minimal height push
    height_bytes = height.to_bytes((height.bit_length() + 7) // 8 or 1, "little")
    script_prefix = bytes([len(height_bytes)]) + height_bytes
    script_suffix = tag

    script_sig = script_prefix + en1 + en2 + script_suffix
    script_pubkey = address_to_script(payout_address)

    coinbase1 = (
        struct.pack("<I", BLOCK_VERSION)      # tx version
        + b"\x01"                             # input count
        + b"\x00" * 32                        # prevout hash (null)
        + b"\xff\xff\xff\xff"                 # prevout index (coinbase)
        + varint(len(script_sig))
        + script_prefix
    )
    coinbase2 = (
        script_suffix
        + b"\xff\xff\xff\xff"                 # sequence
        + b"\x01"                             # output count
        + struct.pack("<q", value)            # reward + fees
        + varint(len(script_pubkey)) + script_pubkey
        + b"\x00\x00\x00\x00"                 # locktime
    )
    return coinbase1.hex(), coinbase2.hex()
    # Full raw txn is assembled by assemble_coinbase_raw() joining the halves.


def assemble_coinbase_raw(coinbase1_hex: str, coinbase2_hex: str,
                          extranonce1_hex: str, extranonce2_hex: str) -> bytes:
    """Join the two halves with the miner-chosen extranonce values."""
    return (bytes.fromhex(coinbase1_hex)
            + bytes.fromhex(extranonce1_hex)
            + bytes.fromhex(extranonce2_hex)
            + bytes.fromhex(coinbase2_hex))


def coinbase_txid_digest(cb_raw: bytes) -> bytes:
    return sha256d(cb_raw)


def coinbase_merkle_root(cb_digest: bytes, extra_digests: list, en2_int: int) -> bytes:
    """Merkle root as compact stratum ASIC firmware commonly computes it:
    the coinbase folds as the leftmost leaf with index bits ALWAYS zero -
    no fold index is derived from extranonce2. So whatever `en2_int` is,
    the root must equal merkle_root([coinbase] + extras). With no extra
    txs the root is just the coinbase txid."""
    from .crypto import merkle_branch, merkle_root_from_branch
    base = [b"\x00" * 32] + list(extra_digests)
    branch = merkle_branch(base, 0)
    return merkle_root_from_branch(cb_digest, branch, 0)


# ------------------------------------------------------- job helpers

def merkle_for_job(coinbase_txid: bytes, extra_txids: list, en2_value: int):
    """Returns (root_display_hex, branch_display_hexes, index) for a job.
    The coinbase always sits at index 0 and the fold always uses index 0
    (stratum ASIC convention) - en2_value is accepted for API compatibility
    but never shifts the coinbase's position in the tree."""
    txids = [coinbase_txid] + extra_txids
    branch = merkle_branch(txids, 0)
    root = merkle_root_from_branch(coinbase_txid, branch, 0)
    return root.hex(), [b.hex() for b in branch], 0
