"""Multi-address wallet support for DeroM.

Allows managing multiple addresses/keypairs in a single wallet file.
"""
import json
import os
from typing import Dict, List, Any, Optional
from datetime import datetime

from .crypto import (generate_privkey, privkey_to_address,
                     privkey_to_pubkey, address_is_valid)


class MultiAddressWallet:
    """Manage multiple addresses in a single wallet."""
    
    def __init__(self, wallet_path: str):
        self.wallet_path = wallet_path
        self.data: Dict[str, Any] = {
            "version": "2.0",  # Multi-address version
            "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "name": "Default Multi-Wallet",
            "addresses": [],  # List of address objects
            "default_address": None,
        }
    
    def load(self) -> bool:
        """Load wallet from file."""
        if not os.path.exists(self.wallet_path):
            return False
        
        try:
            with open(self.wallet_path, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
            return True
        except Exception as e:
            print(f"Error loading wallet: {e}")
            return False
    
    def save(self) -> bool:
        """Save wallet to file."""
        try:
            tmp = self.wallet_path + ".tmp"
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, indent=2)
            os.replace(tmp, self.wallet_path)
            try:
                os.chmod(self.wallet_path, 0o600)
            except OSError:
                pass
            return True
        except Exception as e:
            print(f"Error saving wallet: {e}")
            return False
    
    def add_address(self, label: str = "", is_default: bool = False) -> Optional[str]:
        """Generate and add a new address to the wallet.
        
        Args:
            label: Human-readable label for this address
            is_default: Make this the default address
            
        Returns:
            The new address, or None if failed
        """
        try:
            priv = generate_privkey()
            address = privkey_to_address(priv)
            
            addr_obj = {
                "address": address,
                "private_key": priv.hex(),
                "public_key": privkey_to_pubkey(priv).hex(),
                "label": label,
                "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "balance": 0,
                "transactions": 0,
            }
            
            self.data["addresses"].append(addr_obj)
            
            if is_default or self.data["default_address"] is None:
                self.data["default_address"] = address
            
            return address
        except Exception as e:
            print(f"Error adding address: {e}")
            return None
    
    def import_address(self, private_key_hex: str, label: str = "", 
                      is_default: bool = False) -> Optional[str]:
        """Import an existing private key.
        
        Args:
            private_key_hex: Hex-encoded private key
            label: Human-readable label
            is_default: Make this the default address
            
        Returns:
            The imported address, or None if invalid
        """
        try:
            priv = bytes.fromhex(private_key_hex)
            address = privkey_to_address(priv)
            
            # Check if already exists
            for addr_obj in self.data["addresses"]:
                if addr_obj["address"] == address:
                    return address  # Already in wallet
            
            addr_obj = {
                "address": address,
                "private_key": private_key_hex,
                "public_key": privkey_to_pubkey(priv).hex(),
                "label": label or f"Imported {address[:8]}...",
                "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "balance": 0,
                "transactions": 0,
            }
            
            self.data["addresses"].append(addr_obj)
            
            if is_default or self.data["default_address"] is None:
                self.data["default_address"] = address
            
            return address
        except Exception as e:
            print(f"Error importing address: {e}")
            return None
    
    def remove_address(self, address: str) -> bool:
        """Remove an address from the wallet.
        
        Args:
            address: Address to remove
            
        Returns:
            True if successful, False otherwise
        """
        original_count = len(self.data["addresses"])
        self.data["addresses"] = [
            a for a in self.data["addresses"] if a["address"] != address
        ]
        
        if len(self.data["addresses"]) < original_count:
            # Address was removed
            if self.data["default_address"] == address:
                # Reset default to first remaining address
                self.data["default_address"] = (
                    self.data["addresses"][0]["address"]
                    if self.data["addresses"] else None
                )
            return True
        
        return False
    
    def get_address(self, address: str) -> Optional[Dict[str, Any]]:
        """Get a specific address object."""
        for addr_obj in self.data["addresses"]:
            if addr_obj["address"] == address:
                return addr_obj
        return None
    
    def get_default_address(self) -> Optional[str]:
        """Get the default address."""
        return self.data.get("default_address")
    
    def set_default_address(self, address: str) -> bool:
        """Set the default address."""
        if address_is_valid(address):
            if self.get_address(address):
                self.data["default_address"] = address
                return True
        return False
    
    def list_addresses(self) -> List[Dict[str, Any]]:
        """Get all addresses in the wallet."""
        return self.data.get("addresses", [])
    
    def get_address_count(self) -> int:
        """Get number of addresses in wallet."""
        return len(self.data.get("addresses", []))
    
    def update_balance(self, address: str, balance: int, tx_count: int = None) -> bool:
        """Update balance/transaction count for an address.
        
        Args:
            address: Address to update
            balance: Balance in atoms
            tx_count: Number of transactions (optional)
            
        Returns:
            True if successful
        """
        addr_obj = self.get_address(address)
        if addr_obj:
            addr_obj["balance"] = balance
            if tx_count is not None:
                addr_obj["transactions"] = tx_count
            return True
        return False
    
    def update_label(self, address: str, label: str) -> bool:
        """Update the label for an address."""
        addr_obj = self.get_address(address)
        if addr_obj:
            addr_obj["label"] = label
            return True
        return False
    
    def get_total_balance(self) -> int:
        """Get total balance across all addresses (in atoms)."""
        return sum(addr.get("balance", 0) for addr in self.data.get("addresses", []))
    
    def export_backup(self, backup_path: str) -> bool:
        """Create a backup of the wallet file."""
        try:
            import shutil
            shutil.copy2(self.wallet_path, backup_path)
            try:
                os.chmod(backup_path, 0o600)
            except OSError:
                pass
            return True
        except Exception as e:
            print(f"Error creating backup: {e}")
            return False
    
    def to_dict(self) -> Dict[str, Any]:
        """Get wallet as dictionary."""
        return self.data.copy()
    
    @staticmethod
    def create_new(wallet_path: str, name: str = "Default Multi-Wallet") -> 'MultiAddressWallet':
        """Create a new multi-address wallet.
        
        Args:
            wallet_path: Path to save wallet file
            name: Wallet name
            
        Returns:
            New MultiAddressWallet instance
        """
        wallet = MultiAddressWallet(wallet_path)
        wallet.data["name"] = name
        wallet.add_address(label="Primary Address", is_default=True)
        wallet.save()
        return wallet
