"""DeroM in-memory transaction pool."""
import threading
from collections import OrderedDict

from . import tx as txlib


class MemPool:
    """Holds verified spend transactions waiting for a block."""

    def __init__(self, max_size: int = 5000):
        self.max_size = max_size
        self._txs = OrderedDict()          # txid hex -> tx dict
        self.lock = threading.RLock()

    def add(self, tx: dict) -> str:
        """Add a spend transaction. Returns "" on success, else an error."""
        if tx.get("type") != txlib.SPEND:
            return "only spend transactions enter the mempool"
        tid = txlib.txid(tx)
        with self.lock:
            if tid in self._txs:
                return "already in mempool"
            if len(self._txs) >= self.max_size:
                lowest_id = min(self._txs, key=lambda k: self._txs[k]["fee"])
                if self._txs[lowest_id]["fee"] >= tx["fee"]:
                    return "mempool full (fee too low)"
                del self._txs[lowest_id]
            self._txs[tid] = tx
        return ""

    def remove_txids(self, txid_hexes) -> None:
        with self.lock:
            for tid in txid_hexes:
                self._txs.pop(tid, None)

    def by_fee_desc(self) -> list:
        with self.lock:
            return sorted(self._txs.values(), key=lambda t: t["fee"], reverse=True)

    def size(self) -> int:
        with self.lock:
            return len(self._txs)

    def clear(self) -> None:
        with self.lock:
            self._txs.clear()
