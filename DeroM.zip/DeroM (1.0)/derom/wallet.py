"""DeroM command-line wallet.

Run with:  py -m derom.wallet <command>   (from the project root)
Wallet file holds ONE private key (plain JSON - keep the file safe).

Commands:
    create                     generate wallet.json and print address
    address                    print the wallet address
    export                     print private key (handle with care)
    balance                    query balance via node RPC
    send --to ADDR --amount N [--fee F]
"""
import argparse
import json
import os
import sys
import time
import urllib.request

from . import __version__, tx as txlib
from .crypto import (generate_privkey, privkey_to_address,
                     privkey_to_pubkey)


def wallet_path(args):
    path = args.wallet or "wallet.json"
    return path


def load_wallet(path):
    if not os.path.exists(path):
        sys.exit(f"no wallet at {path} - run: py -m derom.wallet create")
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def save_wallet(path, data):
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
    try:
        os.chmod(path, 0o600)  # best-effort on Windows
    except OSError:
        pass


def rpc(cfg_path, method, params=None):
    cfg = {}
    if cfg_path and os.path.exists(cfg_path):
        with open(cfg_path, "r", encoding="utf-8") as fh:
            cfg = json.load(fh)
    url = f"http://{cfg.get('rpc_host', '127.0.0.1')}:{cfg.get('rpc_port', 8570)}/"
    payload = json.dumps({"jsonrpc": "2.0", "id": 1,
                          "method": method, "params": params or []}).encode()
    req = urllib.request.Request(url, data=payload,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        body = json.loads(resp.read().decode())
    if body.get("error"):
        raise RuntimeError(f"node error: {body['error']}")
    return body.get("result")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="derom-wallet")
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--wallet", default="wallet.json")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("create")
    sub.add_parser("address")
    sub.add_parser("export")

    bal = sub.add_parser("balance")
    bal.add_argument("--address", default=None, help="check any address")

    snd = sub.add_parser("send")
    snd.add_argument("--to", required=True)
    snd.add_argument("--amount", type=float, required=True)
    snd.add_argument("--fee", type=float, default=0.001)

    args = ap.parse_args(argv)

    if args.cmd == "create":
        if os.path.exists(wallet_path(args)):
            sys.exit(f"refusing to overwrite {args.wallet}")
        priv = generate_privkey()
        addr = privkey_to_address(priv)
        save_wallet(args.wallet, {
            "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "version": __version__,
            "private_key": priv.hex(),
            "public_key": privkey_to_pubkey(priv).hex(),
            "address": addr,
        })
        print(f"wallet written to {args.wallet}  (BACK IT UP - it holds your key)")
        print(f"address: {addr}")
        return

    w = load_wallet(wallet_path(args))

    if args.cmd == "address":
        print(w["address"])
    elif args.cmd == "export":
        print("private key:", w["private_key"])
        print("address    :", w["address"])
    elif args.cmd == "balance":
        addr = args.address or w["address"]
        acct = rpc(args.config, "getaccount", [addr])
        atoms = acct["balance"]
        print(f"{addr}")
        print(f"balance: {atoms / txlib.ATOMS_PER_DEROM:g} DEROM "
              f"({atoms} atoms), next_nonce={acct['next_nonce']}")
    elif args.cmd == "send":
        amount = int(round(args.amount * txlib.ATOMS_PER_DEROM))
        fee = max(int(round(args.fee * txlib.ATOMS_PER_DEROM)),
                  txlib.MIN_FEE_ATOMS)
        acct = rpc(args.config, "getaccount", [w["address"]])
        tx = txlib.make_spend(bytes.fromhex(w["private_key"]), args.to,
                              amount, fee, acct["next_nonce"])
        tid = rpc(args.config, "submittransaction", [tx])
        print(f"submitted {tid}")
        print(f"{args.amount:g} DEROM -> {args.to} (fee {args.fee:g}); "
              f"waits in mempool until the next block mines it")


if __name__ == "__main__":
    main()
