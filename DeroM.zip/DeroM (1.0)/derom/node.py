"""DeroM node - CLI entry point AND embeddable background runner.

The GUI (and the frozen .exe) run the node via NodeRunner on a worker
thread; `py -m derom.node` still works as a plain console daemon.
"""
import argparse
import asyncio
import json
import os
import sys
import threading
import time

from . import __version__, tx as txlib
from .chain import Chain
from .mempool import MemPool
from .rpc import RpcServer
from .stratum import StratumServer

DEFAULTS = {
    "ticker": "DEROM",
    "data_dir": "./data",
    "stratum_host": "0.0.0.0",
    "stratum_port": 3333,
    "rpc_host": "127.0.0.1",
    "rpc_port": 8570,
    "initial_difficulty": 0.001,
    "block_time_seconds": 60,
    "retarget_interval_blocks": 10,
    "max_retarget_adjust": 4.0,
    "reward_atoms": 5000000000,
    "halving_interval": 210000,
    # >=1 keeps ASIC control boards happy: most parse mining.set_difficulty
    # as an integer and silently produce zero hashes on fractional values.
    "default_share_difficulty": 5.0,
    "vardiff_min": 1.0,
    "vardiff_max": 500000.0,
    "debug_stratum": False,
}

# Where wallets/config/data live: next to the .exe when frozen, else project root
APP_DIR = (os.path.dirname(sys.executable) if getattr(sys, "frozen", False)
           else os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def load_config(config_path="config.json", overrides=None):
    cfg = dict(DEFAULTS)
    path = (config_path if os.path.isabs(config_path)
            else os.path.join(APP_DIR, config_path))
    if os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            cfg.update(json.load(fh))
    cfg.update({k: v for k, v in (overrides or {}).items() if v is not None})
    datadir = str(cfg.get("data_dir", "./data"))
    if not os.path.isabs(datadir):
        cfg["data_dir"] = os.path.join(APP_DIR, datadir)
    return cfg


def ensure_default_config(path=None):
    path = path or os.path.join(APP_DIR, "config.json")
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(DEFAULTS, fh, indent=2)
    return path


class Node:
    def __init__(self, cfg):
        self.cfg = cfg
        self.version = __version__
        self.chain = None
        self.mempool = None
        self.stratum = None
        self.rpc = None
        self._loop = None

    def log(self, msg):
        print(time.strftime("[%H:%M:%S] ") + msg, flush=True)

    def miner_count(self):
        return self.stratum.miner_count() if self.stratum else 0

    def on_new_tip(self, block):
        self.mempool.remove_txids([txlib.txid(t) for t in block["txs"][1:]])

    def request_shutdown(self):
        stratum = self.stratum
        loop = self._loop
        if stratum is not None and getattr(stratum, "server", None):
            try:
                stratum.server.close()
            except Exception:
                pass
        if stratum is not None and loop is not None and loop.is_running():
            try:
                loop.call_soon_threadsafe(stratum.cancel_background_tasks)
            except RuntimeError:
                pass
        if loop is not None and loop.is_running():
            loop.call_soon_threadsafe(loop.stop)


def build_node(cfg):
    """Wire up chain + mempool + stratum + rpc for a config dict."""
    node = Node(cfg)
    os.makedirs(cfg["data_dir"], exist_ok=True)
    node.log(f"DeroM node v{__version__}  "
             f"datadir={os.path.abspath(cfg['data_dir'])}")
    t0 = time.time()
    node.chain = Chain.load_or_create(cfg, cfg["data_dir"])
    info = node.chain.info()
    node.log(f"chain ready in {time.time() - t0:.1f}s  height={info['height']}"
             f"  tip={str(info['tip'])[:20]}..")
    node.log(f"difficulty={info['difficulty']}  block_reward="
             f"{info['next_reward_atoms'] / txlib.ATOMS_PER_DEROM:g} {cfg['ticker']}")

    node.mempool = MemPool()
    node.stratum = StratumServer(node)
    node.rpc = RpcServer(node)
    bind = node.rpc.start()
    node.log(f"[rpc] http://{bind[0]}:{bind[1]}")
    return node


class NodeRunner:
    """Runs a full node on a daemon thread - GUI / exe friendly."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.node = None
        self.thread = None
        self.loop = None

    def start(self, timeout=60):
        ready = threading.Event()
        self.node = build_node(self.cfg)

        def run():
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)
            self.node._loop = self.loop
            try:
                server = self.loop.run_until_complete(
                    self.node.stratum.make_server())
            except Exception as exc:  # noqa: BLE001 - surfaced via ready()
                self.node.log(f"[node] stratum failed to start: {exc}")
                ready.set()
                return
            ready.set()
            try:
                self.loop.run_until_complete(server.serve_forever())
            except (asyncio.CancelledError, RuntimeError):
                # CancelledError = normal shutdown; RuntimeError covers
                # "event loop stopped before Future completed" when the RPC
                # stop request halts a loop that is actively serving.
                pass
            finally:
                self._close_loop_cleanly()

        self.thread = threading.Thread(target=run, name="derom-node",
                                       daemon=True)
        self.thread.start()
        if not ready.wait(timeout):
            raise RuntimeError("node did not start in time "
                               "(port already in use?)")
        if self.node.stratum.server is None:
            raise RuntimeError("node failed to bind the stratum port")
        return self.node.stratum.server

    def _close_loop_cleanly(self):
        # Cancel leftover housekeeping tasks (ntime refresh etc.) and let
        # them finish so loop.close() does not warn about pending futures.
        pending = [t for t in asyncio.all_tasks(self.loop) if not t.done()]
        for t in pending:
            t.cancel()
        if pending:
            try:
                self.loop.run_until_complete(
                    asyncio.gather(*pending, return_exceptions=True))
            except Exception:
                pass
        try:
            self.loop.close()
        except Exception:
            pass

    def stop(self):
        node = self.node
        if node is None:
            return
        node.request_shutdown()
        loop = self.loop
        if loop is not None and loop.is_running():
            try:
                loop.call_soon_threadsafe(loop.stop)
            except RuntimeError:
                pass
        if self.thread is not None:
            self.thread.join(timeout=8)
        try:
            node.rpc.stop()
        except Exception:
            pass


def main(argv=None):
    ap = argparse.ArgumentParser(prog="derom-node",
                                 description="DeroM full node + stratum server")
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--datadir", default=None)
    ap.add_argument("--stratum-port", type=int, default=None)
    ap.add_argument("--rpc-port", type=int, default=None)
    ap.add_argument("--initial-difficulty", type=float, default=None,
                    help="set BEFORE first launch to pre-tune for hashrate")
    args = ap.parse_args(argv)

    ensure_default_config(os.path.join(APP_DIR, "config.json"))
    cfg = load_config(args.config, {
        "data_dir": args.datadir,
        "stratum_port": args.stratum_port,
        "rpc_port": args.rpc_port,
        "initial_difficulty": args.initial_difficulty,
    })

    runner = NodeRunner(cfg)
    runner.start()
    node = runner.node

    bar = "=" * 64
    print(bar)
    print(" CONNECT YOUR ASIC / MINER")
    print("   URL  : stratum+tcp://derom.surge.sh:3333   (LAN: stratum+tcp://<PC_IP>:3333)")
    print("   User : <your wallet address>.worker1     Pass: x")
    print(" GUI   : py -m derom.gui      (or DeroM.bat / DeroM.exe)")
    print(bar, flush=True)

    try:
        while runner.thread.is_alive():
            runner.thread.join(1)
    except KeyboardInterrupt:
        print(file=sys.stderr)
    finally:
        runner.stop()
        node.log("shutdown complete")


if __name__ == "__main__":
    main()