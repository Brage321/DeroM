"""DeroM Qt Control Panel - modern PyQt5 wallet, node manager, block explorer.

Launch:  py -B -m derom.gui_qt       (or DeroM_Qt.bat)
Modern, tabbed interface with block explorer and advanced wallet features.
"""
import datetime
import json
import os
import shutil
import socket
import sys
import threading
import urllib.request
from typing import Optional, Dict, List, Any
from pathlib import Path

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QLineEdit, QTextEdit, QTabWidget, QTableWidget,
    QTableWidgetItem, QMessageBox, QFileDialog, QProgressDialog, QComboBox,
    QSpinBox, QDoubleSpinBox, QCheckBox, QDialog, QFormLayout, QInputDialog,
    QDialogButtonBox, QSplitter, QFrame, QScrollArea
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer, QSize, QRect
from PyQt5.QtGui import QIcon, QFont, QColor, QPixmap, QTextCursor, QBrush
from PyQt5.QtChart import QChart, QChartView, QLineSeries

from . import __version__, tx as txlib
from .crypto import (address_is_valid, generate_privkey,
                     privkey_to_address, privkey_to_pubkey)
from .node import (APP_DIR as ROOT_DIR, NodeRunner, ensure_default_config,
                   load_config as _load_node_config)

WALLET_PATH = os.path.join(ROOT_DIR, "wallet.json")
CONFIG_PATH = os.path.join(ROOT_DIR, "config.json")
DATA_DIR = os.path.join(ROOT_DIR, "data")

# Modern color scheme (GitHub Dark)
COLORS = {
    "bg": "#0d1117",
    "panel": "#161b22",
    "border": "#30363d",
    "fg": "#e6edf3",
    "dim": "#9aa4b2",
    "muted": "#6e7681",
    "green": "#3fb950",
    "blue": "#4493f8",
    "gold": "#d29922",
    "red": "#f85149",
    "orange": "#fb8500",
    "btn": "#21262d",
    "btn_hover": "#2f3742",
}

FONTS = {
    "mono": ("Consolas", 10),
    "ui": ("Segoe UI", 10),
    "ui_b": ("Segoe UI", 10, "bold"),
    "h1": ("Segoe UI", 16, "bold"),
    "h2": ("Segoe UI", 11, "bold"),
    "h3": ("Segoe UI", 10, "bold"),
}


def load_config():
    return _load_node_config(CONFIG_PATH)


CFG = load_config()
RPC_PORT = int(CFG.get("rpc_port", 8570))
STRATUM_PORT = int(CFG.get("stratum_port", 3333))
TICKER = CFG.get("ticker", "DEROM")
RPC_URL = f"http://127.0.0.1:{RPC_PORT}/"


def rpc(method, params=None, timeout=4):
    """Call JSON-RPC method on node."""
    payload = json.dumps({"id": 1, "method": method,
                          "params": list(params or [])}).encode()
    req = urllib.request.Request(
        RPC_URL, data=payload, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = json.loads(resp.read().decode())
    if body.get("error"):
        raise RuntimeError(str(body["error"]))
    return body["result"]


def local_ip():
    """Best-effort LAN IP for stratum URL."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def fmt_coins(atoms):
    """Format atoms to DEROM with proper precision."""
    return f"{atoms / txlib.ATOMS_PER_DEROM:,.8f}".rstrip("0").rstrip(".")


def load_wallet_file(path=WALLET_PATH) -> Optional[Dict[str, Any]]:
    """Load wallet JSON file."""
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def save_wallet_file(data, path=WALLET_PATH):
    """Save wallet JSON file safely."""
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


class NodeWorker(QThread):
    """Background thread for node operations."""
    status_changed = pyqtSignal(dict)  # {"height", "difficulty", "miners", "mempool", "reward"}
    error_occurred = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.is_running = True

    def run(self):
        while self.is_running:
            try:
                info = rpc("getinfo", timeout=1.5)
                self.status_changed.emit(info)
            except Exception as e:
                self.error_occurred.emit(str(e))
            self.msleep(2000)

    def stop(self):
        self.is_running = False


class BlockExplorerWidget(QWidget):
    """Block explorer and chain statistics."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.refresh_blocks)
        self.update_timer.start(5000)

    def init_ui(self):
        layout = QVBoxLayout()

        # Search bar
        search_layout = QHBoxLayout()
        search_layout.addWidget(QLabel("Search Block/TX/Address:"))
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Block height, hash, or address...")
        search_layout.addWidget(self.search_input)
        search_btn = QPushButton("Search")
        search_btn.clicked.connect(self.search_chain)
        search_layout.addWidget(search_btn)
        layout.addLayout(search_layout)

        # Recent blocks table
        layout.addWidget(QLabel("Recent Blocks:"))
        self.blocks_table = QTableWidget()
        self.blocks_table.setColumnCount(6)
        self.blocks_table.setHorizontalHeaderLabels([
            "Height", "Hash", "Miner", "Reward", "Time", "Txs"
        ])
        self.blocks_table.setMaximumHeight(300)
        layout.addWidget(self.blocks_table)

        # Block details
        layout.addWidget(QLabel("Block Details:"))
        self.details_text = QTextEdit()
        self.details_text.setReadOnly(True)
        self.details_text.setMaximumHeight(250)
        layout.addWidget(self.details_text)

        self.setLayout(layout)

    def refresh_blocks(self):
        """Fetch and display recent blocks."""
        try:
            height = rpc("getblockcount")
            self.blocks_table.setRowCount(0)
            
            # Show last 10 blocks
            for i in range(max(0, height - 9), height + 1):
                block = rpc("getblock", [i])
                txs = block.get("txs", [])
                cb = txs[0] if txs else {}
                header = block.get("header", {})
                row = self.blocks_table.rowCount()
                self.blocks_table.insertRow(row)

                self.blocks_table.setItem(row, 0, QTableWidgetItem(str(i)))
                self.blocks_table.setItem(row, 1, QTableWidgetItem(block.get("hash", "")[:16]))
                self.blocks_table.setItem(row, 2, QTableWidgetItem(cb.get("to", "")[:16]))
                self.blocks_table.setItem(row, 3, QTableWidgetItem(fmt_coins(cb.get("amount", 0))))
                self.blocks_table.setItem(row, 4, QTableWidgetItem(
                    datetime.datetime.fromtimestamp(header.get("ntime", 0)).strftime("%H:%M:%S")
                ))
                self.blocks_table.setItem(row, 5, QTableWidgetItem(str(len(txs))))
        except Exception as e:
            self.details_text.setText(f"Error loading blocks: {e}")

    def search_chain(self):
        """Search for block, tx, or address."""
        query = self.search_input.text().strip()
        if not query:
            return
        
        self.details_text.clear()
        try:
            # Try block height
            if query.isdigit():
                block = rpc("getblock", [int(query)])
                self.display_block(block)
                return
            
            # Try address balance
            if query.startswith("D"):
                account = rpc("getaccount", [query])
                self.display_account(query, account)
                return
            
            self.details_text.setText("Not found: try block height or D... address")
        except Exception as e:
            self.details_text.setText(f"Error: {e}")

    def display_block(self, block):
        """Display block details."""
        txs = block.get("txs", []) or []
        cb = txs[0] if txs else {}
        header = block.get("header", {}) or {}
        ntime = header.get("ntime", 0)
        time_str = (datetime.datetime.fromtimestamp(ntime).strftime("%Y-%m-%d %H:%M:%S")
                    if ntime else "—")
        nbits = header.get("nbits")
        nbits_str = ("0x%08x" % nbits) if nbits is not None else "—"
        text = (
            f"Height: {block.get('height')}\n"
            f"Hash: {block.get('hash')}\n"
            f"Prev: {header.get('prev', '—')}\n"
            f"Merkle: {header.get('merkle', '—')}\n"
            f"Miner: {cb.get('to', '—')}\n"
            f"Reward: {fmt_coins(cb.get('amount', 0))}\n"
            f"nBits: {nbits_str}\n"
            f"Timestamp: {time_str}\n"
            f"Transactions: {len(txs)}\n"
            f"Nonce: {header.get('nonce', '—')}\n"
        )
        self.details_text.setText(text)

    def display_account(self, address, account):
        """Display account details."""
        text = (
            f"Address: {address}\n"
            f"Balance: {fmt_coins(account.get('balance', 0))}\n"
            f"Nonce: {account.get('next_nonce', 0)}\n"
            f"Transactions: {account.get('tx_count', 0)}\n"
        )
        self.details_text.setText(text)


class WalletWidget(QWidget):
    def display_account(self, address, account):
        """Display account details."""
        text = (
            f"Address: {address}\n"
            f"Balance: {fmt_coins(account.get('balance', 0))}\n"
            f"Nonce: {account.get('nonce', 0)}\n"
            f"Next nonce: {account.get('next_nonce', 1)}\n"
        )
        self.details_text.setText(text)

    def init_ui(self):
        layout = QVBoxLayout()

        # Wallet selector
        sel_layout = QHBoxLayout()
        sel_layout.addWidget(QLabel("Active Wallet:"))
        self.wallet_combo = QComboBox()
        self.wallet_combo.currentTextChanged.connect(self.on_wallet_changed)
        sel_layout.addWidget(self.wallet_combo)
        
        new_btn = QPushButton("New Wallet")
        new_btn.clicked.connect(self.create_wallet)
        sel_layout.addWidget(new_btn)
        
        import_btn = QPushButton("Import")
        import_btn.clicked.connect(self.import_wallet)
        sel_layout.addWidget(import_btn)
        
        layout.addLayout(sel_layout)

        # Address display
        layout.addWidget(QLabel("Address:"))
        self.addr_display = QLineEdit()
        self.addr_display.setReadOnly(True)
        layout.addWidget(self.addr_display)

        # Balance
        layout.addWidget(QLabel("Balance:"))
        self.balance_label = QLabel("-- --")
        balance_font = QFont("Segoe UI", 16)
        balance_font.setBold(True)
        self.balance_label.setFont(balance_font)
        self.balance_label.setStyleSheet(f"color: {COLORS['green']};")
        layout.addWidget(self.balance_label)

        # Actions
        actions_layout = QHBoxLayout()
        copy_btn = QPushButton("Copy Address")
        copy_btn.clicked.connect(self.copy_address)
        actions_layout.addWidget(copy_btn)
        
        backup_btn = QPushButton("Backup")
        backup_btn.clicked.connect(self.backup_wallet)
        actions_layout.addWidget(backup_btn)
        
        export_btn = QPushButton("Export Key")
        export_btn.clicked.connect(self.export_key)
        actions_layout.addWidget(export_btn)
        
        layout.addLayout(actions_layout)

        # Multi-address list
        layout.addWidget(QLabel("Addresses in this wallet:"))
        self.addresses_table = QTableWidget()
        self.addresses_table.setColumnCount(3)
        self.addresses_table.setHorizontalHeaderLabels(["Address", "Balance", "Transactions"])
        self.addresses_table.setMaximumHeight(200)
        layout.addWidget(self.addresses_table)

        layout.addStretch()
        self.setLayout(layout)

    def load_wallets(self):
        """Load all available wallets."""
        wallet = load_wallet_file()
        if wallet:
            self.wallets["Default"] = wallet
            self.wallet_combo.addItem("Default")
        
        # Look for additional wallet files
        wallet_dir = ROOT_DIR
        for file in os.listdir(wallet_dir):
            if file.startswith("wallet") and file.endswith(".json") and file != "wallet.json":
                try:
                    path = os.path.join(wallet_dir, file)
                    w = load_wallet_file(path)
                    if w:
                        name = file.replace("wallet_", "").replace(".json", "")
                        self.wallets[name] = w
                        self.wallet_combo.addItem(name)
                except Exception:
                    pass

    def on_wallet_changed(self, name: str):
        """Switch to a different wallet."""
        if name in self.wallets:
            self.current_wallet = self.wallets[name]
            self.addr_display.setText(self.current_wallet.get("address", ""))
            self.update_balance()
            self.update_addresses_table()

    def update_balance(self):
        """Fetch and display balance."""
        if not self.current_wallet:
            return
        try:
            account = rpc("getaccount", [self.current_wallet["address"]])
            balance = fmt_coins(account.get("balance", 0))
            self.balance_label.setText(f"{balance} {TICKER}")
        except Exception as e:
            self.balance_label.setText(f"Error: {str(e)[:20]}")

    def update_addresses_table(self):
        """Update addresses table."""
        if not self.current_wallet:
            return
        self.addresses_table.setRowCount(1)
        addr = self.current_wallet.get("address", "")
        self.addresses_table.setItem(0, 0, QTableWidgetItem(addr))
        
        try:
            account = rpc("getaccount", [addr])
            self.addresses_table.setItem(0, 1, QTableWidgetItem(fmt_coins(account.get("balance", 0))))
            self.addresses_table.setItem(0, 2, QTableWidgetItem(str(account.get("tx_count", 0))))
        except Exception:
            pass

    def copy_address(self):
        """Copy address to clipboard."""
        addr = self.addr_display.text()
        if addr:
            QApplication.clipboard().setText(addr)
            # TODO: Show toast notification
            print(f"Copied: {addr}")

    def backup_wallet(self):
        """Backup wallet file."""
        if not self.current_wallet:
            QMessageBox.warning(self, "No Wallet", "Select a wallet first")
            return
        
        path, _ = QFileDialog.getSaveFileName(
            self, "Backup Wallet", "wallet_backup.json",
            "JSON Files (*.json);;All Files (*)"
        )
        if path:
            try:
                shutil.copy2(WALLET_PATH, path)
                os.chmod(path, 0o600)
                QMessageBox.information(self, "Success", f"Wallet backed up to {path}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Backup failed: {e}")

    def export_key(self):
        """Export private key (with warning)."""
        if not self.current_wallet:
            return
        
        reply = QMessageBox.warning(
            self, "Export Private Key",
            "WARNING: This will display your private key.\n"
            "Only do this if you trust this computer.\n\n"
            "Continue?",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            key = self.current_wallet.get("private_key", "")
            msg = QMessageBox.information(self, "Private Key", f"Key:\n{key}\n\n(Copied to clipboard)")
            QApplication.clipboard().setText(key)

    def create_wallet(self):
        """Create a new wallet."""
        reply = QMessageBox.question(
            self, "Create Wallet",
            "Generate a new wallet?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return
        
        priv = generate_privkey()
        data = {
            "created": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "version": __version__,
            "private_key": priv.hex(),
            "public_key": privkey_to_pubkey(priv).hex(),
            "address": privkey_to_address(priv),
        }
        
        # Save as wallet.json or wallet_new_*.json
        if not os.path.exists(WALLET_PATH):
            save_wallet_file(data, WALLET_PATH)
            name = "Default"
        else:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            path = os.path.join(ROOT_DIR, f"wallet_{timestamp}.json")
            save_wallet_file(data, path)
            name = timestamp
        
        self.wallets[name] = data
        self.wallet_combo.addItem(name)
        self.wallet_combo.setCurrentText(name)
        QMessageBox.information(self, "Success", f"Wallet created:\n{data['address']}")

    def import_wallet(self):
        """Import wallet from file."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Import Wallet", "",
            "JSON Files (*.json);;All Files (*)"
        )
        if path:
            try:
                with open(path, encoding="utf-8") as f:
                    wallet = json.load(f)
                
                name, ok = QInputDialog.getText(self, "Wallet Name", "Name for this wallet:")
                if ok and name:
                    dest = os.path.join(ROOT_DIR, f"wallet_{name}.json")
                    shutil.copy2(path, dest)
                    self.wallets[name] = wallet
                    self.wallet_combo.addItem(name)
                    QMessageBox.information(self, "Success", f"Wallet imported as '{name}'")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Import failed: {e}")


class NodeControlWidget(QWidget):
    """Node startup, stopping, and status."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.node_proc = None
        self.node_runner = None
        self.init_ui()
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_status)
        self.update_timer.start(2000)

    def init_ui(self):
        layout = QVBoxLayout()

        # Status indicator
        status_layout = QHBoxLayout()
        self.status_indicator = QLabel("●")
        self.status_indicator.setStyleSheet(f"color: {COLORS['red']}; font-size: 20px;")
        status_layout.addWidget(self.status_indicator)
        
        self.status_label = QLabel("OFFLINE")
        self.status_label.setStyleSheet(f"color: {COLORS['red']}; font-weight: bold;")
        status_layout.addWidget(self.status_label)
        status_layout.addStretch()
        layout.addLayout(status_layout)

        # Control buttons
        control_layout = QHBoxLayout()
        self.start_btn = QPushButton("Start Node")
        self.start_btn.clicked.connect(self.start_node)
        self.start_btn.setStyleSheet(f"background-color: {COLORS['green']}; color: white; font-weight: bold;")
        control_layout.addWidget(self.start_btn)
        
        self.stop_btn = QPushButton("Stop Node")
        self.stop_btn.clicked.connect(self.stop_node)
        self.stop_btn.setEnabled(False)
        self.stop_btn.setStyleSheet(f"background-color: {COLORS['red']}; color: white; font-weight: bold;")
        control_layout.addWidget(self.stop_btn)
        
        log_btn = QPushButton("View Log")
        log_btn.clicked.connect(self.show_log)
        control_layout.addWidget(log_btn)
        
        layout.addLayout(control_layout)

        # Statistics
        layout.addWidget(QLabel("Statistics:"))
        stats_layout = QHBoxLayout()
        
        stats = ["Height", "Difficulty", "Miners", "Mempool", "Reward"]
        self.stat_labels = {}
        for stat in stats:
            stat_frame = QVBoxLayout()
            stat_frame.addWidget(QLabel(stat.upper()))
            label = QLabel("--")
            label.setStyleSheet(f"font-family: Consolas; font-weight: bold;")
            stat_frame.addWidget(label)
            self.stat_labels[stat] = label
            stats_layout.addLayout(stat_frame)
        
        layout.addLayout(stats_layout)
        layout.addStretch()
        self.setLayout(layout)

    def start_node(self):
        """Start the node."""
        try:
            ensure_default_config(CONFIG_PATH)
            self.node_runner = NodeRunner(CONFIG_PATH, DATA_DIR)
            self.node_runner.run_background()
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
            self.status_label.setText("STARTING...")
            self.status_label.setStyleSheet(f"color: {COLORS['gold']}; font-weight: bold;")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to start node: {e}")

    def stop_node(self):
        """Stop the node."""
        try:
            if self.node_runner:
                self.node_runner.stop()
            self.start_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)
            self.status_label.setText("OFFLINE")
            self.status_label.setStyleSheet(f"color: {COLORS['red']}; font-weight: bold;")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to stop node: {e}")

    def update_status(self):
        """Poll node status."""
        try:
            info = rpc("getinfo", timeout=1)
            self.status_indicator.setStyleSheet(f"color: {COLORS['green']}; font-size: 20px;")
            self.status_label.setText("ONLINE")
            self.status_label.setStyleSheet(f"color: {COLORS['green']}; font-weight: bold;")
            
            self.stat_labels["Height"].setText(str(info.get("height", 0)))
            self.stat_labels["Difficulty"].setText(f"{info.get('difficulty', 0):,}")
            self.stat_labels["Miners"].setText(str(info.get("miners", 0)))
            self.stat_labels["Mempool"].setText(str(info.get("mempool_size", 0)))
            self.stat_labels["Reward"].setText(fmt_coins(info.get("block_reward", 0)))
            
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
        except Exception:
            self.status_indicator.setStyleSheet(f"color: {COLORS['red']}; font-size: 20px;")
            self.status_label.setText("OFFLINE")
            self.status_label.setStyleSheet(f"color: {COLORS['red']}; font-weight: bold;")
            self.start_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)

    def show_log(self):
        """Show node log file."""
        log_path = os.path.join(ROOT_DIR, "node.log")
        if os.path.exists(log_path):
            with open(log_path, "r") as f:
                content = f.read()
            
            dialog = QDialog(self)
            dialog.setWindowTitle("Node Log")
            dialog.resize(600, 400)
            layout = QVBoxLayout()
            text = QTextEdit()
            text.setPlainText(content)
            text.setReadOnly(True)
            layout.addWidget(text)
            dialog.setLayout(layout)
            dialog.exec_()
        else:
            QMessageBox.information(self, "Log", "No log file found yet")


class DeroMMainWindow(QMainWindow):
    """Main PyQt5 application window."""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"DeroM Control Panel v{__version__}")
        self.setWindowIcon(self.create_icon())
        self.setGeometry(100, 100, 1200, 800)
        
        self.init_ui()
        self.apply_styles()

    def create_icon(self):
        """Create application icon."""
        pixmap = QPixmap(32, 32)
        pixmap.fill(QColor(COLORS["blue"]))
        return QIcon(pixmap)

    def init_ui(self):
        """Initialize UI with tabs."""
        tabs = QTabWidget()
        
        # Node control tab
        self.node_widget = NodeControlWidget()
        tabs.addTab(self.node_widget, "Node Status")
        
        # Wallet tab
        self.wallet_widget = WalletWidget()
        tabs.addTab(self.wallet_widget, "Wallets")
        
        # Block explorer tab
        self.explorer_widget = BlockExplorerWidget()
        tabs.addTab(self.explorer_widget, "Block Explorer")
        
        # Settings tab
        self.settings_widget = self.create_settings_tab()
        tabs.addTab(self.settings_widget, "Settings")
        
        # Activity log tab
        self.log_widget = QTextEdit()
        self.log_widget.setReadOnly(True)
        tabs.addTab(self.log_widget, "Activity")
        
        self.setCentralWidget(tabs)
        self.statusBar().showMessage("DeroM ready")

    def create_settings_tab(self) -> QWidget:
        """Create settings tab."""
        widget = QWidget()
        layout = QVBoxLayout()
        
        form = QFormLayout()
        
        # RPC Port
        rpc_port = QSpinBox()
        rpc_port.setValue(RPC_PORT)
        rpc_port.setReadOnly(True)
        form.addRow("RPC Port:", rpc_port)
        
        # Stratum Port
        stratum_port = QSpinBox()
        stratum_port.setValue(STRATUM_PORT)
        stratum_port.setReadOnly(True)
        form.addRow("Stratum Port:", stratum_port)
        
        # Ticker
        ticker = QLineEdit()
        ticker.setText(TICKER)
        ticker.setReadOnly(True)
        form.addRow("Ticker:", ticker)
        
        # Initial Difficulty
        diff = QSpinBox()
        diff.setValue(CFG.get("initial_difficulty", 45000))
        form.addRow("Initial Difficulty:", diff)
        
        # Block Time Target
        block_time = QSpinBox()
        block_time.setValue(CFG.get("block_time_seconds", 300))
        form.addRow("Target Block Time (s):", block_time)
        
        layout.addLayout(form)
        layout.addStretch()
        
        widget.setLayout(layout)
        return widget

    def apply_styles(self):
        """Apply dark theme stylesheet."""
        stylesheet = f"""
        QMainWindow, QWidget, QDialog {{
            background-color: {COLORS['bg']};
            color: {COLORS['fg']};
        }}
        
        QTabWidget::pane {{
            border: 1px solid {COLORS['border']};
        }}
        
        QTabBar::tab {{
            background-color: {COLORS['panel']};
            color: {COLORS['fg']};
            padding: 8px 16px;
            border: 1px solid {COLORS['border']};
        }}
        
        QTabBar::tab:selected {{
            background-color: {COLORS['blue']};
            color: white;
        }}
        
        QPushButton {{
            background-color: {COLORS['btn']};
            color: {COLORS['fg']};
            border: 1px solid {COLORS['border']};
            padding: 5px 10px;
            border-radius: 3px;
        }}
        
        QPushButton:hover {{
            background-color: {COLORS['btn_hover']};
        }}
        
        QLineEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {{
            background-color: {COLORS['panel']};
            color: {COLORS['fg']};
            border: 1px solid {COLORS['border']};
            padding: 5px;
            border-radius: 3px;
        }}
        
        QLabel {{
            color: {COLORS['fg']};
        }}
        
        QTableWidget {{
            background-color: {COLORS['panel']};
            color: {COLORS['fg']};
            gridline-color: {COLORS['border']};
        }}
        
        QHeaderView::section {{
            background-color: {COLORS['border']};
            color: {COLORS['fg']};
            padding: 5px;
        }}
        
        QMenuBar {{
            background-color: {COLORS['panel']};
            color: {COLORS['fg']};
        }}
        
        QStatusBar {{
            background-color: {COLORS['panel']};
            color: {COLORS['fg']};
            border-top: 1px solid {COLORS['border']};
        }}
        """
        self.setStyleSheet(stylesheet)

    def closeEvent(self, event):
        """Clean shutdown."""
        try:
            if self.node_widget.node_runner:
                self.node_widget.node_runner.stop()
        except Exception:
            pass
        event.accept()


def main():
    """Entry point for PyQt5 GUI."""
    multiprocessing = __import__('multiprocessing')
    multiprocessing.freeze_support()
    
    app = QApplication(sys.argv)
    window = DeroMMainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
