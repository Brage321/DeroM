"""PPLNS (Pay Per Last N Shares) pool mode for DeroM.

Allows multiple miners to pool resources and share block rewards
based on their contributed shares.
"""
import json
import os
import time
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
from collections import defaultdict


class PoolAccount:
    """Individual miner account in the pool."""

    def __init__(self, address: str, worker_name: str = ""):
        self.address = address
        self.worker_name = worker_name
        self.balance = 0  # In atoms
        self.shares = []  # List of (timestamp, difficulty) tuples
        self.joined_at = time.time()
        self.stats = {
            "total_shares": 0,
            "valid_shares": 0,
            "stale_shares": 0,
            "current_round_shares": 0,
        }

    def add_share(self, difficulty: float, stale: bool = False):
        """Record a share submission."""
        now = time.time()
        self.shares.append((now, difficulty))
        self.stats["total_shares"] += 1

        if stale:
            self.stats["stale_shares"] += 1
        else:
            self.stats["valid_shares"] += 1
            self.stats["current_round_shares"] += 1

    def get_current_difficulty(self) -> float:
        """Get miner's current vardiff target."""
        valid = self.stats["valid_shares"]
        if valid < 2:
            return 1.0

        # Target ~15 shares per minute = 1 share per 4 seconds
        target_interval = 4.0
        if len(self.shares) >= 2:
            elapsed = self.shares[-1][0] - self.shares[-2][0]
            if elapsed > 0:
                ratio = target_interval / elapsed
                current_diff = self.shares[-1][1]
                return max(0.5, min(1000, current_diff * ratio))

        return 1.0

    def reset_round(self):
        """Reset round statistics."""
        self.stats["current_round_shares"] = 0


class PPLNSPool:
    """PPLNS pool management."""

    def __init__(self, config_path: str = "pool_config.json"):
        self.config_path = config_path
        self.config = self.load_config()

        # Pool parameters
        self.window_size = self.config.get("window_size", 1000)  # Last N shares
        self.block_reward = self.config.get("block_reward", 50 * 10**8)  # In atoms
        self.pool_fee = self.config.get("pool_fee", 0.01)  # 1% fee
        self.min_payout = self.config.get("min_payout", 0.1 * 10**8)  # Min payout in atoms

        # Accounts
        self.accounts: Dict[str, PoolAccount] = {}
        self.total_shares = 0
        self.block_history: List[Dict[str, Any]] = []

        self.load_accounts()

    def load_config(self) -> Dict[str, Any]:
        """Load pool configuration."""
        if os.path.exists(self.config_path):
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)

        return {
            "pool_name": "DeroM Pool",
            "pool_address": "Pool",
            "window_size": 1000,
            "block_reward": 50 * 10**8,
            "pool_fee": 0.01,
            "min_payout": 0.1 * 10**8,
            "difficulty_multiplier": 256,
        }

    def save_config(self):
        """Save pool configuration."""
        with open(self.config_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, indent=2)

    def load_accounts(self):
        """Load accounts from disk."""
        accounts_file = self.config_path.replace(".json", "_accounts.json")
        if os.path.exists(accounts_file):
            try:
                with open(accounts_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for addr, acc_data in data.items():
                        acc = PoolAccount(addr, acc_data.get("worker_name", ""))
                        acc.balance = acc_data.get("balance", 0)
                        acc.stats = acc_data.get("stats", {})
                        self.accounts[addr] = acc
            except Exception as e:
                print(f"Error loading accounts: {e}")

    def save_accounts(self):
        """Save accounts to disk."""
        accounts_file = self.config_path.replace(".json", "_accounts.json")
        data = {}
        for addr, acc in self.accounts.items():
            # Shares are transient (per-run); persist balance + stats only.
            data[addr] = {
                "worker_name": acc.worker_name,
                "balance": acc.balance,
                "stats": acc.stats,
            }

        with open(accounts_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)

    def register_miner(self, address: str, worker_name: str = "") -> bool:
        """Register a new miner in the pool.

        Args:
            address: Miner's payout address
            worker_name: Worker identifier

        Returns:
            True if registered successfully
        """
        if address not in self.accounts:
            self.accounts[address] = PoolAccount(address, worker_name)
            return True
        return False

    def submit_share(self, address: str, difficulty: float, block: bool = False) -> Optional[Dict[str, Any]]:
        """Submit a share from a miner.

        Args:
            address: Miner address
            difficulty: Share difficulty
            block: Whether this is a block (difficulty >= network difficulty)

        Returns:
            Share result with current status
        """
        if address not in self.accounts:
            self.register_miner(address)

        account = self.accounts[address]
        account.add_share(difficulty, stale=False)
        self.total_shares += 1

        result = {
            "status": "accepted",
            "difficulty": difficulty,
            "user_difficulty": account.get_current_difficulty(),
            "shares": account.stats["current_round_shares"],
            "block": block,
        }

        if block:
            result["block_info"] = self.on_block_found(address)

        return result


    def on_block_found(self, block_address: str) -> Dict[str, Any]:
        """Process block found by a pool miner.

        Args:
            block_address: Address that found the block

        Returns:
            Block reward distribution info
        """
        # Get shares in the window
        window_shares = self.get_window_shares()

        if not window_shares:
            return {"error": "No shares in window"}

        total_difficulty = sum(d for _, d, _ in window_shares)
        if total_difficulty == 0:
            return {"error": "Total share difficulty is zero"}

        # Calculate payouts
        payouts = {}
        pool_fee_amount = int(self.block_reward * self.pool_fee)
        payout_amount = self.block_reward - pool_fee_amount

        for miner_addr, miner_difficulty, _ in window_shares:
            share_percentage = miner_difficulty / total_difficulty
            miner_payout = int(payout_amount * share_percentage)

            if miner_payout >= self.min_payout:
                if miner_addr not in payouts:
                    payouts[miner_addr] = 0
                payouts[miner_addr] += miner_payout

        # Distribute payouts
        for miner_addr, amount in payouts.items():
            if miner_addr in self.accounts:
                self.accounts[miner_addr].balance += amount

        # Record block
        block_record = {
            "timestamp": datetime.now().isoformat(),
            "finder": block_address,
            "reward": self.block_reward,
            "fee": pool_fee_amount,
            "payouts": payouts,
            "total_shares": len(window_shares),
        }
        self.block_history.append(block_record)

        # Reset round
        for account in self.accounts.values():
            account.reset_round()

        self.total_shares = 0

        # Persist credited balances so a restart before the next payout
        # round does not lose them.
        self.save_accounts()

        return block_record

    def get_window_shares(self) -> List[Tuple[str, float, float]]:
        """Get the last N shares for payout calculation.

        Returns:
            List of (address, difficulty, timestamp) tuples, newest first
        """
        shares = []

        for address, account in self.accounts.items():
            for timestamp, difficulty in account.shares[-self.window_size:]:
                shares.append((address, difficulty, timestamp))

        # Sort by timestamp (newest first) - PPLNS selection across all miners
        shares.sort(key=lambda x: x[2], reverse=True)

        return shares[:self.window_size]


    def process_payouts(self) -> Dict[str, int]:
        """Process pending payouts for all miners.

        Returns:
            Dict of address -> payout amount
        """
        payouts = {}

        for address, account in self.accounts.items():
            if account.balance >= self.min_payout:
                payouts[address] = account.balance
                account.balance = 0

        self.save_accounts()

        return payouts

    def get_miner_stats(self, address: str) -> Optional[Dict[str, Any]]:
        """Get statistics for a miner.

        Args:
            address: Miner address

        Returns:
            Miner statistics
        """
        if address not in self.accounts:
            return None

        account = self.accounts[address]

        return {
            "address": address,
            "worker": account.worker_name,
            "balance": account.balance,
            "pending_payout": account.balance if account.balance >= self.min_payout else 0,
            "stats": account.stats,
            "current_difficulty": account.get_current_difficulty(),
            "joined": datetime.fromtimestamp(account.joined_at).isoformat(),
        }

    def get_pool_stats(self) -> Dict[str, Any]:
        """Get overall pool statistics."""
        total_balance = sum(acc.balance for acc in self.accounts.values())
        total_payouts = sum(block.get("reward", 0) for block in self.block_history)

        return {
            "pool_name": self.config.get("pool_name", "DeroM Pool"),
            "miners": len(self.accounts),
            "total_miners": len(self.accounts),
            "total_shares": self.total_shares,
            "window_size": self.window_size,
            "block_reward": self.block_reward,
            "pool_fee": self.pool_fee,
            "total_pending_balance": total_balance,
            "total_paid_out": total_payouts,
            "blocks_found": len(self.block_history),
            "last_block": self.block_history[-1]["timestamp"] if self.block_history else None,
        }

    def cleanup_inactive_accounts(self, days: int = 7) -> int:
        """Remove inactive miner accounts.

        Args:
            days: Remove miners inactive for this many days

        Returns:
            Number of accounts removed
        """
        cutoff = time.time() - (days * 86400)
        to_remove = [
            addr for addr, acc in self.accounts.items()
            if acc.joined_at < cutoff and not acc.shares
        ]

        for addr in to_remove:
            del self.accounts[addr]

        self.save_accounts()
        return len(to_remove)


