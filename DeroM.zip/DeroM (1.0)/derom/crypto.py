"""DeroM cryptographic primitives: hashing, base58, keys, targets, merkle."""
import hashlib
import json

from ecdsa import SECP256k1, SigningKey, VerifyingKey
from ecdsa.util import sigdecode_der, sigencode_der_canonize

# Address version byte chosen so base58 addresses ALWAYS start with 'D'
# (first base58 digit lands in [12,13) for every possible key)
ADDRESS_VERSION_BYTE = 0x1F

BASE58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
_BASE58_INDEX = {c: i for i, c in enumerate(BASE58_ALPHABET)}

# Difficulty-1 target (Bitcoin convention): 0x00000000FFFF0000 || 0*48
DIFF1_TARGET = 0x00000000FFFF0000000000000000000000000000000000000000000000000000
# Upper bound on the PoW target (compact 0x207fffff), Bitcoin-style safety cap
POW_LIMIT = 0x007FFFFF << (8 * 29)


# ---------------------------------------------------------------- hashing

def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def sha256d(data: bytes) -> bytes:
    """Double SHA-256 - DeroM's proof-of-work and commitment hash."""
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()


def hash160(data: bytes) -> bytes:
    """Short identifier of a public key (we deliberately avoid RIPEMD-160,
    which is unavailable in modern OpenSSL builds on Windows)."""
    return sha256(data)[:20]


# ---------------------------------------------------------------- base58

def b58encode(raw: bytes) -> str:
    n = int.from_bytes(raw, "big")
    out = ""
    while n > 0:
        n, r = divmod(n, 58)
        out = BASE58_ALPHABET[r] + out
    pad = 0
    for byte in raw:
        if byte == 0:
            pad += 1
        else:
            break
    return "1" * pad + out


def b58decode(text: str) -> bytes:
    n = 0
    for ch in text:
        if ch not in _BASE58_INDEX:
            raise ValueError(f"invalid base58 character {ch!r}")
        n = n * 58 + _BASE58_INDEX[ch]
    body = n.to_bytes((n.bit_length() + 7) // 8, "big")
    pad = 0
    for ch in text:
        if ch == "1":
            pad += 1
        else:
            break
    return b"\x00" * pad + body


def b58check_encode(raw: bytes) -> str:
    return b58encode(raw + sha256d(raw)[:4])


def b58check_decode(text: str) -> bytes:
    decoded = b58decode(text)
    if len(decoded) < 5:
        raise ValueError("address too short")
    payload, checksum = decoded[:-4], decoded[-4:]
    if sha256d(payload)[:4] != checksum:
        raise ValueError("bad address checksum")
    return payload


# ---------------------------------------------------------------- addresses / keys

def pubkey_to_address(pubkey: bytes) -> str:
    payload = bytes([ADDRESS_VERSION_BYTE]) + hash160(pubkey)
    return b58check_encode(payload)


def address_is_valid(address: str) -> bool:
    try:
        payload = b58check_decode(address)
    except Exception:
        return False
    return len(payload) == 21 and payload[0] == ADDRESS_VERSION_BYTE


def generate_privkey() -> bytes:
    return SigningKey.generate(curve=SECP256k1).to_string()


def privkey_to_pubkey(privkey: bytes) -> bytes:
    """Return the 33-byte compressed SEC1 public key."""
    sk = SigningKey.from_string(privkey, curve=SECP256k1)
    return _compress_pubkey(sk.get_verifying_key())


def privkey_to_address(privkey: bytes) -> str:
    return pubkey_to_address(privkey_to_pubkey(privkey))


def _compress_pubkey(vk: VerifyingKey) -> bytes:
    raw = vk.to_string()  # 64 bytes: x || y
    x, y = raw[:32], raw[32:]
    prefix = b"\x03" if y[-1] & 1 else b"\x02"
    return prefix + x


# secp256k1 field prime (avoids ecdsa-lib attribute quirks across versions)
_SECP256K1_P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F


def _decompress_pubkey(compressed: bytes) -> VerifyingKey:
    if len(compressed) != 33 or compressed[0] not in (2, 3):
        raise ValueError("bad compressed pubkey")
    p = _SECP256K1_P
    x = int.from_bytes(compressed[1:], "big")
    y_sq = (pow(x, 3, p) + 7) % p
    y = pow(y_sq, (p + 1) // 4, p)
    if pow(y, 2, p) != y_sq:
        raise ValueError("point not on curve")
    if (y & 1) != (compressed[0] & 1):
        y = p - y
    return VerifyingKey.from_string(x.to_bytes(32, "big") + y.to_bytes(32, "big"),
                                    curve=SECP256k1)


def sign_payload(privkey: bytes, payload: bytes) -> bytes:
    """Deterministic ECDSA (secp256k1) signature over a byte payload."""
    sk = SigningKey.from_string(privkey, curve=SECP256k1)
    return sk.sign_deterministic(sha256d(payload), hashfunc=hashlib.sha256,
                                 sigencode=sigencode_der_canonize)


def verify_payload(pubkey: bytes, payload: bytes, signature: bytes) -> bool:
    try:
        vk = _decompress_pubkey(pubkey)
        return vk.verify(signature, sha256d(payload), hashfunc=hashlib.sha256,
                         sigdecode=sigdecode_der)
    except Exception:
        return False


# ---------------------------------------------------------------- difficulty / nBits

def encode_nbits(target: int) -> int:
    """Bitcoin-style compact encoding of a 256-bit target."""
    if target <= 0:
        raise ValueError("target must be positive")
    size = (target.bit_length() + 7) // 8
    if size <= 3:
        compact = target << (8 * (3 - size))
    else:
        compact = target >> (8 * (size - 3))
    if compact & 0x00800000:  # sign bit would collide; lose precision instead
        compact >>= 8
        size += 1
    return compact | (size << 24)


def decode_nbits(nbits: int) -> int:
    size = nbits >> 24
    mantissa = nbits & 0x007FFFFF
    negative = bool(nbits & 0x00800000)
    if negative or size == 0 or mantissa == 0:
        raise ValueError("invalid nBits")
    if size <= 3:
        return mantissa >> (8 * (3 - size))
    return mantissa << (8 * (size - 3))


def difficulty_to_target(difficulty: float) -> int:
    if difficulty <= 0:
        difficulty = 1e-9
    return min(int(DIFF1_TARGET / difficulty), POW_LIMIT)


def target_to_difficulty(target: int) -> float:
    return DIFF1_TARGET / target


# ---------------------------------------------------------------- merkle

def merkle_root(txid_digests: list) -> bytes:
    """Merkle root over raw sha256d digests (odd levels duplicate last)."""
    if not txid_digests:
        raise ValueError("no txids")
    level = list(txid_digests)
    while len(level) > 1:
        if len(level) % 2:
            level.append(level[-1])
        level = [sha256d(level[i] + level[i + 1]) for i in range(0, len(level), 2)]
    return level[0]


def merkle_branch(txid_digests: list, index: int) -> list:
    """Merkle branch (raw digests) for the txid at `index`."""
    branch = []
    level = list(txid_digests)
    idx = index
    while len(level) > 1:
        if len(level) % 2:
            level.append(level[-1])
        branch.append(level[idx ^ 1])
        level = [sha256d(level[i] + level[i + 1]) for i in range(0, len(level), 2)]
        idx //= 2
    return branch


def merkle_root_from_branch(coinbase_txid: bytes, branch: list, index: int) -> bytes:
    """Recompute the merkle root from coinbase txid + branch (stratum style)."""
    acc = coinbase_txid
    for i, digest in enumerate(branch):
        if (index >> i) & 1:
            acc = sha256d(digest + acc)
        else:
            acc = sha256d(acc + digest)
    return acc


# ---------------------------------------------------------------- misc

def canonical_json(obj) -> bytes:
    """Stable serialization used for txids and signatures."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False).encode("utf-8")
