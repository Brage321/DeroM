"""DeroM Qt GUI entry point."""
import sys
from .gui_qt import main

if __name__ == "__main__":
    main()
