"""DeroM JSON-RPC control plane (HTTP, localhost by default)."""
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import block as blk
from . import tx as txlib
from .crypto import target_to_difficulty

MAX_TXS_PER_BLOCK = 200


def _estimate_network_hashrate(chain) -> float:
    """Simple hashrate estimate over the recent retarget window, H/s."""
    with chain.lock:
        interval = int(chain.cfg["retarget_interval_blocks"])
        hist = chain.ts_hist[-(interval + 1):]
        if len(hist) < 2:
            return 0.0
        dt = max(hist[-1][1] - hist[0][1], 1)
        blocks = len(hist) - 1
        diff = target_to_difficulty(chain.next_target)
    return round(diff * (2 ** 32) * blocks / dt, 2)


def _get_block_template(node, chain) -> dict:
    """Build a block template a stratum pool can turn into miner jobs.

    Follows the getblocktemplate convention pools already know: the pool
    merges `coinbasevalue` into its own coinbase, includes `transactions`
    in its merkle tree and broadcasts work via mining.notify."""
    spends = node.mempool.by_fee_desc()[:MAX_TXS_PER_BLOCK]
    quote, err = chain.quote_block(spends)
    if err:
        quote, err = chain.quote_block([])
        if err:
            raise ValueError(f"cannot build template: {err}")
    return {
        "version": blk.BLOCK_VERSION,
        "height": quote["height"],
        "previousblockhash": quote["prev"],
        "nbits": quote["nbits"],
        "bits": f"{quote['nbits']:08x}",
        "target": quote["target"],
        "difficulty": round(target_to_difficulty(quote["target"]), 8),
        "curtime": int(time.time()),
        "transactions": quote["spends"],
        "coinbasevalue": chain.subsidy(quote["height"]) + quote["fees"],
        "fees": quote["fees"],
    }


class RpcServer:
    """Exposes node/chain/mempool operations as JSON-RPC 2.0-ish POST /."""

    def __init__(self, node):
        self.node = node
        self.httpd = None
        self.thread = None

    # -------------------------------------------------------------- methods

    def call(self, method: str, params):
        node = self.node
        chain = node.chain
        p = params if isinstance(params, list) else []

        def arg(i, default=None):
            return p[i] if len(p) > i else default

        if method == "getinfo":
            info = chain.info()
            info.update({
                "mempool_size": node.mempool.size(),
                "miners_connected": node.miner_count(),
                "ticker": node.cfg["ticker"],
                "version": node.version,
            })
            return info
        if method == "getblockcount":
            return chain.height
        if method == "getdifficulty":
            return round(target_to_difficulty(chain.next_target), 8)
        if method == "getblock":
            block = chain.get_block(arg(0))
            if block is None:
                raise ValueError("block not found")
            return block
        if method == "getbalance":
            addr = arg(0)
            if not addr:
                raise ValueError("address parameter required")
            acct = chain.account(addr)
            return acct["balance"] / txlib.ATOMS_PER_DEROM
        if method == "getaccount":
            addr = arg(0)
            if not addr:
                raise ValueError("address parameter required")
            return chain.account(addr)
        if method == "richlist":
            return chain.richlist(arg(0, 25))
        if method == "submittransaction":
            tx = arg(0)
            if not isinstance(tx, dict):
                raise ValueError("transaction object required")
            err = txlib.verify_spend(
                tx,
                lambda a: chain.balance_of(a),
                lambda a: chain.nonce_of(a))
            if err:
                raise ValueError(err)
            dup = node.mempool.add(tx)
            if dup and dup != "already in mempool":
                raise ValueError(dup)
            return txlib.txid(tx)
        if method == "getrawmempool":
            return [txlib.txid(t) for t in node.mempool.by_fee_desc()]
        if method == "getmininginfo":
            info = chain.info()
            info.update({
                "mempool_size": node.mempool.size(),
                "miners_connected": node.miner_count(),
                "ticker": node.cfg["ticker"],
                "network_hashrate": _estimate_network_hashrate(chain),
            })
            return info
        if method == "getnetworkhashps":
            return _estimate_network_hashrate(chain)
        if method == "getblocktemplate":
            return _get_block_template(node, chain)
        if method == "submitblock":
            block = arg(0)
            if isinstance(block, str):
                block = json.loads(block)
            if not isinstance(block, dict):
                raise ValueError("block object required")
            ok, msg = chain.add_block(block)
            if not ok:
                raise ValueError(msg)
            node.on_new_tip(block)
            return block["hash"]
        if method == "stop":
            node.request_shutdown()
            return "stopping"
        raise ValueError(f"unknown method {method!r}")

    # -------------------------------------------------------------- serving

    def start(self):
        server = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *_args):
                pass

            def _cors(self):
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Headers", "Content-Type")
                self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")

            def do_OPTIONS(self):
                self.send_response(204)  # browser preflight for cross-origin RPC
                self._cors()
                self.send_header("Content-Length", "0")
                self.end_headers()

            def do_POST(self):
                req = {}
                try:
                    length = int(self.headers.get("Content-Length", 0))
                    raw = self.rfile.read(length) if length else b"{}"
                    req = json.loads(raw.decode("utf-8"))
                    result = server.call(req.get("method", ""), req.get("params", []))
                    body = {"jsonrpc": "2.0", "id": req.get("id"), "result": result,
                            "error": None}
                except Exception as exc:  # noqa: BLE001 - report to client
                    body = {"jsonrpc": "2.0", "id": req.get("id"), "result": None,
                            "error": str(exc)}
                payload = json.dumps(body).encode("utf-8")
                self.send_response(200)  # JSON-RPC errors ride a 200
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(payload)))
                self._cors()
                self.end_headers()
                self.wfile.write(payload)

        bind = (self.node.cfg.get("rpc_host", "127.0.0.1"),
                int(self.node.cfg.get("rpc_port", 8570)))
        self.httpd = ThreadingHTTPServer(bind, Handler)
        self.thread = threading.Thread(target=self.httpd.serve_forever,
                                       name="derom-rpc", daemon=True)
        self.thread.start()
        return bind

    def stop(self):
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
