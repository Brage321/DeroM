"""DeroM transactions.

DeroM uses a simple account model:
  - balances: address -> integer atom balance (1 DEROM = 100_000_000 atoms)
  - nonces:   address -> last spent nonce (each spend must increment by 1)

Two transaction types:
  coinbase : created by miners, mints new atoms (validated only inside blocks)
  spend    : signed transfer of atoms between addresses
"""
import secrets

from .crypto import (address_is_valid, canonical_json, privkey_to_address,
                     privkey_to_pubkey, pubkey_to_address, sign_payload,
                     verify_payload)

COINBASE = "coinbase"
SPEND = "spend"

ATOMS_PER_DEROM = 100_000_000
MIN_FEE_ATOMS = 1000          # dust fee to discourage spam
MAX_TX_BYTES = 4096


# ---------------------------------------------------------------- coinbase

def make_coinbase(to_address: str, value: int, height: int) -> dict:
    return {
        "type": COINBASE,
        "to": to_address,
        "amount": int(value),
        "height": int(height),
        "extra": secrets.randbits(64),
    }


def coinbase_txid(cb: dict) -> bytes:
    from .crypto import sha256d
    return sha256d(canonical_json(_coinbase_core(cb)))


def tx_digest(t: dict) -> bytes:
    """Raw sha256d commitment digest of any transaction (bytes).
    Coinbase transactions commit to their serialized raw bytes (the exact
    bytes an ASIC hashes into the merkle root); other txs to canonical JSON."""
    from .crypto import sha256d
    if t.get("type") == COINBASE:
        raw = t.get("raw")
        if raw:
            return sha256d(bytes.fromhex(raw))
        return sha256d(canonical_json(_coinbase_core(t)))
    return sha256d(canonical_json(_signed_payload(t)))


def _coinbase_core(cb: dict) -> dict:
    return {k: cb[k] for k in ("type", "to", "amount", "height", "extra")}


# ---------------------------------------------------------------- spends

_SIGNED_KEYS = ("type", "from", "to", "amount", "fee", "nonce", "pubkey")


def make_spend(privkey: bytes, to_address: str, amount: int, fee: int,
               nonce: int) -> dict:
    from_address = privkey_to_address(privkey)
    pubkey = privkey_to_pubkey(privkey)
    tx = {
        "type": SPEND,
        "from": from_address,
        "to": to_address,
        "amount": int(amount),
        "fee": int(fee),
        "nonce": int(nonce),
        "pubkey": pubkey.hex(),
        "signature": "",
    }
    tx["signature"] = sign_payload(privkey, canonical_json(_signed_payload(tx))).hex()
    return tx


def _signed_payload(tx: dict) -> dict:
    return {k: tx[k] for k in _SIGNED_KEYS}


def txid(tx: dict) -> str:
    """Stable transaction id (excludes signature so it exists pre-signing)."""
    core = _signed_payload(tx) if tx["type"] == SPEND else _coinbase_core(tx)
    from .crypto import sha256d
    return sha256d(canonical_json(core)).hex()


def verify_spend(tx: dict, balance_of, nonce_of) -> str:
    """Fully validate a spend against the current state.
    `balance_of`/`nonce_of` are callables address -> int.
    Returns "" when valid, otherwise an error string."""
    if tx.get("type") != SPEND:
        return "not a spend transaction"
    required = set(_SIGNED_KEYS) | {"signature"}
    missing = required - set(tx)
    if missing:
        return f"missing fields: {sorted(missing)}"
    for key in ("amount", "fee", "nonce"):
        if not isinstance(tx[key], int) or tx[key] < 0:
            return f"field {key} must be a non-negative integer"
    if tx["amount"] <= 0:
        return "amount must be positive"
    if tx["fee"] < MIN_FEE_ATOMS:
        return f"fee below minimum ({MIN_FEE_ATOMS} atoms)"
    if not address_is_valid(tx["to"]):
        return "invalid destination address"
    if not address_is_valid(tx["from"]):
        return "invalid source address"

    try:
        pubkey = bytes.fromhex(tx["pubkey"])
        signature = bytes.fromhex(tx["signature"])
    except ValueError:
        return "pubkey/signature must be hex"
    if pubkey_to_address(pubkey) != tx["from"]:
        return "pubkey does not match sending address"
    if not verify_payload(pubkey, canonical_json(_signed_payload(tx)), signature):
        return "invalid signature"

    expected_nonce = nonce_of(tx["from"]) + 1
    if tx["nonce"] != expected_nonce:
        return f"bad nonce (expected {expected_nonce}, got {tx['nonce']})"
    if balance_of(tx["from"]) < tx["amount"] + tx["fee"]:
        return "insufficient balance"
    return ""
