"""DeroM Control Panel - point-and-click wallet, node manager, miner guide.

Launch:  py -B -m derom.gui       (or double-click DeroM.bat)
Uses only the Python standard library (tkinter) - no new dependencies.
"""
import datetime
import json
import os
import shutil
import socket
import sys
import threading
import urllib.request
import tkinter as tk
from tkinter import filedialog, messagebox

from . import __version__, tx as txlib
from .crypto import (address_is_valid, generate_privkey,
                     privkey_to_address, privkey_to_pubkey)
from .node import (APP_DIR as ROOT_DIR, NodeRunner, ensure_default_config,
                   load_config as _load_node_config)

WALLET_PATH = os.path.join(ROOT_DIR, "wallet.json")
CONFIG_PATH = os.path.join(ROOT_DIR, "config.json")
DATA_DIR = os.path.join(ROOT_DIR, "data")

BG, PANEL, BORDER = "#0d1117", "#161b22", "#30363d"
FG, DIM, MUTED = "#e6edf3", "#9aa4b2", "#6e7681"
GREEN, BLUE, GOLD, RED = "#3fb950", "#4493f8", "#d29922", "#f85149"
BTN, BTN_HOVER = "#21262d", "#2f3742"

MONO = ("Consolas", 11)
UI = ("Segoe UI", 10)
UI_B = ("Segoe UI", 10, "bold")
H1 = ("Segoe UI", 16, "bold")
H2 = ("Segoe UI", 11, "bold")


def load_config():
    return _load_node_config(CONFIG_PATH)


CFG = load_config()
RPC_PORT = int(CFG.get("rpc_port", 8570))
STRATUM_PORT = int(CFG.get("stratum_port", 3333))
TICKER = CFG.get("ticker", "DEROM")
RPC_URL = f"http://127.0.0.1:{RPC_PORT}/"


def rpc(method, params=None, timeout=4):
    payload = json.dumps({"id": 1, "method": method,
                          "params": list(params or [])}).encode()
    req = urllib.request.Request(
        RPC_URL, data=payload, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = json.loads(resp.read().decode())
    if body.get("error"):
        raise RuntimeError(str(body["error"]))
    return body["result"]


def local_ip():
    """Best-effort LAN IP so miner URLs are copy-paste ready."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))          # no packet is actually sent
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def fmt_coins(atoms):
    return f"{atoms / txlib.ATOMS_PER_DEROM:,.8f}".rstrip("0").rstrip(".")


def load_wallet_file(path=WALLET_PATH):
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def save_wallet_file(data, path=WALLET_PATH):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
    os.replace(tmp, path)


class App:
    def __init__(self, root):
        self.root = root
        root.title(f"DeroM Control Panel  v{__version__}")
        root.configure(bg=BG)
        root.geometry("840x760")
        root.minsize(780, 700)

        self.addr = None
        self.priv_hex = None
        self.node_proc = None
        self.we_spawned = False
        self.node_running = False

        outer = tk.Frame(root, bg=BG)
        outer.pack(fill="both", expand=True, padx=14, pady=10)
        self._build_header(outer)

        mid = tk.Frame(outer, bg=BG)
        mid.pack(fill="both", expand=True)
        mid.columnconfigure(0, weight=1)
        mid.columnconfigure(1, weight=1)
        self._build_node_panel(mid)
        self._build_wallet_panel(mid)
        guide_wrap = tk.Frame(mid, bg=BG)
        guide_wrap.grid(row=2, column=0, columnspan=2, sticky="nsew",
                        pady=(10, 0))
        self._build_guide_panel(guide_wrap)
        send_wrap = tk.Frame(mid, bg=BG)
        send_wrap.grid(row=3, column=0, columnspan=2, sticky="nsew",
                       pady=(10, 0))
        self._build_send_panel(send_wrap)
        self._build_log(outer)

        root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.refresh_wallet_ui()
        self.poll_loop()
        self.log("DeroM control panel ready.")
        threading.Thread(target=self._autostart, daemon=True).start()

    # ------------------------------------------------------------ chrome

    def _panel(self, parent, title):
        box = tk.Frame(parent, bg=PANEL, highlightbackground=BORDER,
                       highlightthickness=1)
        head = tk.Frame(box, bg=PANEL)
        head.pack(fill="x", padx=12, pady=(8, 2))
        tk.Label(head, text=title, bg=PANEL, fg=DIM, font=H2).pack(side="left")
        return box

    def _button(self, parent, text, cmd, color=BLUE):
        b = tk.Button(parent, text=text, command=cmd, bg=color, fg="#ffffff",
                      activebackground=color, activeforeground="#ffffff",
                      relief="flat", font=UI_B, padx=12, pady=5,
                      cursor="hand2", bd=0)
        b.bind("<Enter>", lambda e: b.config(bg=BTN_HOVER))
        b.bind("<Leave>", lambda e: b.config(bg=color))
        return b

    def _build_header(self, parent):
        bar = tk.Frame(parent, bg=BG)
        bar.pack(fill="x", pady=(0, 10))
        tk.Label(bar, text=f"DeroM  ({TICKER})", bg=BG, fg=FG,
                 font=H1).pack(side="left")
        tk.Label(bar, text="ASIC-mineable · solo stratum · no premine",
                 bg=BG, fg=MUTED, font=UI).pack(side="left", padx=12,
                                                pady=(6, 0))

    # ------------------------------------------------------------ node

    def _build_node_panel(self, parent):
        box = self._panel(parent, "NODE")
        box.grid(row=1, column=0, sticky="nsew", padx=(0, 5))
        body = tk.Frame(box, bg=PANEL)
        body.pack(fill="both", expand=True, padx=12, pady=(2, 10))

        top = tk.Frame(body, bg=PANEL)
        top.pack(fill="x")
        self.dot = tk.Label(top, text="\u25cf OFFLINE", bg=PANEL, fg=RED,
                            font=("Segoe UI", 12, "bold"))
        self.dot.pack(side="left")
        self.btn_start = self._button(top, "Start node", self.start_node,
                                      GREEN)
        self.btn_start.pack(side="right")
        self.btn_stop = self._button(top, "Stop", self.stop_node, RED)
        self.btn_stop.pack(side="right", padx=(0, 6))
        self.btn_nodelog = self._button(top, "View log", self.view_node_log,
                                        BTN)
        self.btn_nodelog.pack(side="right", padx=(0, 6))

        grid = tk.Frame(body, bg=PANEL)
        grid.pack(fill="x", pady=(10, 0))
        self.stats = {}
        for i, key in enumerate(["Height", "Difficulty", "Reward",
                                 "Miners", "Mempool"]):
            r, c = divmod(i, 3)
            cell = tk.Frame(grid, bg=PANEL)
            cell.grid(row=r, column=c, sticky="w", padx=(0, 26), pady=3)
            tk.Label(cell, text=key.upper(), bg=PANEL, fg=MUTED,
                     font=("Segoe UI", 8, "bold")).pack(anchor="w")
            lbl = tk.Label(cell, text="-", bg=PANEL, fg=FG, font=MONO)
            lbl.pack(anchor="w")
            self.stats[key] = lbl

    # ------------------------------------------------------------ wallet

    def _build_wallet_panel(self, parent):
        box = self._panel(parent, "YOUR WALLET")
        box.grid(row=1, column=1, sticky="nsew", padx=(5, 0))
        body = tk.Frame(box, bg=PANEL)
        body.pack(fill="both", expand=True, padx=12, pady=(2, 10))

        tk.Label(body, text="ADDRESS", bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w")
        self.addr_var = tk.StringVar()
        self.addr_entry = tk.Entry(body, textvariable=self.addr_var,
                                   font=MONO, state="readonly",
                                   readonlybackground="#10151c", fg=FG,
                                   insertbackground=FG, relief="flat",
                                   justify="center")
        self.addr_entry.pack(fill="x", ipady=5)

        r1 = tk.Frame(body, bg=PANEL)
        r1.pack(fill="x", pady=(7, 0))
        self.btn_newwallet = self._button(r1, "New wallet",
                                          self.on_new_wallet, GOLD)
        self.btn_newwallet.pack(side="left")
        self.btn_copyaddr = self._button(r1, "Copy address",
                                         self.on_copy_address)
        self.btn_copyaddr.pack(side="left", padx=(6, 0))
        self.btn_saveaddr = self._button(r1, "Save address .txt",
                                         self.on_save_address, BTN)
        self.btn_saveaddr.pack(side="left", padx=(6, 0))

        r2 = tk.Frame(body, bg=PANEL)
        r2.pack(fill="x", pady=(6, 0))
        self.btn_backup = self._button(r2, "Backup wallet file",
                                       self.on_backup_wallet, BTN)
        self.btn_backup.pack(side="left")
        self.btn_exportkey = self._button(r2, "Export private key...",
                                          self.on_export_key, BTN)
        self.btn_exportkey.pack(side="left", padx=(6, 0))

        tk.Label(body, text="BALANCE", bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", pady=(9, 0))
        self.bal_var = tk.StringVar(value="--")
        tk.Label(body, textvariable=self.bal_var, bg=PANEL, fg=GREEN,
                 font=("Segoe UI", 15, "bold")).pack(anchor="w")

    # ------------------------------------------------------------ guide

    def _build_guide_panel(self, parent):
        box = self._panel(parent, "CONNECT YOUR MINER")
        box.pack(fill="both", expand=True)
        body = tk.Frame(box, bg=PANEL)
        body.pack(fill="both", expand=True, padx=12, pady=(2, 10))

        self.guide = tk.Text(body, height=6, bg=PANEL, fg=FG, font=UI,
                             relief="flat", wrap="word", bd=0,
                             insertbackground=FG, cursor="arrow")
        self.guide.tag_config("step", foreground=GOLD, font=UI_B)
        self.guide.tag_config("dim", foreground=MUTED)
        self.guide.insert("1.0", "...")
        self.guide.config(state="disabled")
        self.guide.pack(fill="both", expand=True)

        def field_row(label):
            row = tk.Frame(body, bg=PANEL)
            row.pack(fill="x", pady=(6, 0))
            tk.Label(row, text=label, bg=PANEL, fg=MUTED, font=UI_B,
                     width=13, anchor="w").pack(side="left")
            var = tk.StringVar()
            ent = tk.Entry(row, textvariable=var, font=MONO, state="readonly",
                           readonlybackground="#10151c", fg=FG,
                           relief="flat")
            ent.pack(side="left", fill="x", expand=True, ipady=4,
                     padx=(0, 6))
            return row, var

        row, self.url_var = field_row("STRATUM URL")
        self._button(row, "Copy URL",
                     lambda: self.copy_to_clipboard(self.url_var.get(),
                                                    "Stratum URL copied"),
                     BTN).pack(side="right")
        row, self.user_var = field_row("MINER USERNAME")
        self._button(row, "Copy user",
                     lambda: self.copy_to_clipboard(self.user_var.get(),
                                                    "Miner username copied"),
                     BTN).pack(side="right")

        bottom = tk.Frame(body, bg=PANEL)
        bottom.pack(fill="x", pady=(9, 0))
        self.btn_testmine = self._button(bottom,
                                         "Test-mine 30s (CPU, no ASIC needed)",
                                         self.run_test_miner, GOLD)
        self.btn_testmine.pack(side="left")
        tk.Label(bottom,
                 text="verifies shares & payouts before real hardware",
                 bg=PANEL, fg=MUTED, font=UI).pack(side="left", padx=8)

    # ------------------------------------------------------------ send

    def _build_send_panel(self, parent):
        box = self._panel(parent, f"SEND {TICKER}")
        box.pack(fill="x")
        body = tk.Frame(box, bg=PANEL)
        body.pack(fill="x", padx=12, pady=(2, 10))

        body.columnconfigure(1, weight=1)
        tk.Label(body, text="TO ADDRESS", bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).grid(row=0, column=0,
                                                    sticky="w", pady=(6, 2))
        self.to_var = tk.StringVar()
        to_ent = tk.Entry(body, textvariable=self.to_var, font=MONO,
                          bg="#10151c", fg=FG, insertbackground=FG,
                          relief="flat")
        to_ent.grid(row=1, column=0, columnspan=3, sticky="ew", ipady=4)

        tk.Label(body, text=f"AMOUNT ({TICKER})", bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).grid(row=2, column=0,
                                                    sticky="w", pady=(8, 2))
        self.amt_var = tk.StringVar()
        amt = tk.Entry(body, textvariable=self.amt_var, font=MONO, width=16,
                       bg="#10151c", fg=FG, insertbackground=FG,
                       relief="flat")
        amt.grid(row=3, column=0, sticky="w", ipady=4)

        tk.Label(body, text="FEE (min 0.00001)", bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).grid(row=2, column=1,
                                                    sticky="w", padx=(14, 0),
                                                    pady=(8, 2))
        self.fee_var = tk.StringVar(value="0.001")
        fee = tk.Entry(body, textvariable=self.fee_var, font=MONO, width=12,
                       bg="#10151c", fg=FG, insertbackground=FG,
                       relief="flat")
        fee.grid(row=3, column=1, sticky="w", ipady=4, padx=(14, 0))

        self.btn_send = self._button(body, "Send", self.do_send, GREEN)
        self.btn_send.grid(row=3, column=2, sticky="e", padx=(14, 0))
        tk.Label(body,
                 text="funds arrive when the next block is mined",
                 bg=PANEL, fg=MUTED, font=("Segoe UI", 8)).grid(
            row=4, column=0, columnspan=3, sticky="w", pady=(5, 0))

    # ------------------------------------------------------------ log

    def _build_log(self, parent):
        box = self._panel(parent, "ACTIVITY")
        box.pack(fill="both", expand=True, pady=(10, 0))
        self.logbox = tk.Text(box, height=7, bg="#0b0e13", fg=DIM, font=MONO,
                              relief="flat", bd=0, state="disabled",
                              insertbackground=FG)
        for tag, color in (("info", DIM), ("ok", GREEN), ("warn", GOLD),
                           ("err", RED), ("hl", FG)):
            self.logbox.tag_config(tag, foreground=color)
        self.logbox.pack(fill="both", expand=True, padx=10, pady=(2, 8))

    def log(self, msg, tag="info"):
        def append():
            stamp = datetime.datetime.now().strftime("%H:%M:%S")
            self.logbox.config(state="normal")
            self.logbox.insert("end", f"[{stamp}] {msg}\n", tag)
            self.logbox.see("end")
            self.logbox.config(state="disabled")
        self.root.after(0, append)

    def copy_to_clipboard(self, text, label):
        if not text:
            messagebox.showwarning("Nothing to copy",
                                   "Create a wallet first.")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.log(f"{label}")

    # ------------------------------------------------------- wallet actions

    def refresh_wallet_ui(self):
        w = load_wallet_file()
        if w:
            self.addr = w["address"]
            self.priv_hex = w["private_key"]
            self.addr_var.set(w["address"])
        else:
            self.addr = None
            self.priv_hex = None
            self.addr_var.set("(no wallet yet - click New wallet)")
        has = self.addr is not None
        for b in (self.btn_copyaddr, self.btn_saveaddr, self.btn_backup,
                  self.btn_exportkey, self.btn_send, self.btn_testmine):
            b.config(state="normal" if has else "disabled")
        self.refresh_guide()

    def on_new_wallet(self):
        if os.path.exists(WALLET_PATH):
            if not messagebox.askyesno(
                    "Replace wallet?",
                    "wallet.json already exists.\n\nA copy will be kept as "
                    "wallet.backup.json, and a NEW wallet becomes active.\n\n"
                    "Continue?"):
                return
            shutil.copy2(WALLET_PATH,
                         os.path.join(ROOT_DIR, "wallet.backup.json"))
        priv = generate_privkey()
        data = {
            "created": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "version": __version__,
            "private_key": priv.hex(),
            "public_key": privkey_to_pubkey(priv).hex(),
            "address": privkey_to_address(priv),
        }
        save_wallet_file(data)
        try:
            os.chmod(WALLET_PATH, 0o600)
        except OSError:
            pass
        self.refresh_wallet_ui()
        self.log(f"New wallet created: {data['address']}", "ok")
        messagebox.showinfo(
            "Wallet created",
            "Your new DeroM address:\n\n" + data["address"] +
            "\n\nwallet.json now holds its private key.\n"
            "Use 'Backup wallet file' to keep it safe!")

    def on_copy_address(self):
        self.copy_to_clipboard(self.addr, "Address copied to clipboard")

    def on_save_address(self):
        if not self.addr:
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".txt", initialfile="DeroM_address.txt",
            filetypes=[("Text file", "*.txt")], parent=self.root)
        if not path:
            return
        stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(
                f"DeroM ({TICKER}) address - saved {stamp}\n"
                f"{'=' * 46}\n\nAddress:\n{self.addr}\n\n"
                f"Miner username:\n{self.addr}.worker1\n\n"
                f"Stratum URL (official):\n"
                f"stratum+tcp://derom.surge.sh:{STRATUM_PORT}\n\n"
                f"Stratum URL (this PC / LAN):\n"
                f"stratum+tcp://{local_ip()}:{STRATUM_PORT}\n")
        self.log(f"Address saved to {path}", "ok")

    def on_backup_wallet(self):
        if not os.path.exists(WALLET_PATH):
            messagebox.showinfo("No wallet", "Create a wallet first.")
            return
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M")
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            initialfile=f"derom_wallet_backup_{stamp}.json",
            filetypes=[("JSON", "*.json")], parent=self.root)
        if not path:
            return
        shutil.copy2(WALLET_PATH, path)
        self.log(f"Wallet backed up to {path}", "ok")
        messagebox.showwarning(
            "Backup saved",
            "This file contains your PRIVATE KEY.\n"
            "Anyone who gets it can spend your coins - store it safely.")

    def on_export_key(self):
        if not self.priv_hex:
            return
        if not messagebox.askyesno(
                "Export private key?",
                "The private key controls ALL coins in this wallet.\n"
                "Anyone who sees it can steal everything.\n\n"
                "Export it anyway?"):
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            initialfile="derom_PRIVATE_KEY_keep_secret.txt",
            filetypes=[("Text file", "*.txt")], parent=self.root)
        if not path:
            return
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(
                "!!! TOP SECRET - DeroM PRIVATE KEY !!!\n"
                "Anyone holding this key owns the funds.\n\n"
                f"Address    : {self.addr}\n"
                f"Private key: {self.priv_hex}\n")
        self.log(f"Private key exported to {path}", "warn")

    # ------------------------------------------------------------ guide

    def refresh_guide(self):
        ip = local_ip()
        url = f"stratum+tcp://derom.surge.sh:{STRATUM_PORT}"
        user = f"{self.addr or '<your-address>'}.worker1"
        self.url_var.set(url)
        self.user_var.set(user)
        steps = [
            ('1. ', 'Click "Start node" above and leave it running.'),
            ('2. ', 'Put your ASIC/miner on reachable network and open its '
                    'web interface or config.'),
            ('3. ', 'Paste STRATUM URL and MINER USERNAME below '
                    '(Password = x), then start mining.'),
            ('4. ', 'Every solved block pays 50 DEROM straight to your '
                    'address - watch ACTIVITY and BALANCE here.'),
        ]
        tips = ("derom.surge.sh:3333 is the official mining hostname; it only "
                "reaches this pool if that name points at (or is forwarded to) "
                f"this PC. On a private LAN use stratum+tcp://{ip}:{STRATUM_PORT} "
                "instead. Allow TCP 3333 through Windows Firewall when the miner "
                "runs on another device.")
        self.guide.config(state="normal")
        self.guide.delete("1.0", "end")
        for num, text in steps:
            self.guide.insert("end", num, "step")
            self.guide.insert("end", text + "\n")
        self.guide.insert("end", "\n" + tips, "dim")
        self.guide.config(state="disabled")

    # ------------------------------------------------------------ node

    def _autostart(self):
        try:
            rpc("getinfo", timeout=1.5)
            self.log("Node already running.", "ok")
        except Exception:
            self.start_node()

    def start_node(self):
        def work():
            try:
                rpc("getinfo", timeout=1.0)
                self.log("Node is already running.", "ok")
                return
            except Exception:
                pass
            try:
                ensure_default_config(CONFIG_PATH)
                cfg = _load_node_config(CONFIG_PATH)
                self.runner = NodeRunner(cfg)
                self.runner.start()
                self.log("Node started (running inside this app).", "ok")
            except Exception as exc:  # noqa: BLE001 - shown to user
                self.log(f"Node failed to start: {exc}", "err")
                messagebox.showerror("Node failed",
                                     f"Could not start the node:\n{exc}\n\n"
                                     "Is another DeroM node already "
                                     "using ports 3333/8570?")
        threading.Thread(target=work, daemon=True).start()

    def stop_node(self):
        def work():
            try:
                if getattr(self, "runner", None) is not None:
                    self.runner.stop()
                else:
                    rpc("stop", timeout=2)   # node started outside the GUI
            except Exception:
                pass
            self.log("Node stopped.", "warn")
        threading.Thread(target=work, daemon=True).start()

    def view_node_log(self):
        path = os.path.join(DATA_DIR, "node_console.log")
        if not os.path.exists(path):
            messagebox.showinfo("No log yet",
                                "Start the node once and a log appears.")
            return
        os.startfile(path)      # opens in the default text editor

    # ------------------------------------------------------------ polling

    def poll_loop(self):
        threading.Thread(target=self._poll_worker, daemon=True).start()
        self.root.after(2500, self.poll_loop)

    def _poll_worker(self):
        info, acct = None, None
        try:
            info = rpc("getinfo", timeout=1.5)
            if self.addr:
                acct = rpc("getaccount", [self.addr], timeout=1.5)
        except Exception:
            pass
        self.root.after(0, lambda: self.apply_status(info, acct))

    def apply_status(self, info, acct):
        running = info is not None
        if running != self.node_running:
            if running:
                self.log("Node is online.", "ok")
            else:
                self.log("Node is offline.", "warn")
        self.node_running = running

        if not running:
            self.dot.config(text="\u25cf OFFLINE", fg=RED)
            self.btn_start.config(state="normal")
            self.btn_stop.config(state="disabled")
            for lbl in self.stats.values():
                lbl.config(text="-")
            self.bal_var.set("-- (node offline)")
            return

        self.dot.config(text="\u25cf RUNNING", fg=GREEN)
        self.btn_start.config(state="disabled")
        self.btn_stop.config(state="normal")
        self.stats["Height"].config(text=str(info.get("height", "-")))
        self.stats["Difficulty"].config(text=str(info.get("difficulty", "-")))
        reward = info.get("next_reward_atoms", 0) / txlib.ATOMS_PER_DEROM
        self.stats["Reward"].config(text=f"{reward:g} {TICKER}")
        self.stats["Miners"].config(text=str(info.get("miners_connected", 0)))
        self.stats["Mempool"].config(text=str(info.get("mempool_size", 0)))
        if acct is not None:
            atoms = acct.get("balance", 0)
            self.bal_var.set(f"{fmt_coins(atoms)} {TICKER}")

    # ------------------------------------------------------------ send

    def do_send(self):
        dest = self.to_var.get().strip()
        if not self.addr or not self.priv_hex:
            messagebox.showwarning("No wallet", "Create a wallet first.")
            return
        if not address_is_valid(dest):
            messagebox.showerror(
                "Bad address",
                "Destination is not a valid DeroM address "
                "(it should start with D).")
            return
        if not self.node_running:
            messagebox.showwarning("Node offline",
                                   "Start the node before sending.")
            return
        try:
            amount = float(self.amt_var.get())
            fee = float(self.fee_var.get() or 0.001)
        except ValueError:
            messagebox.showerror("Bad number",
                                 "Amount and fee must be numbers.")
            return
        min_fee = txlib.MIN_FEE_ATOMS / txlib.ATOMS_PER_DEROM
        if amount <= 0 or fee < min_fee:
            messagebox.showerror(
                "Bad amount",
                f"Amount must be positive and the fee at least {min_fee:g}.")
            return
        if not messagebox.askyesno(
                "Confirm transfer",
                f"Send {amount:g} {TICKER} (+{fee:g} fee)\n"
                f"to\n{dest}\n\nContinue?"):
            return

        def work():
            self.root.after(0,
                            lambda: self.btn_send.config(state="disabled"))
            try:
                acct = rpc("getaccount", [self.addr])
                tx = txlib.make_spend(
                    bytes.fromhex(self.priv_hex), dest,
                    int(round(amount * txlib.ATOMS_PER_DEROM)),
                    int(round(fee * txlib.ATOMS_PER_DEROM)),
                    acct["next_nonce"])
                tid = rpc("submittransaction", [tx])
                self.log(f"Sent {amount:g} {TICKER} -> tx {tid[:16]}..", "ok")

                def done():
                    self.btn_send.config(state="normal")
                    self.to_var.set("")
                    self.amt_var.set("")
                    messagebox.showinfo(
                        "Sent!",
                        f"Transaction submitted:\n{tid}\n\n"
                        "It will be included in the next block mined.")
                self.root.after(0, done)
            except Exception as exc:  # noqa: BLE001
                # Capture the message NOW: Python deletes `exc` when this
                # except block exits (PEP 3110), and fail() runs later via
                # root.after - closing over `exc` directly would NameError.
                err_text = f"Send failed: {exc}"
                self.log(err_text, "err")

                def fail(msg=err_text):
                    self.btn_send.config(state="normal")
                    messagebox.showerror("Send failed", msg)
                self.root.after(0, fail)
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------ test miner

    def run_test_miner(self):
        if not self.node_running:
            messagebox.showwarning("Node offline", "Start the node first.")
            return

        # A CPU cannot realistically hit ASIC-level network difficulty -
        # be honest about it instead of running a futile 30s loop.
        def work():
            try:
                net_diff = float(rpc("getdifficulty", timeout=4))
            except Exception:
                net_diff = None
            if net_diff is not None and net_diff > 1000:
                self.log(f"CPU test mining skipped: network difficulty "
                         f"({net_diff:,.0f}) is ASIC-level.", "warn")

                def inform():
                    self.btn_testmine.config(
                        state="normal",
                        text="Test-mine 30s (CPU, no ASIC needed)")
                    messagebox.showinfo(
                        "ASIC-level difficulty",
                        f"Network difficulty is {net_diff:,.0f} - far beyond "
                        "what a CPU can touch.\n\nThat's your ASIC miner's job "
                        "now: point it at this node and watch ACTIVITY.")
                self.root.after(0, inform)
                return

            self.root.after(0, lambda: self._run_test_miner_now())

        threading.Thread(target=work, daemon=True).start()

    def _run_test_miner_now(self):
        from .testminer import run_cpu_miner
        self.btn_testmine.config(state="disabled", text="Mining 30s...")
        self.log("CPU test miner started - watch it find real blocks!")
        result_box = {"value": {"hashes": 0, "shares": 0, "blocks": 0}}

        def work():
            try:
                result_box["value"] = run_cpu_miner(
                    f"{self.addr}.guiworker", seconds=30,
                    host="127.0.0.1",
                    port=int(CFG.get("stratum_port", 3333)),
                    log=self.log, verbose=False)
            except Exception as exc:  # noqa: BLE001
                self.log(f"Test miner failed: {exc}", "err")

            res = result_box["value"]

            def done():
                self.btn_testmine.config(
                    state="normal",
                    text="Test-mine 30s (CPU, no ASIC needed)")
                if res["blocks"]:
                    messagebox.showinfo(
                        "It works!",
                        f"Found {res['blocks']} block(s) and "
                        f"{res['shares']} shares with just your CPU.")
            self.root.after(0, done)
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------ shutdown

    def on_close(self):
        if self.node_running:
            keep = messagebox.askyesno(
                "Keep node running?",
                "Your miner may be connected to this node.\n\n"
                "Keep it running in the background after closing?\n"
                "(Yes = miner keeps hashing · No = shut everything down)")
            if not keep:
                if getattr(self, "runner", None) is not None:
                    try:
                        self.runner.stop()
                    except Exception:
                        pass
                else:
                    try:
                        rpc("stop", timeout=2)
                    except Exception:
                        pass
        self.root.destroy()


def main():
    ensure_default_config(CONFIG_PATH)
    # Frozen/windowed apps have no console - send node prints to a file so
    # the GUI's "View log" button stays useful.
    if getattr(sys, "frozen", False) or sys.stdout is None:
        os.makedirs(DATA_DIR, exist_ok=True)
        _log = open(os.path.join(DATA_DIR, "node_console.log"),
                    "a", buffering=1, encoding="utf-8")
        sys.stdout = _log
        sys.stderr = _log
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()