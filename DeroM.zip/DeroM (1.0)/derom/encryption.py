"""Encrypted wallet support for DeroM.

Provides password-protected wallet encryption/decryption using AES-256-GCM.
"""
import os
import json
import base64
from typing import Dict, Any, Optional
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes


class EncryptedWallet:
    """Handles encryption and decryption of wallet files."""
    
    # Constants for encryption
    ALGORITHM_VERSION = 1
    SALT_SIZE = 16  # bytes
    IV_SIZE = 12    # bytes (nonce for GCM)
    TAG_SIZE = 16   # bytes (authentication tag for GCM)
    KEY_SIZE = 32   # bytes (AES-256)
    ITERATIONS = 100000  # PBKDF2 iterations
    
    @staticmethod
    def derive_key(password: str, salt: bytes) -> bytes:
        """Derive encryption key from password using PBKDF2."""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=EncryptedWallet.KEY_SIZE,
            salt=salt,
            iterations=EncryptedWallet.ITERATIONS,
        )
        return kdf.derive(password.encode('utf-8'))
    
    @staticmethod
    def encrypt_wallet(wallet_data: Dict[str, Any], password: str) -> Dict[str, str]:
        """Encrypt wallet data with password.
        
        Returns:
            Dict with encrypted data and metadata:
            {
                "version": 1,
                "salt": base64-encoded salt,
                "iv": base64-encoded nonce,
                "ciphertext": base64-encoded encrypted data,
                "tag": base64-encoded authentication tag
            }
        """
        # Generate random salt and IV
        salt = os.urandom(EncryptedWallet.SALT_SIZE)
        iv = os.urandom(EncryptedWallet.IV_SIZE)
        
        # Derive key from password
        key = EncryptedWallet.derive_key(password, salt)
        
        # Serialize wallet to JSON
        plaintext = json.dumps(wallet_data).encode('utf-8')
        
        # Encrypt with AES-256-GCM
        cipher = AESGCM(key)
        ciphertext = cipher.encrypt(iv, plaintext, None)
        
        # GCM mode returns ciphertext + tag concatenated
        # We need to split them
        ciphertext_only = ciphertext[:-EncryptedWallet.TAG_SIZE]
        tag = ciphertext[-EncryptedWallet.TAG_SIZE:]
        
        return {
            "version": str(EncryptedWallet.ALGORITHM_VERSION),
            "salt": base64.b64encode(salt).decode('utf-8'),
            "iv": base64.b64encode(iv).decode('utf-8'),
            "ciphertext": base64.b64encode(ciphertext_only).decode('utf-8'),
            "tag": base64.b64encode(tag).decode('utf-8'),
        }
    
    @staticmethod
    def decrypt_wallet(encrypted_data: Dict[str, str], password: str) -> Optional[Dict[str, Any]]:
        """Decrypt wallet data with password.
        
        Args:
            encrypted_data: Dict from encrypt_wallet()
            password: Wallet password
            
        Returns:
            Decrypted wallet dict
            
        Raises:
            ValueError: If version mismatch
            cryptography.hazmat.primitives.ciphers.aead.InvalidTag: If wrong password
            json.JSONDecodeError: If decrypted data is invalid JSON
        """
        version = int(encrypted_data.get("version", 0))
        if version != EncryptedWallet.ALGORITHM_VERSION:
            raise ValueError(f"Unsupported wallet version: {version}")
        
        # Decode components
        salt = base64.b64decode(encrypted_data["salt"])
        iv = base64.b64decode(encrypted_data["iv"])
        ciphertext = base64.b64decode(encrypted_data["ciphertext"])
        tag = base64.b64decode(encrypted_data["tag"])
        
        # Derive key
        key = EncryptedWallet.derive_key(password, salt)
        
        # Decrypt - will raise InvalidTag if password is wrong (GCM tamper detection)
        cipher = AESGCM(key)
        plaintext = cipher.decrypt(iv, ciphertext + tag, None)
        
        return json.loads(plaintext.decode('utf-8'))


class WalletManager:
    """Manages multiple encrypted wallets."""
    
    def __init__(self, wallet_dir: str):
        self.wallet_dir = wallet_dir
        self.wallets: Dict[str, Dict[str, Any]] = {}
        self.passwords: Dict[str, str] = {}  # wallet_name -> password (in memory)
    
    def create_encrypted_wallet(self, name: str, password: str, 
                               wallet_data: Dict[str, Any]) -> bool:
        """Create an encrypted wallet file.
        
        Args:
            name: Wallet name (used as filename)
            password: Encryption password
            wallet_data: Wallet data to encrypt
            
        Returns:
            True if successful, False otherwise
        """
        try:
            encrypted = EncryptedWallet.encrypt_wallet(wallet_data, password)
            
            # Save to file
            path = os.path.join(self.wallet_dir, f"wallet_encrypted_{name}.json")
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(encrypted, f, indent=2)
            
            # Restrict permissions
            try:
                os.chmod(path, 0o600)
            except OSError:
                pass
            
            # Cache in memory
            self.wallets[name] = wallet_data
            self.passwords[name] = password
            
            return True
        except Exception as e:
            print(f"Error creating encrypted wallet: {e}")
            return False
    
    def load_encrypted_wallet(self, name: str, password: str) -> Optional[Dict[str, Any]]:
        """Load and decrypt an encrypted wallet.
        
        Args:
            name: Wallet name
            password: Encryption password
            
        Returns:
            Decrypted wallet data, or None if failed
        """
        try:
            path = os.path.join(self.wallet_dir, f"wallet_encrypted_{name}.json")
            
            if not os.path.exists(path):
                return None
            
            with open(path, 'r', encoding='utf-8') as f:
                encrypted_data = json.load(f)
            
            wallet_data = EncryptedWallet.decrypt_wallet(encrypted_data, password)
            
            if wallet_data:
                self.wallets[name] = wallet_data
                self.passwords[name] = password
            
            return wallet_data
        except Exception as e:
            print(f"Error loading encrypted wallet: {e}")
            return None
    
    def list_encrypted_wallets(self) -> list:
        """List all encrypted wallets in the directory."""
        wallets = []
        try:
            for file in os.listdir(self.wallet_dir):
                if file.startswith("wallet_encrypted_") and file.endswith(".json"):
                    name = file.replace("wallet_encrypted_", "").replace(".json", "")
                    wallets.append(name)
        except OSError:
            pass
        return sorted(wallets)
    
    def export_public_data(self, name: str) -> Optional[Dict[str, str]]:
        """Export public wallet data (address, public key, etc.) without decryption."""
        try:
            path = os.path.join(self.wallet_dir, f"wallet_encrypted_{name}.json")
            
            if not os.path.exists(path):
                return None
            
            with open(path, 'r', encoding='utf-8') as f:
                encrypted_data = json.load(f)
            
            # We can't decrypt without password, but we can extract non-sensitive info
            # from the filename or other metadata if stored separately
            return None  # Would need separate metadata file
        except Exception:
            return None
