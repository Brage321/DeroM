        if force or cur <= 0 or abs(eff - cur) / max(cur, 1e-9) >= 0.10:
            self.share_difficulty = round(eff, 8)
            self.share_target = difficulty_to_target(self.share_difficulty)
            await self.send_set_difficulty()
            # Firmware must regenerate its work pipeline to apply the new
            # target; always follow a difficulty change with a clean job.
            if self.job is not None:
                await self.push_job(clean=True)
            return True
        return False