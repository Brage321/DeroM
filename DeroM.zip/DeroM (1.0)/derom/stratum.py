"""DeroM stratum mining server - hardened for real ASIC firmware
(any SHA-256 ASIC miner: Antminer, Whatsminer, Avalon, ESP-Miner boards,
cgminer/BFGMiner-family builds, Awesome Miner proxies).

Compatibility notes baked in:
  - authorize works even if the firmware never sent subscribe
  - unknown methods (mining.configure etc.) get success, not errors
  - lenient hex parsing (short/odd-length extranonce2 & co)
  - TCP_NODELAY for snappy job pushes
  - effective share difficulty never exceeds network difficulty
    (so early low-diff chain life still yields shares & blocks)
  - ntime refresh issues a NEW job id (clean=False), firmware-safe
"""
import asyncio
import json
import math
import secrets
import socket
import time

from . import block as blk
from . import tx as txlib
from .crypto import (address_is_valid, difficulty_to_target,
                     merkle_branch, merkle_root_from_branch, sha256d,
                     target_to_difficulty)

MAX_TXS_PER_BLOCK = 200
VARDIFF_WINDOW = 30.0        # seconds between vardiff evaluations
VARDIFF_TARGET_DT = 15.0     # aim for roughly one share per this many seconds

DEFAULT_SHARE_DIFFICULTY = 5.0
# MOST ASIC control boards parse mining.set_difficulty as an INTEGER:
# pushing a fractional value (0.001, 0.5, ...) makes them produce ZERO
# valid hashes -> 100% error rate. Automatic difficulties therefore stay
# at safe integers >= HARDWARE_MIN_DIFFICULTY; anything smaller is only
# ever honored per-session when the CLIENT ITSELF requests it through
# mining.suggest_difficulty (that is how our CPU/GUI test rig operates).
HARDWARE_MIN_DIFFICULTY = 1.0
MICRO_MIN_DIFFICULTY = 0.001


def hardware_safe_difficulty(value: float) -> float:
    """Clamp an automatic/configured difficulty into the range real mining
    firmware can consume: whole numbers >= HARDWARE_MIN_DIFFICULTY."""
    try:
        value = float(value)
    except (TypeError, ValueError):
        return DEFAULT_SHARE_DIFFICULTY
    whole = float(math.ceil(value))
    return max(whole, HARDWARE_MIN_DIFFICULTY)

ERRORS = {20: "Other/Unknown", 21: "Job not found", 22: "Invalid worker",
          23: "Low difficulty share", 24: "Unauthorized worker",
          25: "Not subscribed"}


class StratumError(Exception):
    def __init__(self, code, message=""):
        self.code = code
        self.message = message
        super().__init__(message)


def parse_hex_field(value, size_bytes: int) -> bytes | None:
    """Tolerant hex parsing for miner-submitted fields.

    Accepts ints, strips 0x/spaces, pads odd nibbles, right-aligns to
    size_bytes. Returns None when unrecoverable."""
    if isinstance(value, int):
        value = f"{value:x}"
    text = str(value).strip().lower().replace("0x", "").replace(" ", "")
    if text == "":
        text = "0"
    if len(text) % 2:
        text = "0" + text
    want = size_bytes * 2
    if len(text) > want:                    # keep least-significant part
        text = text[-want:]
    if len(text) < want:
        text = text.zfill(want)
    try:
        return bytes.fromhex(text)
    except ValueError:
        return None


class Job:
    """Container for everything needed to rebuild headers from submits."""

    __slots__ = ("id", "height", "prev_display", "cb1", "cb2", "branch",
                 "version", "nbits", "ntime", "target", "spends", "fees")

    def notify_params(self, clean):
        """Spec-correct mining.notify params:
        [job_id, prevhash, coinb1, coinb2, merkle_branch, version, nbits,
         ntime, clean]"""
        prev_wire = bytes.fromhex(self.prev_display)[::-1].hex()
        return [self.id, prev_wire, self.cb1, self.cb2,
                list(self.branch), f"{self.version:08x}", f"{self.nbits:08x}",
                f"{self.ntime:08x}", clean]


class Session:
    """One connected miner."""

    def __init__(self, server, reader, writer):
        self.server = server
        self.reader = reader
        self.writer = writer
        self.peer = str(writer.get_extra_info("peername"))
        self.subscribed = False
        self.authorized = False
        self.username = ""
        self.worker = "worker"
        self.payout_address = None
        self.extranonce1 = secrets.token_hex(4)
        self.en2_size = 4
        cfg = server.node.cfg
        # Firmware-safe integer START difficulty; fractional values would
        # silently break most ASIC control boards (see constants above).
        self.desired_difficulty = hardware_safe_difficulty(
            cfg.get("default_share_difficulty", DEFAULT_SHARE_DIFFICULTY))
        self.micro_requested = False         # opted out of the hw floor
        self.share_difficulty = 0.0          # effective; synced on first job
        self.share_target = difficulty_to_target(self.desired_difficulty)
        self.job = None
        self.jobs = {}
        self.shares_ok = 0
        self.shares_bad = 0
        self.bad_streak = 0                 # consecutive invalid submits
        self.blocks_found = 0
        self.last_share_time = time.time()
        self.last_vardiff = time.time()
        self.share_dts = []
        self.disconnect_reason = ""

    async def send(self, obj):
        line = json.dumps(obj)
        if self.server.node.cfg.get("debug_stratum"):
            self.server.node.log(
                f"[tx-> {self.peer}] {line[:200]}")
        try:
            self.writer.write((line + "\n").encode("utf-8"))
            await self.writer.drain()
        except (ConnectionResetError, BrokenPipeError, OSError) as exc:
            self.disconnect_reason = f"send failed: {exc}"

    async def run(self):
        buf = b""
        try:
            while True:
                data = await self.reader.read(8192)
                if not data:
                    self.disconnect_reason = "client closed"
                    break
                buf += data
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    line = line.strip()
                    if line:
                        await self.handle_line(line.decode("utf-8", "replace"))
        except Exception as exc:            # noqa: BLE001 - recorded + closed
            self.disconnect_reason = f"{type(exc).__name__}: {exc}"

    async def handle_line(self, text):
        try:
            msg = json.loads(text)
        except ValueError:
            self.server.node.log(
                f"[stratum] {self.peer} sent unparsable line "
                f"({len(text)} bytes) - ignored")
            return
        mid, method = msg.get("id"), msg.get("method")
        params = msg.get("params") or []
        try:
            handler = getattr(self, "rpc_" + str(method).replace(".", "_"),
                              None)
            if handler is None:
                # Firmware extras (mining.configure, mining.get_features,
                # mining.suggest_difficulty ...) must NOT error out - some
                # clients reconnect-loop when optional calls fail.
                self.server.node.log(
                    f"[stratum] tolerated unsupported method {method!r} "
                    f"from {self.username or self.peer}")
                await self.send({"id": mid, "result": True, "error": None})
                return
            result = await handler(params)
            await self.send({"id": mid, "result": result, "error": None})
        except StratumError as exc:
            desc = exc.message or ERRORS.get(exc.code, "error")
            await self.send({"id": mid, "result": None,
                             "error": [exc.code, desc, None]})
        except Exception as exc:  # noqa: BLE001
            self.server.node.log(f"[stratum] handler error: {exc}")
            await self.send({"id": mid, "result": None,
                             "error": [20, f"internal: {exc}", None]})

    # ------------------------------------------------------ difficulty sync

    def share_floor(self) -> float:
        """Lowest difficulty this session may receive. Real hardware gets
        the >=1 firmware-safe floor; sessions that explicitly asked for
        micro-difficulty (CPU/GUI test rigs) may go lower."""
        if self.micro_requested:
            return MICRO_MIN_DIFFICULTY
        return HARDWARE_MIN_DIFFICULTY

    def effective_difficulty(self) -> float:
        """Never ask hardware for more precision than the chain itself:
        effective = min(desired, network). Keeps shares flowing (and blocks
        findable) while network difficulty is still ramping up."""
        try:
            net = target_to_difficulty(self.server.chain.next_target)
        except Exception:
            net = None
        if net is None:
            eff = self.desired_difficulty
        else:
            eff = min(self.desired_difficulty, net)
        return max(eff, self.share_floor())

    async def sync_difficulty(self, force=False) -> bool:
        """Push effective difficulty to the miner when it drifted >=10%.
        Always follows with a CLEAN job - every real pool does this, and
        ASIC firmware drops its stale queued work instead of wasting time
        (and rejection bursts) hashing against the old difficulty."""
        eff = self.effective_difficulty()
        cur = self.share_difficulty
        if force or cur <= 0 or abs(eff - cur) / max(cur, 1e-9) >= 0.10:
            self.share_difficulty = round(eff, 8)
            self.share_target = difficulty_to_target(self.share_difficulty)
            await self.send_set_difficulty()
            await self.push_job(clean=True)
            return True
        return False

    # ------------------------------------------------------------- methods

    async def rpc_mining_configure(self, params):
        """Firmware asks for extensions (several ASIC firmwares send
        version-rolling).
        We must answer with an OBJECT explicitly disabling anything we don't
        support - a bare `true` lets some firmware start mutating the version
        field, which invalidates every share we reconstruct."""
        wanted = []
        try:
            wanted = list(params[0]) if params else []
        except Exception:
            wanted = []
        result = {}
        for ext in wanted:
            if ext == "version-rolling":
                result["version-rolling.enabled"] = False
                result["version-rolling.mask"] = "00000000"
            else:
                result[f"{ext}.enabled"] = False
        self.server.node.log(
            f"[stratum] mining.configure -> {result or 'empty'}")
        return result

    async def rpc_mining_suggest_difficulty(self, params):
        """Honor a difficulty proposal from ANY ASIC (most cgminer-family
        firmware sends one right after authorize). Clamped into our range;
        the miner knows its own throughput best."""
        try:
            want = float(params[0])
        except Exception:
            return True
        try:
            vmax = float(self.server.node.cfg.get("vardiff_max", 2000000))
        except Exception:
            vmax = 2000000.0
        want = min(max(want, MICRO_MIN_DIFFICULTY), vmax)
        # Hysteresis mirror of var-diff: proposals within 10% of the
        # difficulty we already run change nothing - re-syncing on them
        # would clean-job churn and starve the miner of stable work.
        if abs(want - self.desired_difficulty) <= 0.10 * max(
                self.desired_difficulty, 1e-9):
            return True
        # A proposal BELOW the hardware floor only comes from our own
        # CPU/GUI test rigs (real ASICs never need it) - honor it verbatim
        # for THIS session, flagged so varDiff/idle-rescue never push
        # fractional difficulties anywhere by themselves.
        self.micro_requested = want < HARDWARE_MIN_DIFFICULTY
        self.desired_difficulty = want
        await self.sync_difficulty(force=True)
        self.server.node.log(
            f"[stratum] {self.worker} suggested difficulty "
            f"{params[0]} -> using {self.share_difficulty}"
            + (" (micro opt-in)" if self.micro_requested else ""))
        return True

    async def rpc_mining_subscribe(self, params):
        self.subscribed = True
        token = secrets.token_hex(8)
        return [[["mining.set_difficulty", token[:8]],
                 ["mining.notify", token]],
                self.extranonce1, self.en2_size]

    async def rpc_mining_authorize(self, params):
        if not self.subscribed:
            # Some firmware authorizes without subscribing - tolerate it by
            # synthesizing the subscription instead of erroring.
            self.subscribed = True
        user = str(params[0]) if params else ""
        addr = user.split(".")[0].strip()
        if not address_is_valid(addr):
            raise StratumError(
                22, "username must start with a valid DeroM payout "
                    "address: connect as <your_address>.<worker>")
        self.username = user
        self.payout_address = addr
        self.worker = user.split(".", 1)[1] if "." in user else "worker"
        self.authorized = True
        self.server.node.log(f"[stratum] authorized {user} ({self.peer})")
        # Classic pool ordering: difficulty + first job go out INLINE before
        # the ack (no task-scheduling surprises), each step guarded so the
        # ack always reaches the firmware.
        try:
            await self.sync_difficulty(force=True)
            await self.push_job(clean=True)
        except Exception as exc:  # noqa: BLE001 - ack must still be sent
            self.server.node.log(
                f"[stratum] post-authorize problem for {user}: "
                f"{type(exc).__name__}: {exc}")
        return True

    async def send_set_difficulty(self):
        await self.send({"id": None, "method": "mining.set_difficulty",
                         "params": [self.share_difficulty]})

    async def push_job(self, clean=True):
        try:
            job = self.server.build_job(self)
        except Exception as exc:  # noqa: BLE001 - log, keep session alive
            self.server.node.log(
                f"[stratum] build_job failed for {self.username}: "
                f"{type(exc).__name__}: {exc}")
            return
        if job is None:
            return
        self.job = job
        self.jobs[job.id] = job
        while len(self.jobs) > 60:
            self.jobs.pop(next(iter(self.jobs)))
        await self.send({"id": None, "method": "mining.notify",
                         "params": job.notify_params(clean)})

    # ------------------------------------------------------ reconstruction

    def _en2_candidates(self, en2_raw):
        """Extranonce2 variants seen across ASIC firmware: the value
        normalized to our advertised size AND the verbatim bytes exactly as
        submitted. Different-length encodings change the coinbase bytes, so
        both must be tried before declaring a share invalid."""
        out = []
        norm = parse_hex_field(en2_raw, self.en2_size)
        if norm is not None:
            out.append(norm)
        text = str(en2_raw).strip().lower().replace("0x", "").replace(" ", "")
        if len(text) % 2:
            text = "0" + text
        try:
            verbatim = bytes.fromhex(text) if text else None
        except ValueError:
            verbatim = None
        if verbatim is not None and len(verbatim) <= 64 and verbatim not in out:
            out.append(verbatim)
        return out or [b"\x00" * self.en2_size]

    @staticmethod
    def _reconstructions(job, en1_hex, en2_bytes, extras, ntime, nonce):
        """Yield (cb_raw, header_raw, powval) under each merkle-fold
        convention ASIC firmware actually uses: index 0 (fold never shifted;
        common in compact embedded firmwares) and index=en2%leaf_count
        (classic stratum position). Every yield is a fully consistent
        reconstruction - whichever validates can build the block directly."""
        cb_raw = blk.assemble_coinbase_raw(job.cb1, job.cb2,
                                           en1_hex, en2_bytes.hex())
        cb_digest = sha256d(cb_raw)
        leaves = 1 + len(extras)
        indices = [0]
        alt = int.from_bytes(en2_bytes, "big") % leaves
        if alt not in indices:
            indices.append(alt)
        for idx in indices:
            branch = merkle_branch([cb_digest] + extras, idx)
            root = merkle_root_from_branch(cb_digest, branch, idx)
            header_raw = blk.pack_header(job.version, job.prev_display,
                                          blk.hash_display(root), ntime,
                                          job.nbits, nonce)
            powval = int.from_bytes(sha256d(header_raw), "little")
            yield cb_raw, header_raw, root, powval

    # ------------------------------------------------------------- submits

    async def rpc_mining_submit(self, params):
        if not self.authorized:
            raise StratumError(24)
        if len(params) >= 5:
            _, jid, en2_raw, ntime_raw, nonce_raw = params[:5]
        elif len(params) == 4:
            jid, en2_raw, ntime_raw, nonce_raw = params
        else:
            raise StratumError(20,
                               "expected [worker, job_id, extranonce2, "
                               "ntime, nonce]")
        job = self.jobs.get(str(jid))
        if job is None:
            raise StratumError(21)

        try:
            ntime_b = parse_hex_field(ntime_raw, 4)
            nonce_b = parse_hex_field(nonce_raw, 4)
            if ntime_b is None or nonce_b is None:
                raise ValueError
            ntime = int.from_bytes(ntime_b, "big")
            nonce = int.from_bytes(nonce_b, "big")
        except Exception:
            raise StratumError(20, "bad ntime/nonce encoding")

        now = time.time()
        if abs(ntime - now) > 5400:
            raise StratumError(20, "ntime too far from server clock")

        # Rebuild under every firmware convention until one matches. A share
        # only validates against its own consistent reconstruction, so the
        # winner (en2, coinbase, header) is carried through for blocks too.
        extras = [txlib.tx_digest(t) for t in job.spends]
        best = None
        chosen = None
        for en2 in self._en2_candidates(en2_raw):
            for cb_raw, header_raw, root, powval in self._reconstructions(
                    job, self.extranonce1, en2, extras, ntime, nonce):
                cand = {"en2": en2, "cb_raw": cb_raw,
                        "header_raw": header_raw,
                        "merkle": blk.hash_display(root),
                        "powval": powval}
                if best is None:
                    best = cand
                if powval <= job.target or powval <= self.share_target:
                    chosen = cand
                    break
            if chosen is not None:
                break

        dt = max(now - self.last_share_time, 1e-6)

        if chosen is None:
            cand = best
            self.last_share_time = now
            self.shares_bad += 1
            if (self.server.node.cfg.get("debug_stratum")
                    and cand is not None and self.shares_bad <= 5):
                powval = cand["powval"]
                cb_raw = cand["cb_raw"]
                header_raw = cand["header_raw"]
                en2_hex = cand["en2"].hex()
                self.server.node.log(
                    f"[share-reject] {self.worker}: powval={powval:x} "
                    f"share_target={self.share_target:x} "
                    f"block_target={job.target:x}")
                self.server.node.log(
                    f"[share-reject] {self.worker}: "
                    f"header={header_raw.hex()} "
                    f"cb_raw={cb_raw.hex()} "
                    f"en2={en2_hex} nonce={nonce} "
                    f"prev={job.prev_display} nbits={job.nbits:08x} "
                    f"version={job.version:08x} ntime={ntime}")
                if self.shares_bad % 25 == 0:
                    # Ongoing forensics: don't go blind after the first few.
                    self.server.node.log(
                        f"[share-reject] {self.worker} #{self.shares_bad}: "
                        f"header={header_raw.hex()} "
                        f"cb_raw={cb_raw.hex()} en2={en2_hex} "
                        f"nonce={nonce} ntime={ntime}")
            # Hardware safety valve: some control boards acknowledge a
            # difficulty change yet keep hashing at their OLD target
            # (stale pipeline / half-applied config). Their work then never
            # meets our target, so they'd sit at accepted=0 forever while
            # flooding rejections. Real pools ease difficulty on exactly
            # this pattern; var-diff walks it back up once shares validate.
            self.bad_streak += 1
            stuck_from_start = (self.shares_ok == 0
                                and self.shares_bad >= 10)
            chronic = self.bad_streak >= 30
            # Re-ease at most every RE_EASE_SECONDS, never below hw floor.
            re_ease = (now - getattr(self, "last_re_ease", 0.0)) > 20.0
            if ((stuck_from_start or chronic) and re_ease
                    and self.desired_difficulty > HARDWARE_MIN_DIFFICULTY
                    and not self.micro_requested):
                self.desired_difficulty = max(
                    self.desired_difficulty / 2.0, HARDWARE_MIN_DIFFICULTY)
                self.last_re_ease = now
                self.bad_streak = 0
                await self.sync_difficulty(force=True)
                self.server.node.log(
                    f"[stratum] {self.worker} invalid-work streak "
                    f"(ok={self.shares_ok}) - easing difficulty to "
                    f"{self.share_difficulty}")
            raise StratumError(23)

        cb_raw = chosen["cb_raw"]
        header_raw = chosen["header_raw"]
        powval = chosen["powval"]
        self.last_share_time = now
        block_found = powval <= job.target

        self.shares_ok += 1
        self.bad_streak = 0
        self.share_dts.append(dt)
        del self.share_dts[:-60]
        if (self.server.node.cfg.get("debug_stratum")
                and self.shares_ok <= 5):
            self.server.node.log(
                f"[share-ok] {self.worker}: #{self.shares_ok} "
                f"{'BLOCK!' if block_found else ''}")

        if block_found:
            ok, msg = self.server.accept_block(
                job, self, cb_raw, chosen["en2"].hex(), ntime, nonce,
                merkle_display=chosen["merkle"])
            bh = blk.hash_display(sha256d(header_raw))
            if ok:
                self.blocks_found += 1
                self.server.node.log(
                    f"*** BLOCK #{job.height} solved by {self.username} "
                    f"hash {bh[:24]}.. reward -> {self.payout_address}")
            else:
                self.server.node.log(
                    f"[stratum] candidate {bh[:16]}.. not added: {msg}")

        self.server.maybe_vardiff(self)
        return True


class StratumServer:
    """Listening socket + job construction + block acceptance."""

    def __init__(self, node):
        self.node = node
        self.sessions = set()
        self.job_counter = 0
        self.server = None
        self.ntime_task = None

    @property
    def chain(self):
        return self.node.chain

    @property
    def mempool(self):
        return self.node.mempool

    def miner_count(self):
        return sum(1 for s in self.sessions if s.authorized)

    def next_job_id(self) -> str:
        self.job_counter += 1
        return f"{self.job_counter:x}"

    # ------------------------------------------------------------- jobs

    def build_job(self, session):
        spends = self.mempool.by_fee_desc()[:MAX_TXS_PER_BLOCK]
        quote, err = self.chain.quote_block(spends)
        if err:
            self.node.log(f"[stratum] mempool txs invalid, skipping: {err}")
            quote, err = self.chain.quote_block([])
            if err:
                return None
        job = Job()
        job.id = self.next_job_id()
        job.height = quote["height"]
        job.prev_display = quote["prev"]
        job.spends = quote["spends"]
        job.fees = quote["fees"]
        job.version = blk.BLOCK_VERSION
        job.nbits = quote["nbits"]
        job.ntime = int(time.time())
        job.target = quote["target"]
        value = self.chain.subsidy(job.height) + quote["fees"]
        placeholder = "00" * session.en2_size
        job.cb1, job.cb2 = blk.build_coinbase_parts(
            session.payout_address, value, job.height,
            session.extranonce1, placeholder)
        extras = [txlib.tx_digest(t) for t in quote["spends"]]
        branch = merkle_branch([b"\x00" * 32] + extras, 0) if extras else []
        job.branch = [b.hex() for b in branch]
        return job

    def accept_block(self, job, session, cb_raw, en2_hex, ntime, nonce,
                     merkle_display=None):
        """Assemble + validate + apply a winning share as a real block.
        `merkle_display` pins the EXACT root of the validated reconstruction
        so the committed block can never drift from its winning share."""
        value = self.chain.subsidy(job.height) + job.fees
        cbtx = {
            "type": "coinbase", "to": session.payout_address,
            "amount": value, "height": job.height,
            "extra": int.from_bytes(sha256d(cb_raw)[:8], "big"),
            "raw": cb_raw.hex(), "en2": en2_hex,
        }
        txs = [cbtx] + list(job.spends)
        if merkle_display is None:
            root = blk.coinbase_merkle_root(
                txlib.tx_digest(cbtx),
                [txlib.tx_digest(t) for t in txs[1:]],
                int.from_bytes(bytes.fromhex(en2_hex), "big"))
            merkle_display = blk.hash_display(root)
        header = {
            "version": job.version, "prev": job.prev_display,
            "merkle": merkle_display, "ntime": ntime,
            "nbits": job.nbits, "nonce": nonce,
        }
        raw = blk.pack_header(header["version"], header["prev"],
                              header["merkle"], ntime, job.nbits, nonce)
        block = {"hash": blk.hash_display(sha256d(raw)),
                 "height": job.height, "header": header, "txs": txs}
        ok, msg = self.chain.add_block(block)
        if ok:
            self.node.on_new_tip(block)
            asyncio.ensure_future(self.broadcast_jobs(clean=True))
        return ok, msg

    async def broadcast_jobs(self, clean=True):
        for s in list(self.sessions):
            if s.authorized:
                await s.push_job(clean=clean)

    async def ntime_refresh_loop(self):
        """Periodic housekeeping:
        - fresh ntime under a NEW job id (firmware-safe, clean=False)
        - rescue quiet workers: halve difficulty after 45s of silence
        """
        while True:
            await asyncio.sleep(20)
            now = int(time.time())
            for s in list(self.sessions):
                if not s.authorized or s.job is None:
                    continue
                idle = time.time() - s.last_share_time
                if (45 < idle and not s.micro_requested
                        and s.desired_difficulty > HARDWARE_MIN_DIFFICULTY):
                    s.desired_difficulty = max(s.desired_difficulty / 2,
                                               HARDWARE_MIN_DIFFICULTY)
                    s.share_dts.clear()
                    await s.sync_difficulty(force=True)
                    self.node.log(f"[stratum] {s.username} idle {idle:.0f}s "
                                  f"- difficulty lowered to "
                                  f"{s.share_difficulty}")
                s.job.ntime = now
                new_id = self.next_job_id()
                s.job.id = new_id
                s.jobs[new_id] = s.job
                while len(s.jobs) > 60:
                    s.jobs.pop(next(iter(s.jobs)))
                await s.send({"id": None, "method": "mining.notify",
                              "params": s.job.notify_params(False)})

    def maybe_vardiff(self, session):
        now = time.time()
        if now - session.last_vardiff < VARDIFF_WINDOW:
            return
        session.last_vardiff = now
        if session.micro_requested:
            return                       # client manages its own difficulty
        if len(session.share_dts) < 4:
            return                       # not enough evidence to raise yet
        avg_dt = sum(session.share_dts) / len(session.share_dts)
        if avg_dt < VARDIFF_TARGET_DT / 2:
            session.desired_difficulty *= 2.0
        elif avg_dt > VARDIFF_TARGET_DT * 2:
            session.desired_difficulty /= 2.0
        # Hardware floor wins even if an older config file still carries a
        # tiny vardiff_min from a previous install.
        lo = max(float(self.node.cfg.get("vardiff_min",
                                         MICRO_MIN_DIFFICULTY)),
                 HARDWARE_MIN_DIFFICULTY)
        hi = float(self.node.cfg.get("vardiff_max", 500000.0))
        session.desired_difficulty = min(max(session.desired_difficulty,
                                             lo), hi)
        session.share_dts.clear()
        asyncio.ensure_future(session.sync_difficulty())

    # ------------------------------------------------------------ serving

    async def make_server(self):
        host = str(self.node.cfg.get("stratum_host", "0.0.0.0"))
        port = int(self.node.cfg.get("stratum_port", 3333))
        self.server = await asyncio.start_server(self._handle_client,
                                                 host, port)
        self.node.log(f"[stratum] listening on {host}:{port}")
        self.ntime_task = asyncio.create_task(self.ntime_refresh_loop())
        return self.server

    def cancel_background_tasks(self):
        """Must be called from the node's event loop thread (shutdown)."""
        task = self.ntime_task
        if task is not None and not task.done():
            task.cancel()
        self.server = None

    async def serve(self):
        server = await self.make_server()
        async with server:
            await server.serve_forever()

    async def _handle_client(self, reader, writer):
        sock = writer.get_extra_info("socket")
        if sock is not None:
            try:
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except OSError:
                pass
        session = Session(self, reader, writer)
        self.sessions.add(session)
        self.node.log(f"[stratum] connect {session.peer} "
                      f"(miners={self.miner_count()})")
        try:
            await session.run()
        finally:
            self.sessions.discard(session)
            self.node.log(
                f"[stratum] disconnect {session.peer} "
                f"({session.disconnect_reason or 'closed'}) "
                f"shares ok={session.shares_ok} bad={session.shares_bad} "
                f"(miners={self.miner_count()})")