"""DeroM CPU test miner - runnable in-process (GUI/exe) or as a CLI.

Speaks the EXACT stratum protocol an ASIC uses, so a successful CPU run
proves the whole share -> block -> payout pipeline.
"""
import json
import socket
import threading
import time

from . import block as blk
from .crypto import (DIFF1_TARGET, decode_nbits, difficulty_to_target,
                     merkle_root_from_branch, sha256d)


class _State:
    def __init__(self):
        self.lock = threading.Lock()
        self.sock_lock = threading.Lock()
        self.job = None
        self.en1 = None
        self.en2_size = 4
        self.difficulty = 0.05
        self.target = difficulty_to_target(self.difficulty)
        self.authorized = False
        self.auth_sent = False
        self.msg_id = 0

    def next_id(self):
        with self.lock:
            self.msg_id += 1
            return self.msg_id


def _handle_line(line, st, log):
    try:
        msg = json.loads(line)
    except ValueError:
        return
    method = msg.get("method")
    params = msg.get("params") or []
    mid = msg.get("id")
    with st.lock:
        if method == "mining.notify" and len(params) >= 9:
            # Spec-correct params: [job_id, prevhash, coinb1, coinb2,
            # merkle_branch, version, nbits, ntime, clean]
            jid, prev_wire, cb1, cb2, branch, vhex, nbhex, nthex = params[:8]
            st.job = {"jid": str(jid), "prev_wire": prev_wire, "cb1": cb1,
                      "cb2": cb2, "branch": list(branch),
                      "version": int(vhex, 16), "nbits": int(nbhex, 16),
                      "ntime": int(nthex, 16)}
        elif method == "mining.set_difficulty":
            st.difficulty = float(params[0])
            st.target = difficulty_to_target(st.difficulty)
    if mid is not None and "result" in msg:
        res, err = msg.get("result"), msg.get("error")
        if err:
            log(f"node rejected our submit: {err}")
        elif isinstance(res, list) and len(res) == 3:   # subscribe reply
            st.en1 = res[1]
            try:
                st.en2_size = int(res[2])
            except (TypeError, ValueError):
                st.en2_size = 4
        elif res is True:
            st.authorized = True


def _reader_loop(sock, st, log):
    buf = b""
    while True:
        try:
            data = sock.recv(8192)
        except OSError as exc:
            log(f"connection error: {exc}")
            return
        if not data:
            return
        buf += data
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            if line.strip():
                _handle_line(line.decode("utf-8", "replace"), st, log)


def run_cpu_miner(user, seconds=30, host="127.0.0.1", port=3333,
                  log=print, verbose=False, stop_event=None):
    """Blocking CPU stratum miner. Wrap in a thread for GUIs.

    Returns {"hashes", "shares", "blocks"}."""
    sock = socket.create_connection((host, port), timeout=10)
    sock.settimeout(None)
    st = _State()

    def send(obj):
        with st.sock_lock:
            sock.sendall((json.dumps(obj) + "\n").encode())

    threading.Thread(target=_reader_loop, args=(sock, st, log),
                     daemon=True).start()

    send({"id": st.next_id(), "method": "mining.subscribe",
          "params": [["mining.notify", "derom-cpu-miner"]]})
    wait_until = time.time() + 8
    while st.en1 is None and time.time() < wait_until:
        if stop_event is not None and stop_event.is_set():
            break
        time.sleep(0.05)
    if st.en1 is None:
        log("no subscribe reply from node - aborting test")
        try:
            sock.close()
        except OSError:
            pass
        return {"hashes": 0, "shares": 0, "blocks": 0}

    send({"id": st.next_id(), "method": "mining.authorize",
          "params": [user, "x"]})
    wait_until = time.time() + 10
    while not st.authorized and time.time() < wait_until:
        if stop_event is not None and stop_event.is_set():
            break
        time.sleep(0.05)

    hashes = shares = blocks = 0
    stat_t = time.time()
    started = stat_t
    last_suggest_t = 0.0
    last_sent_want = 0.0
    deadline = time.time() + seconds

    def maybe_suggest():
        """Keep pool difficulty matched to our measured hashrate: CPU rigs
        cannot reach ASIC-level floors, so ask the pool for a difficulty
        yielding roughly one share per ~10 seconds once speed is known.
        Runs on the hashing hot path so short test windows still trigger."""
        nonlocal last_suggest_t, last_sent_want
        if not st.authorized or st.en1 is None:
            return
        elapsed = time.time() - started
        if hashes < 50000 or elapsed < 1.0 \
                or time.time() - last_suggest_t < 5.0:
            return
        last_suggest_t = time.time()
        rate = hashes / max(elapsed, 1e-9)
        want = max(rate * 10.0 / DIFF1_TARGET, 1e-5)
        # Re-suggest only when BOTH far from the pool's active difficulty
        # AND meaningfully different from our previous ask (pools clamp
        # proposals, and comparing against the clamped value would loop).
        if abs(want - st.difficulty) / max(st.difficulty, 1e-9) > 0.20 \
                and abs(want - last_sent_want) / max(last_sent_want, 1e-9) > 0.20:
            last_sent_want = want
            send({"id": st.next_id(), "method": "mining.suggest_difficulty",
                  "params": [float(f"{want:.6g}")]})

    while time.time() < deadline:
        if stop_event is not None and stop_event.is_set():
            break
        with st.lock:
            job = dict(st.job) if st.job else None
            share_target = st.target
        if job is None or not st.authorized or st.en1 is None:
            time.sleep(0.05)
            continue

        maybe_suggest()

        prev_display = bytes.fromhex(job["prev_wire"])[::-1].hex()
        branch = [bytes.fromhex(h) for h in job["branch"]]
        block_target = decode_nbits(job["nbits"])
        submit_target = max(share_target, block_target)

        for e2i in range(256):
            if time.time() >= deadline:
                break
            en2_hex = f"{e2i:0{st.en2_size * 2}x}"
            cb_raw = blk.assemble_coinbase_raw(job["cb1"], job["cb2"],
                                               st.en1, en2_hex)
            # Stratum-ASIC merkle fold: coinbase stays at index 0 (many
            # firmwares never apply an extranonce2-derived fold index).
            root = merkle_root_from_branch(sha256d(cb_raw), branch, 0)

            nonce = 0
            aborted = False
            applied_diff = st.difficulty
            while nonce <= 0xFFFFFFFF:
                raw = blk.pack_header(job["version"], prev_display,
                                      blk.hash_display(root), job["ntime"],
                                      job["nbits"], nonce & 0xFFFFFFFF)
                digest = sha256d(raw)
                hashes += 1
                powval = int.from_bytes(digest, "little")
                if powval <= submit_target:
                    is_block = powval <= block_target
                    send({"id": st.next_id(), "method": "mining.submit",
                          "params": [user, job["jid"], en2_hex,
                                     f"{job['ntime']:08x}",
                                     f"{nonce & 0xFFFFFFFF:08x}"]})
                    shares += 1
                    if is_block:
                        blocks += 1
                        log(f"*** BLOCK candidate "
                            f"{blk.hash_display(digest)[:20]}.. submitted")
                    elif verbose:
                        log(f"share #{shares} submitted")
                    break                       # fresh extranonce2 slot
                nonce += 1
                if (nonce & 0xFFF) == 0:
                    # Consolidated hot-path tick: keep difficulty matched to
                    # our speed AND absorb pool pushes mid-sweep without
                    # waiting out a full 4-billion-nonce pass.
                    maybe_suggest()
                    if st.difficulty != applied_diff:
                        applied_diff = st.difficulty
                        with st.lock:
                            share_target = st.target
                        submit_target = max(share_target, block_target)
                    if time.time() >= deadline:
                        aborted = True
                        break
            if aborted:
                break

        if verbose and time.time() - stat_t >= 5:
            dt = max(time.time() - stat_t, 0.001)
            stat_t = time.time()
            log(f"{hashes / dt:,.0f} H/s | {shares} shares | {blocks} blocks")

    try:
        sock.close()
    except OSError:
        pass
    log(f"test mining done: {hashes:,} hashes, {shares} shares, "
        f"{blocks} blocks")
    return {"hashes": hashes, "shares": shares, "blocks": blocks}