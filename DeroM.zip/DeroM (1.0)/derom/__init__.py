"""DeroM - a simple ASIC-mineable cryptocurrency."""

__version__ = "0.1.0"
