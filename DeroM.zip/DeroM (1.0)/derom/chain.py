"""DeroM blockchain core: PoW validation, account state, retargeting."""
import json
import os
import threading
import time

from . import block as blk
from . import tx as txlib
from .crypto import POW_LIMIT, decode_nbits, difficulty_to_target, encode_nbits, sha256d


class Chain:
    """Thread-safe blockchain + account-balanced ledger."""

    def __init__(self, cfg: dict, data_dir: str):
        self.cfg = cfg
        self.data_dir = data_dir
        self.blocks_dir = os.path.join(data_dir, "blocks")
        os.makedirs(self.blocks_dir, exist_ok=True)
        self.lock = threading.RLock()
        self.height = -1            # tip height (genesis = 0)
        self.tip_hash = None
        self.tip_ntime = 0
        self.balances = {}          # address -> atoms
        self.nonces = {}            # address -> last spent nonce
        self.target_int = None      # PoW target required at height+1
        self.target_nbits = None
        self.next_target = None     # target after the next block lands
        self.next_nbits = None
        self.ts_hist = []           # [(height, ntime)] window for retargeting
        self._cache = {}

    # ------------------------------------------------------------- persistence

    def _block_path(self, height):
        return os.path.join(self.blocks_dir, f"{height}.json")

    def _state_path(self):
        return os.path.join(self.data_dir, "state.json")

    def get_block(self, ident):
        """Block lookup by height (int/numeric str) or display hash."""
        with self.lock:
            if isinstance(ident, int) or (isinstance(ident, str) and ident.isdigit()):
                path = self._block_path(int(ident))
                if not os.path.exists(path):
                    return None
                with open(path, encoding="utf-8") as fh:
                    return json.load(fh)
            if ident in self._cache:
                return self._cache[ident]
            for h in range(self.height, max(-1, self.height - 500), -1):
                b = self._load_height(h)
                if b and b.get("hash") == ident:
                    return b
            return None

    def _load_height(self, height):
        path = self._block_path(height)
        if not os.path.exists(path):
            return None
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)

    def save_state(self):
        keep = self.cfg["retarget_interval_blocks"] * 3
        payload = {
            "height": self.height,
            "tip_hash": self.tip_hash,
            "balances": self.balances,
            "nonces": self.nonces,
            "ts_hist": self.ts_hist[-keep:],
        }
        tmp = self._state_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh)
        os.replace(tmp, self._state_path())

    def _load_state(self):
        if not os.path.exists(self._state_path()):
            return False
        with open(self._state_path(), encoding="utf-8") as fh:
            s = json.load(fh)
        tip = self._load_height(s["height"]) if s["height"] >= 0 else None
        if tip is None:
            return False
        self.height = s["height"]
        self.tip_hash = s["tip_hash"]
        self.balances = s.get("balances", {})
        self.nonces = s.get("nonces", {})
        self.ts_hist = [tuple(x) for x in s.get("ts_hist", [])]
        self.tip_ntime = tip["header"]["ntime"]
        self.target_int = decode_nbits(tip["header"]["nbits"])
        self.target_nbits = tip["header"]["nbits"]
        self._compute_next_targets()
        return True

    # ------------------------------------------------------------- economics

    def subsidy(self, height):
        halvings = height // self.cfg["halving_interval"]
        return 0 if halvings >= 64 else self.cfg["reward_atoms"] >> halvings

    def _compute_next_targets(self):
        interval = self.cfg["retarget_interval_blocks"]
        height_next = self.height + 1

        # Block 1 always lands at the configured starting difficulty -
        # genesis itself is minted at pow-limit (instant) by design.
        if self.height == 0:
            target = difficulty_to_target(self.cfg["initial_difficulty"])
            self.next_target = target
            self.next_nbits = encode_nbits(target)
            return

        target = self.target_int
        if height_next % interval == 0 and len(self.ts_hist) >= interval:
            actual = max(1, self.ts_hist[-1][1] - self.ts_hist[-interval][1])
            expected = interval * self.cfg["block_time_seconds"]
            max_adj = float(self.cfg.get("max_retarget_adjust", 4.0))
            factor = min(max(expected / actual, 1.0 / max_adj), max_adj)
            target = int(min(max(int(target * factor), 1), POW_LIMIT))
        self.next_target = target
        self.next_nbits = encode_nbits(target)

    def balance_of(self, address):
        return self.balances.get(address, 0)

    def nonce_of(self, address):
        return self.nonces.get(address, 0)

    def account(self, address):
        with self.lock:
            last = self.nonces.get(address, 0)
            return {"address": address, "balance": self.balances.get(address, 0),
                    "nonce": last, "next_nonce": last + 1}

    # ------------------------------------------------------------- genesis

    def create_genesis(self):
        """Mine block 0 synchronously (initial difficulty is tiny on purpose)."""
        cb = txlib.make_coinbase("DEROM_NO_PREMINE_BURN_ADDRESS", 0, 0)
        cbid = txlib.coinbase_txid(cb)
        # Genesis is ALWAYS trivially minable (pow limit) so startup is
        # instant at any network scale - the configured starting difficulty
        # applies from block 1 onward.
        target = POW_LIMIT
        nbits = encode_nbits(target)
        merkle_display = blk.hash_display(cbid)
        prev_zeros = "00" * 32
        base_time = int(time.time())
        found = None
        for attempt in range(64):          # widen search over ntime too
            gtime = base_time + attempt
            for i in range(1 << 21):
                nonce = (i + attempt * 7919) & 0xFFFFFFFF
                raw = blk.pack_header(blk.BLOCK_VERSION, prev_zeros,
                                      merkle_display, gtime, nbits, nonce)
                digest = sha256d(raw)
                if int.from_bytes(digest, "little") <= target:
                    found = (digest, gtime, nonce)
                    break
            if found:
                break
        digest, gtime, gnonce = found
        bdict = {
            "hash": blk.hash_display(digest),
            "height": 0,
            "header": {"version": blk.BLOCK_VERSION, "prev": prev_zeros,
                       "merkle": merkle_display, "ntime": gtime,
                       "nbits": nbits, "nonce": gnonce},
            "txs": [cb],
        }
        self._adopt_genesis(bdict)
        return bdict

    def _adopt_genesis(self, bdict):
        with self.lock:
            self.height = 0
            self.tip_hash = bdict["hash"]
            self.tip_ntime = bdict["header"]["ntime"]
            self.target_int = decode_nbits(bdict["header"]["nbits"])
            self.target_nbits = bdict["header"]["nbits"]
            self.ts_hist = [(0, self.tip_ntime)]
            self._compute_next_targets()
            with open(self._block_path(0), "w", encoding="utf-8") as fh:
                json.dump(bdict, fh)
            self.save_state()

    @classmethod
    def load_or_create(cls, cfg, data_dir):
        chain = cls(cfg, data_dir)
        if not chain._load_state():
            chain.create_genesis()
        return chain

    # ------------------------------------------------------------- validation

    def _simulate_spends(self, spends):
        """Sequentially validate spends against a snapshot of current
        state. The dict copies happen under the same RLock writers use so
        the snapshot can never observe a half-applied mutation."""
        with self.lock:
            bal = dict(self.balances)
            non = dict(self.nonces)
        fees = 0
        for t in spends:
            err = txlib.verify_spend(t, lambda a: bal.get(a, 0), lambda a: non.get(a, 0))
            if err:
                return 0, f"tx {txlib.txid(t)[:16]}..: {err}"
            bal[t["from"]] -= t["amount"] + t["fee"]
            bal[t["to"]] = bal.get(t["to"], 0) + t["amount"]
            non[t["from"]] = t["nonce"]
            fees += t["fee"]
        return fees, ""

    def validate_block(self, b):
        """Full consensus check of a candidate block. Returns "" if valid."""
        from .crypto import address_is_valid
        hdr, txs = b.get("header"), b.get("txs")
        if not isinstance(hdr, dict) or not isinstance(txs, list) or not txs:
            return "malformed block"
        if b.get("height") != self.height + 1:
            return f"bad height {b.get('height')} (expected {self.height + 1})"
        if hdr.get("prev") != self.tip_hash:
            return "prev_hash does not extend current tip"
        if hdr.get("nbits") != self.next_nbits:
            return "nbits mismatch (stale job or wrong difficulty)"
        try:
            raw = blk.pack_header(hdr["version"], hdr["prev"], hdr["merkle"],
                                  hdr["ntime"], hdr["nbits"], hdr["nonce"])
        except Exception:
            return "bad header fields"
        digest = sha256d(raw)
        if int.from_bytes(digest, "little") > decode_nbits(hdr["nbits"]):
            return "PoW does not meet target"
        if blk.hash_display(digest) != b.get("hash"):
            return (f"block hash mismatch stored={str(b.get('hash'))[:20]}.. "
                    f"recomputed={blk.hash_display(digest)[:20]}.. "
                    f"hdr={raw.hex()}")
        now = int(time.time())
        if not now - 3600 <= hdr["ntime"] <= now + 7200:
            return "ntime outside acceptable window"
        if hdr["ntime"] < self.tip_ntime:
            return "ntime older than parent block"
        try:
            en2_bytes = bytes.fromhex(txs[0].get("en2") or "")
        except ValueError:
            return "coinbase en2 field is not hex"
        en2_int = int.from_bytes(en2_bytes, "big") if en2_bytes else 0
        root = blk.coinbase_merkle_root(txlib.tx_digest(txs[0]),
                                        [txlib.tx_digest(t) for t in txs[1:]],
                                        en2_int)
        if blk.hash_display(root) != hdr["merkle"]:
            return "merkle root mismatch"
        if txs[0].get("type") != txlib.COINBASE:
            return "first transaction must be the coinbase"
        if any(t.get("type") == txlib.COINBASE for t in txs[1:]):
            return "multiple coinbase transactions"
        if not address_is_valid(txs[0].get("to", "")):
            return "coinbase payout address invalid"
        spends = []
        for t in txs[1:]:
            if t.get("type") != txlib.SPEND:
                return f"unknown tx type {t.get('type')!r}"
            spends.append(t)
        fees, err = self._simulate_spends(spends)
        if err:
            return err
        expected = self.subsidy(b["height"]) + fees
        if txs[0].get("amount") != expected:
            return f"coinbase amount {txs[0].get('amount')} != expected {expected}"
        return ""

    def add_block(self, b):
        """Validate + apply + persist. Returns (accepted, message)."""
        with self.lock:
            err = self.validate_block(b)
            if err:
                return False, err
            cb = b["txs"][0]
            if cb["amount"]:
                self.balances[cb["to"]] = self.balances.get(cb["to"], 0) + cb["amount"]
            for t in b["txs"][1:]:
                self.balances[t["from"]] -= t["amount"] + t["fee"]
                self.balances[t["to"]] = self.balances.get(t["to"], 0) + t["amount"]
                self.nonces[t["from"]] = t["nonce"]
            self.height = b["height"]
            self.tip_hash = b["hash"]
            self.tip_ntime = b["header"]["ntime"]
            self.target_int = decode_nbits(b["header"]["nbits"])
            self.target_nbits = b["header"]["nbits"]
            self.ts_hist.append((self.height, self.tip_ntime))
            self.ts_hist = self.ts_hist[-self.cfg["retarget_interval_blocks"] * 3:]
            self._compute_next_targets()
            with open(self._block_path(self.height), "w", encoding="utf-8") as fh:
                json.dump(b, fh)
            self.save_state()
            self._cache[b["hash"]] = b
            while len(self._cache) > 100:
                self._cache.pop(next(iter(self._cache)))
        return True, "accepted"

    def info(self):
        from .crypto import target_to_difficulty
        with self.lock:
            return {
                "chain": "derom",
                "height": self.height,
                "tip": self.tip_hash,
                "difficulty": round(target_to_difficulty(self.next_target), 8),
                "nbits": f"{self.next_nbits:08x}",
                "next_reward_atoms": self.subsidy(self.height + 1),
                "addresses_tracked": len(self.balances),
            }

    def richlist(self, limit=25):
        """Top accounts by balance, descending."""
        with self.lock:
            items = sorted(self.balances.items(), key=lambda kv: kv[1], reverse=True)
            return {
                "total_supply": sum(self.balances.values()) / txlib.ATOMS_PER_DEROM,
                "accounts": len(self.balances),
                "top": [
                    {"address": addr,
                     "balance": atoms / txlib.ATOMS_PER_DEROM}
                    for addr, atoms in items[:max(1, min(int(limit), 500))]
                ],
            }

    def quote_block(self, candidate_spends):
        """Snapshot everything needed to build a candidate at height+1."""
        fees, err = self._simulate_spends(candidate_spends)
        if err:
            return None, err
        with self.lock:
            return {
                "height": self.height + 1,
                "prev": self.tip_hash,
                "nbits": self.next_nbits,
                "target": self.next_target,
                "spends": list(candidate_spends),
                "fees": fees,
            }, ""
