"""P2P node synchronization for DeroM.

Allows multiple nodes to sync and share the blockchain.
"""
import json
import socket
import threading
import time
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import logging


class P2PNode:
    """P2P network node for block/transaction synchronization."""
    
    PROTOCOL_VERSION = 1
    MESSAGE_TYPES = {
        "handshake": 0x00,
        "get_blocks": 0x01,
        "send_blocks": 0x02,
        "get_mempool": 0x03,
        "send_mempool": 0x04,
        "new_block": 0x05,
        "new_transaction": 0x06,
        "ping": 0x07,
        "pong": 0x08,
    }
    
    def __init__(self, node_id: str, listen_host: str = "0.0.0.0", 
                 listen_port: int = 3334, initial_peers: List[str] = None):
        self.node_id = node_id
        self.listen_host = listen_host
        self.listen_port = listen_port
        
        # Network state
        self.peers: Dict[str, 'PeerConnection'] = {}  # peer_id -> PeerConnection
        self.initial_peers = initial_peers or []
        
        # Sync state
        self.best_height = 0
        self.synced = False
        self.pending_blocks: Dict[int, Dict] = {}  # height -> block_data
        self.pending_txs: Dict[str, Dict] = {}  # tx_id -> tx_data
        
        # Callbacks
        self.on_block_received = None
        self.on_tx_received = None
        self.on_peer_connected = None
        self.on_peer_disconnected = None
        
        self.logger = logging.getLogger(f"p2p_{node_id}")
        
        # Server state
        self.running = False
        self.server_thread = None
        self.sync_thread = None
    
    def start(self):
        """Start the P2P node."""
        self.running = True
        self.server_thread = threading.Thread(target=self._run_server, daemon=True)
        self.server_thread.start()
        
        self.sync_thread = threading.Thread(target=self._run_sync, daemon=True)
        self.sync_thread.start()
        
        self.logger.info(f"P2P Node {self.node_id} started on {self.listen_host}:{self.listen_port}")
    
    def stop(self):
        """Stop the P2P node."""
        self.running = False
        
        # Disconnect all peers
        for peer in list(self.peers.values()):
            peer.disconnect()
        
        self.logger.info(f"P2P Node {self.node_id} stopped")
    
    def add_peer(self, peer_host: str, peer_port: int, peer_id: str = None) -> bool:
        """Connect to a peer node.
        
        Args:
            peer_host: Peer IP/hostname
            peer_port: Peer port
            peer_id: Peer node ID (auto-generated if None)
            
        Returns:
            True if connection successful
        """
        if not peer_id:
            peer_id = f"{peer_host}:{peer_port}"
        
        if peer_id in self.peers:
            return True
        
        try:
            conn = PeerConnection(peer_id, peer_host, peer_port, self)
            if conn.connect():
                self.peers[peer_id] = conn
                self.logger.info(f"Connected to peer {peer_id}")
                return True
        except Exception as e:
            self.logger.error(f"Failed to connect to {peer_id}: {e}")
        
        return False
    
    def broadcast_block(self, block_data: Dict[str, Any]):
        """Broadcast a new block to all peers.
        
        Args:
            block_data: Block data to broadcast
        """
        message = {
            "type": self.MESSAGE_TYPES["new_block"],
            "data": block_data,
        }
        
        for peer in self.peers.values():
            if peer.is_connected():
                peer.send_message(message)
    
    def broadcast_transaction(self, tx_data: Dict[str, Any]):
        """Broadcast a new transaction to all peers.
        
        Args:
            tx_data: Transaction data to broadcast
        """
        message = {
            "type": self.MESSAGE_TYPES["new_transaction"],
            "data": tx_data,
        }
        
        for peer in self.peers.values():
            if peer.is_connected():
                peer.send_message(message)
    
    def request_blocks(self, from_height: int, to_height: int) -> Optional[List[Dict]]:
        """Request blocks from peers.
        
        Args:
            from_height: Starting block height
            to_height: Ending block height
            
        Returns:
            List of blocks, or None if request failed
        """
        if not self.peers:
            return None
        
        # Ask the first connected peer
        for peer in self.peers.values():
            if peer.is_connected():
                message = {
                    "type": self.MESSAGE_TYPES["get_blocks"],
                    "from_height": from_height,
                    "to_height": to_height,
                }
                return peer.send_request(message)
        
        return None
    
    def request_mempool(self) -> Optional[List[Dict]]:
        """Request pending transactions from peers.
        
        Returns:
            List of transactions in mempool
        """
        if not self.peers:
            return None
        
        for peer in self.peers.values():
            if peer.is_connected():
                message = {"type": self.MESSAGE_TYPES["get_mempool"]}
                return peer.send_request(message)
        
        return None
    
    def _run_server(self):
        """Run the P2P server to accept incoming connections."""
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            server.bind((self.listen_host, self.listen_port))
            server.listen(5)
            self.logger.info(f"P2P server listening on {self.listen_host}:{self.listen_port}")
            
            while self.running:
                server.settimeout(1.0)
                try:
                    client_sock, addr = server.accept()
                    self.logger.info(f"Incoming connection from {addr}")
                    
                    # Create peer connection for incoming
                    peer_id = f"{addr[0]}:{addr[1]}"
                    peer = PeerConnection(peer_id, addr[0], addr[1], self, 
                                         existing_socket=client_sock)
                    self.peers[peer_id] = peer
                    
                except socket.timeout:
                    continue
                except Exception as e:
                    self.logger.error(f"Server error: {e}")
        finally:
            server.close()
    
    def _run_sync(self):
        """Run the synchronization loop."""
        while self.running:
            try:
                # Connect to initial peers if needed
                if not self.peers and self.initial_peers:
                    for peer_addr in self.initial_peers:
                        parts = peer_addr.split(":")
                        if len(parts) == 2:
                            self.add_peer(parts[0], int(parts[1]))
                
                # Send ping to all peers
                self.ping_peers()
                
                # Sync blocks if needed
                if self.pending_blocks:
                    self.process_pending_blocks()
                
                time.sleep(5)
            except Exception as e:
                self.logger.error(f"Sync error: {e}")
    
    def ping_peers(self):
        """Send ping to all connected peers."""
        message = {
            "type": self.MESSAGE_TYPES["ping"],
            "timestamp": int(time.time()),
        }
        
        disconnected = []
        for peer_id, peer in self.peers.items():
            if peer.is_connected():
                peer.send_message(message)
            else:
                disconnected.append(peer_id)
        
        # Remove disconnected peers
        for peer_id in disconnected:
            del self.peers[peer_id]
            if self.on_peer_disconnected:
                self.on_peer_disconnected(peer_id)
    
    def process_pending_blocks(self):
        """Process any blocks waiting to be verified."""
        # This would integrate with the chain validation
        # For now, just log
        self.logger.debug(f"Processing {len(self.pending_blocks)} pending blocks")
    
    def get_peer_info(self) -> List[Dict[str, Any]]:
        """Get information about connected peers."""
        peers = []
        for peer_id, peer in self.peers.items():
            peers.append({
                "id": peer_id,
                "connected": peer.is_connected(),
                "height": peer.height,
                "last_seen": peer.last_seen,
            })
        return peers
    
    def get_sync_status(self) -> Dict[str, Any]:
        """Get node synchronization status."""
        return {
            "node_id": self.node_id,
            "best_height": self.best_height,
            "synced": self.synced,
            "peer_count": len([p for p in self.peers.values() if p.is_connected()]),
            "pending_blocks": len(self.pending_blocks),
            "pending_txs": len(self.pending_txs),
        }


class PeerConnection:
    """Connection to a single peer node."""
    
    def __init__(self, peer_id: str, host: str, port: int, parent_node: P2PNode,
                 existing_socket: socket.socket = None):
        self.peer_id = peer_id
        self.host = host
        self.port = port
        self.parent = parent_node
        self.socket = existing_socket
        self.connected = existing_socket is not None
        
        self.height = 0
        self.version = 0
        self.last_seen = time.time()
        self.last_ping = 0
        
        self.logger = logging.getLogger(f"peer_{peer_id}")
    
    def connect(self) -> bool:
        """Establish connection to peer."""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(10)
            self.socket.connect((self.host, self.port))
            self.connected = True
            self.last_seen = time.time()
            
            # Send handshake
            self.send_handshake()
            
            # Start receive thread
            threading.Thread(target=self._receive_loop, daemon=True).start()
            
            return True
        except Exception as e:
            self.logger.error(f"Connection failed: {e}")
            self.connected = False
            return False
    
    def disconnect(self):
        """Disconnect from peer."""
        self.connected = False
        if self.socket:
            try:
                self.socket.close()
            except Exception:
                pass
    
    def is_connected(self) -> bool:
        """Check if connection is active."""
        return self.connected
    
    def send_handshake(self):
        """Send protocol handshake."""
        handshake = {
            "type": P2PNode.MESSAGE_TYPES["handshake"],
            "version": P2PNode.PROTOCOL_VERSION,
            "node_id": self.parent.node_id,
            "height": self.parent.best_height,
            "timestamp": int(time.time()),
        }
        self.send_message(handshake)
    
    def send_message(self, message: Dict[str, Any]):
        """Send a message to the peer."""
        try:
            data = json.dumps(message).encode('utf-8')
            length = len(data).to_bytes(4, 'big')
            self.socket.sendall(length + data)
        except Exception as e:
            self.logger.error(f"Send error: {e}")
            self.disconnect()
    
    def send_request(self, message: Dict[str, Any], timeout: int = 10) -> Optional[Any]:
        """Send a request and wait for response."""
        self.send_message(message)
        # TODO: Implement request/response with timeout
        return None
    
    def _receive_loop(self):
        """Receive messages from peer."""
        while self.connected:
            try:
                # Read message length
                length_data = self.socket.recv(4)
                if not length_data:
                    self.disconnect()
                    break
                
                msg_len = int.from_bytes(length_data, 'big')
                
                # Read message data
                msg_data = b''
                while len(msg_data) < msg_len:
                    chunk = self.socket.recv(min(4096, msg_len - len(msg_data)))
                    if not chunk:
                        self.disconnect()
                        break
                    msg_data += chunk
                
                if len(msg_data) == msg_len:
                    message = json.loads(msg_data.decode('utf-8'))
                    self._handle_message(message)
                
                self.last_seen = time.time()
            except socket.timeout:
                continue
            except Exception as e:
                self.logger.debug(f"Receive error: {e}")
                self.disconnect()
    
    def _handle_message(self, message: Dict[str, Any]):
        """Handle incoming message from peer."""
        msg_type = message.get("type")
        
        if msg_type == P2PNode.MESSAGE_TYPES["handshake"]:
            self.version = message.get("version", 0)
            self.height = message.get("height", 0)
        
        elif msg_type == P2PNode.MESSAGE_TYPES["new_block"]:
            if self.parent.on_block_received:
                self.parent.on_block_received(message.get("data"))
        
        elif msg_type == P2PNode.MESSAGE_TYPES["new_transaction"]:
            if self.parent.on_tx_received:
                self.parent.on_tx_received(message.get("data"))
        
        elif msg_type == P2PNode.MESSAGE_TYPES["pong"]:
            self.last_ping = time.time()
