/* Rich List page */
"use strict";

async function loadRich() {
  const info = await refreshStatus();
  const body = document.getElementById("rich-body");
  const meta = document.getElementById("rich-meta");
  if (!info) { document.getElementById("rich-wrap").style.display = "none"; return; }
  document.getElementById("rich-wrap").style.display = "";
  try {
    const rl = await rpc("richlist", [25]);
    const supply = rl.total_supply > 0 ? rl.total_supply : 1;
    meta.textContent = rl.accounts + " addresses tracked · " +
      fmt(supply) + " DEROM in circulation of 81,000,000 max";
    body.innerHTML = rl.top.map((a, i) => {
      const pct = (100 * a.balance / supply).toFixed(2);
      const medal = ["🥇", "🥈", "🥉"][i] || "";
      return "<tr><td class=\"rank\">" + (medal || "#" + (i + 1)) + "</td>" +
        '<td class="mono" title="' + esc(a.address) + '">' + esc(a.address) + "</td>" +
        '<td class="num"><b>' + fmt(a.balance) + "</b> DEROM</td>" +
        '<td class="num">' + pct + "%</td></tr>";
    }).join("") || '<tr><td colspan="4">ledger is empty — mine block #1!</td></tr>';
  } catch (e) {
    body.innerHTML = '<tr><td colspan="4">error loading rich list: ' + esc(e.message) + "</td></tr>";
  }
}

wireRpcInput();
document.addEventListener("node-changed", loadRich);
loadRich();
