/* Block Explorer page */
"use strict";

let tipHeight = -1;

async function loadStats() {
  const info = await refreshStatus();
  if (!info) { showOffline(); return null; }
  document.getElementById("x-height").textContent = fmt(info.height);
  document.getElementById("x-diff").textContent = fmt(info.difficulty);
  document.getElementById("x-miners").textContent = fmt(info.miners_connected);
  document.getElementById("x-mempool").textContent = fmt(info.mempool_size);
  tipHeight = info.height;
  return info;
}

function showOffline() {
  ["recent-wrap", "detail-card", "account-card"].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.style.display = "none";
  });
}

async function loadRecent() {
  if (tipHeight < 0) return;
  const from = Math.max(0, tipHeight - 11);
  const rows = [];
  for (let h = tipHeight; h >= from; h--) {
    try {
      const b = await rpc("getblock", [h]);
      if (!b) continue;
      const cb = b.txs && b.txs[0] ? b.txs[0] : {};
      rows.push(
        '<tr class="clickable" onclick="openBlock(' + b.height + ')">' +
        "<td><b>" + b.height + "</b></td>" +
        '<td class="mono" title="' + esc(b.hash) + '">' + esc(short(b.hash, 14, 8)) + "</td>" +
        "<td>" + timeAgo(b.header && b.header.ntime) + "</td>" +
        '<td class="num">' + ((b.txs || []).length) + "</td>" +
        '<td class="mono" title="' + esc(cb.to || "") + '">' + esc(short(cb.to || "—", 10, 6)) + "</td>" +
        '<td class="num">' + fmt(toDerom(cb.amount || 0)) + "</td></tr>");
    } catch (e) { break; }
  }
  document.getElementById("recent-body").innerHTML =
    rows.join("") || '<tr><td colspan="6">no blocks yet</td></tr>';
}

async function openBlock(ident) {
  let b;
  try { b = await rpc("getblock", [ident]); } catch (e) { return; }
  if (!b) return;
  const h = b.header || {};
  const rows = [
    ["Height", b.height], ["Hash", b.hash], ["Prev", h.prev],
    ["Merkle root", h.merkle], ["Time", h.ntime ? new Date(h.ntime * 1000).toLocaleString() : "—"],
    ["nBits", h.nbits != null ? "0x" + Number(h.nbits).toString(16).padStart(8, "0") : "—"],
    ["Nonce", h.nonce], ["Version", h.version != null ? "0x" + (h.version >>> 0).toString(16) : "—"],
  ];
  document.getElementById("detail-title").innerHTML = "Block <span class='grad' style='font-size:inherit'>" + b.height + "</span>";
  document.getElementById("detail-fields").innerHTML = rows.map((r) =>
    '<div class="stat"><div class="k">' + r[0] + '</div><div class="v mono" style="font-size:.95rem">' +
    esc(r[1]) + "</div></div>").join("");
  const txrows = (b.txs || []).map((t, i) => {
    const cb = i === 0;
    return "<tr><td>" + (cb ? "🪙 coinbase" : "💸 spend") + "</td>" +
      '<td class="mono" title="' + esc(t.from || "") + '">' + esc(t.from ? short(t.from, 10, 6) : "(new coins)") + "</td>" +
      '<td class="mono" title="' + esc(t.to || "") + '">' + esc(short(t.to || "", 10, 6)) + "</td>" +
      '<td class="num">' + fmt(toDerom(t.amount || 0)) + "</td>" +
      '<td class="num">' + (t.fee ? fmt(toDerom(t.fee)) : "—") + "</td></tr>";
  }).join("");
  document.getElementById("tx-body").innerHTML = txrows || '<tr><td colspan="5">no transactions</td></tr>';
  document.getElementById("detail-card").style.display = "";
  document.getElementById("detail-card").scrollIntoView({ behavior: "smooth", block: "nearest" });
}

async function lookup() {
  const q = document.getElementById("q").value.trim();
  const out = document.getElementById("lookup-out");
  if (!q) return;
  if (/^D/.test(q)) {
    try {
      const acct = await rpc("getaccount", [q]);
      out.className = "banner on";
      out.innerHTML = '<span class="dot on"></span><b class="mono">' + esc(q) + "</b> — balance <b>" +
        fmt(toDerom(acct.balance)) + " DEROM</b>, nonce " + esc(acct.nonce ?? 0);
    } catch (e) {
      out.className = "banner off";
      out.innerHTML = '<span class="dot off"></span>Account not found or invalid address.';
    }
  } else {
    openBlock(isNaN(Number(q)) ? q : Number(q));
    out.className = "banner on";
    out.innerHTML = '<span class="dot on"></span>Showing block ' + esc(q);
  }
}

wireRpcInput(); wireCopyButtons();
document.addEventListener("node-changed", async () => { await loadStats(); loadRecent(); });
(async () => { await loadStats(); loadRecent(); setInterval(loadRecent, 20000); })();
