/* DeroM website — shared RPC client + helpers */
"use strict";

const ATOMS = 1e8; // atoms per DEROM (matches derom/tx.py)
const DEFAULT_RPC = "http://127.0.0.1:8570";

function getRpcUrl() {
  return localStorage.getItem("derom_rpc") || DEFAULT_RPC;
}
function setRpcUrl(url) {
  url = (url || "").trim().replace(/\/+$/, "");
  localStorage.setItem("derom_rpc", url || DEFAULT_RPC);
}

/* JSON-RPC call to a DeroM node. Rejects with a readable message. */
async function rpc(method, params = []) {
  let res;
  try {
    res = await fetch(getRpcUrl(), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
    });
  } catch (e) {
    throw new Error("node unreachable at " + getRpcUrl());
  }
  const body = await res.json();
  if (body.error) throw new Error(String(body.error));
  return body.result;
}

/* ---------- formatting helpers ---------- */
const fmt = (n) => Number(n).toLocaleString("en-US", { maximumFractionDigits: 8 });
const toDerom = (atoms) => Number(atoms) / ATOMS;
function short(s, head = 10, tail = 6) {
  s = String(s || "");
  return s.length <= head + tail + 1 ? s : s.slice(0, head) + "…" + s.slice(-tail);
}
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function timeAgo(unix) {
  if (!unix) return "—";
  const d = Math.max(0, Date.now() / 1000 - unix);
  if (d < 60) return Math.floor(d) + "s ago";
  if (d < 3600) return Math.floor(d / 60) + "m ago";
  if (d < 86400) return Math.floor(d / 3600) + "h ago";
  return new Date(unix * 1000).toLocaleDateString();
}

/* ---------- node status banner ----------
   Any element with data-node-banner becomes an online/offline strip. */
async function refreshStatus() {
  const el = document.querySelector("[data-node-banner]");
  if (!el) return true;
  try {
    const info = await rpc("getinfo");
    el.className = "banner on";
    el.innerHTML = '<span class="dot on"></span>Connected to node <b class="mono"></b>' +
      " — height " + esc(fmt(info.height));
    el.querySelector("b").textContent = getRpcUrl();
    return info;
  } catch (e) {
    el.className = "banner off";
    el.innerHTML = '<span class="dot off"></span>' +
      "Live chain data appears when a DeroM node is reachable. " +
      '<a href="connect.html">Start your own node</a> (it also serves as your ' +
      "pool), or enter a running node's address below.";
    return null;
  }
}

/* ---------- RPC URL widget (input + save button) ---------- */
function wireRpcInput() {
  const input = document.querySelector("[data-rpc-input]");
  const btn = document.querySelector("[data-rpc-save]");
  if (!input || !btn) return;
  input.value = getRpcUrl();
  btn.addEventListener("click", async () => {
    setRpcUrl(input.value);
    await refreshStatus();
    document.dispatchEvent(new CustomEvent("node-changed"));
  });
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") btn.click(); });
}

/* ---------- copy-to-clipboard for .code blocks ---------- */
function wireCopyButtons() {
  document.querySelectorAll(".code").forEach((block) => {
    const btn = block.querySelector(".copy");
    if (!btn) return;
    btn.addEventListener("click", () => {
      navigator.clipboard.writeText(block.textContent.replace(/^copy$/, "").trim());
      const old = btn.textContent;
      btn.textContent = "copied!";
      setTimeout(() => (btn.textContent = old), 1200);
    });
  });
}
