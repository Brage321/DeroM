@echo off
REM ============================================
REM  DeroM - Deploy website to derom.surge.sh
REM  Double-click this file to publish updates
REM ============================================
echo.
echo   Deploying DeroM website to derom.surge.sh ...
echo.
surge --project "C:\Users\Brage\OneDrive\Dokumenter\DeroM (1.0)\website" --domain derom.surge.sh
echo.
pause
