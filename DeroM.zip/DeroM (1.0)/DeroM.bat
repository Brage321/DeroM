@echo off
title DeroM Control Panel
cd /d "%~dp0"
py -B -m derom.gui
