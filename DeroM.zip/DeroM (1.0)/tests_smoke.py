"""Quick sanity checks for DeroM primitives. Run: py tests_smoke.py"""
import time

from derom import block as blk
from derom import tx as txlib
from derom.crypto import (DIFF1_TARGET, address_is_valid, b58check_decode,
                          decode_nbits, difficulty_to_target,
                          encode_nbits, generate_privkey,
                          merkle_branch, merkle_root, merkle_root_from_branch,
                          privkey_to_address, privkey_to_pubkey,
                          sha256d, sign_payload, verify_payload)

fails = []


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond:
        fails.append(name)


# --- addresses start with 'D' and roundtrip
priv = generate_privkey()
addr = privkey_to_address(priv)
check("address starts with D", addr.startswith("D"))
check("address checksum valid", address_is_valid(addr))
check("b58 roundtrip", b58check_decode(addr)[0] == 0x1F)

# --- nBits roundtrip on difficulty-1 target
nb = encode_nbits(DIFF1_TARGET)
check("diff1 encodes to 0x1d00ffff", nb == 0x1D00FFFF)
check("nbits decode(encode(t)) ~ t",
      abs(decode_nbits(nb) - DIFF1_TARGET) / DIFF1_TARGET < 0.01)

# --- difficulty/target conversion sane
t = difficulty_to_target(0.001)
check("difficulty->target positive & within pow limit", 0 < t <= 0x7FFFFF << 232)

# --- signatures
pub = privkey_to_pubkey(priv)
sig = sign_payload(priv, b"hello derom")
check("signature verifies", verify_payload(pub, b"hello derom", sig))
check("tampered payload rejected", not verify_payload(pub, b"hello derom!", sig))

# --- tx build/verify flow
a2 = privkey_to_address(generate_privkey())
tx = txlib.make_spend(priv, a2, 5_0000_0000, 10_0000, 1)


def bal(_): return 100 * txlib.ATOMS_PER_DEROM


def non(_): return 0


check("valid spend accepted", txlib.verify_spend(tx, bal, non) == "")
bad = dict(tx, amount=999 * txlib.ATOMS_PER_DEROM)
check("overspend rejected", txlib.verify_spend(bad, lambda a: 1, non) != "")

# --- merkle consistency incl. stratum fold with extranonce2 index
ids = [sha256d(bytes([i])) for i in range(5)]
root_full = merkle_root(ids)
branch0 = merkle_branch(ids, 0)
check("branch length correct", len(branch0) == 3)
check("fold at index 0 matches root",
      merkle_root_from_branch(ids[0], branch0, 0) == root_full)

# coinbase-style root must equal full-tree root regardless of en2 value
# (stratum ASIC firmware never applies an extranonce2 fold index)
cb = ids[0]
extras = ids[1:]
r_en2_0 = blk.coinbase_merkle_root(cb, extras, 0)
r_en2_7 = blk.coinbase_merkle_root(cb, extras, 7)
check("coinbase fold en2=0 equals full root", r_en2_0 == root_full)
check("coinbase fold en2=7 equals full root", r_en2_7 == root_full)

# --- header pack/unpack roundtrip
h = {"version": 1, "prev": "ab" * 32, "merkle": "cd" * 32,
     "ntime": 1700000000, "nbits": 0x207FFFFF, "nonce": 123456}
raw = blk.pack_header(h["version"], h["prev"], h["merkle"], h["ntime"],
                      h["nbits"], h["nonce"])
check("header is 80 bytes", len(raw) == 80)
back = blk.unpack_header(raw)
check("header roundtrip", all(back[k] == h[k] for k in h))

print()
if fails:
    raise SystemExit(f"{len(fails)} smoke checks FAILED")
print(f"ALL SMOKE CHECKS PASSED ({time.strftime('%H:%M:%S')})")
