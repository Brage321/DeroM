#!/usr/bin/env python3
"""Test all DeroM modules for functionality."""

import sys
import json
import os

print("=" * 60)
print("DeroM Module Tests")
print("=" * 60)

# Test 1: Encryption
print("\n[1/5] Testing encryption module...")
try:
    from derom.encryption import EncryptedWallet
    
    wallet_data = {'private_key': 'test123', 'address': 'DeromTestAddr123'}
    password = 'super_secure_password'
    
    # Encrypt
    encrypted = EncryptedWallet.encrypt_wallet(wallet_data, password)
    print("  ✓ Encrypted wallet")
    
    # Decrypt
    decrypted = EncryptedWallet.decrypt_wallet(encrypted, password)
    print("  ✓ Decrypted wallet")
    
    # Verify
    if decrypted == wallet_data:
        print("  ✓ Encryption/decryption cycle verified")
    else:
        print("  ✗ Mismatch after decryption!")
        sys.exit(1)
    
    # Test wrong password
    try:
        EncryptedWallet.decrypt_wallet(encrypted, 'wrong_password')
        print("  ✗ Should have failed with wrong password!")
        sys.exit(1)
    except Exception:
        print("  ✓ Correctly rejected wrong password")
    
    print("✅ Encryption tests passed!")
except Exception as e:
    print(f"❌ Encryption test failed: {e}")
    sys.exit(1)

# Test 2: Multi-Wallet
print("\n[2/5] Testing multi_wallet module...")
try:
    from derom.multi_wallet import MultiAddressWallet
    import tempfile
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        wallet_path = f.name
    
    try:
        # Create wallet
        mw = MultiAddressWallet(wallet_path)
        print("  ✓ Created MultiAddressWallet")
        
        # Add address
        addr1 = mw.add_address("Main Address")
        print(f"  ✓ Added address: {addr1[:16]}...")
        
        # Add another
        addr2 = mw.add_address("Secondary Address")
        print(f"  ✓ Added another address: {addr2[:16]}...")
        
        # List addresses
        addrs = mw.list_addresses()
        if len(addrs) == 2:
            print(f"  ✓ Listed {len(addrs)} addresses")
        else:
            print(f"  ✗ Expected 2 addresses, got {len(addrs)}")
            sys.exit(1)
        
        # Save and load
        mw.save()
        print(f"  ✓ Saved wallet to disk")
        
        # Load wallet in new instance
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            wallet_path2 = f.name
        
        # Copy the saved file to test reload
        import shutil
        shutil.copy(wallet_path, wallet_path2)
        
        mw2 = MultiAddressWallet(wallet_path2)
        mw2.load()
        print(f"  ✓ Loaded wallet from disk")
        
        addrs2 = mw2.list_addresses()
        if len(addrs2) == 2:
            print(f"  ✓ Verified {len(addrs2)} addresses after reload")
        else:
            print(f"  ✗ Address count mismatch after reload!")
            sys.exit(1)
        
        print("✅ Multi-Wallet tests passed!")
    finally:
        if os.path.exists(wallet_path):
            os.remove(wallet_path)
        try:
            if os.path.exists(wallet_path2):
                os.remove(wallet_path2)
        except NameError:
            pass
except Exception as e:
    print(f"❌ Multi-Wallet test failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 3: Pool
print("\n[3/5] Testing pool module...")
try:
    from derom.pool import PPLNSPool, PoolAccount
    import tempfile
    
    # Create a temporary pool config
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        config_path = f.name
        json.dump({
            "pool_name": "Test Pool",
            "window_size": 10,
            "block_reward": 50 * 10**8,
            "pool_fee": 0.01,
            "min_payout": 0.1 * 10**8,
        }, f)
    
    try:
        # Create pool
        pool = PPLNSPool(config_path)
        print("  ✓ Created PPLNS pool")

        # Register miners
        pool.register_miner("addr1", "miner1")
        pool.register_miner("addr2", "miner2")
        print("  ✓ Registered 2 miners")

        # Submit shares
        pool.submit_share("addr1", difficulty=1.0)
        pool.submit_share("addr2", difficulty=2.0)
        pool.submit_share("addr1", difficulty=1.5)
        print("  ✓ Submitted 3 shares")

        # Get pool stats
        stats = pool.get_pool_stats()
        if stats and "total_miners" in stats:
            print(f"  ✓ Pool stats: {stats['total_miners']} miners")
        else:
            print("  ✗ Pool stats missing!")
            sys.exit(1)

        # Simulate block found
        block_info = pool.on_block_found("addr1")
        if block_info and "payouts" in block_info:
            print(f"  ✓ Block found, generated {len(block_info['payouts'])} payouts")
        else:
            print("  ✗ No payouts generated!")
            sys.exit(1)

        print("✅ Pool tests passed!")
    finally:
        if os.path.exists(config_path):
            os.remove(config_path)
        accounts_file = config_path.replace(".json", "_accounts.json")
        if os.path.exists(accounts_file):
            os.remove(accounts_file)
except Exception as e:
    print(f"❌ Pool test failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 4: P2P
print("\n[4/5] Testing P2P module...")
try:
    from derom.p2p import P2PNode, PeerConnection

    # Create P2P node (node_id is required)
    p2p = P2PNode(node_id="test-node", listen_port=9999)
    print("  ✓ Created P2P node")

    # Verify protocol constants exist (handshake + message framing)
    if "handshake" in P2PNode.MESSAGE_TYPES:
        print(f"  ✓ Protocol has handshake message type "
              f"(0x{P2PNode.MESSAGE_TYPES['handshake']:02X})")
    else:
        print("  ✗ Handshake message type missing!")
        sys.exit(1)

    # Get node ID
    node_id = p2p.node_id
    if node_id and len(node_id) > 0:
        print(f"  ✓ Node ID: {node_id[:16]}...")
    else:
        print("  ✗ No node ID!")
        sys.exit(1)

    print("✅ P2P tests passed!")
except Exception as e:
    print(f"❌ P2P test failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 5: GUI
print("\n[5/5] Testing GUI module...")
try:
    from derom.gui_qt import DeroMMainWindow, NodeWorker
    print("  ✓ GUI module imports successful")
    print("  Note: Full GUI testing requires display environment")
    print("✅ GUI module tests passed!")
except Exception as e:
    print(f"❌ GUI test failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("\n" + "=" * 60)
print("✅ ALL TESTS PASSED!")
print("=" * 60)
