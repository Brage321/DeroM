@echo off
cd /d "%~dp0"
if "%~1"=="" (
  py test_miner.py --user %DEROM_USER% --seconds 120
) else (
  py test_miner.py %*
)
pause
