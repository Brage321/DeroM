@echo off
title DeroM Control Panel (PyQt5)
cd /d "%~dp0"
py -B -m derom.gui_qt
